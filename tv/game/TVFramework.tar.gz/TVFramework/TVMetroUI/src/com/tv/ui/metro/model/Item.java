package com.tv.ui.metro.model;

import java.io.Serializable;

/**
 * Created by tv metro on 9/1/14.
 */
public class Item extends DisplayItem implements Serializable {
    private static final long serialVersionUID = 2L;
}
