package com.xiaomi.mibox.gamecenter.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import android.widget.Toast;
import com.tv.ui.metro.model.GameItem;
import org.json.JSONException;
import org.json.JSONObject;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.MiboxGamecenterApplication;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.data.GlobalConfig;
import com.xiaomi.mibox.gamecenter.data.IUserData;
import com.xiaomi.mibox.gamecenter.data.LocalAppInfo;

import java.util.Random;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.os.StatFs;
import android.text.TextUtils;
import android.util.Pair;
import android.util.SparseArray;

/**
 * 
 * @author mengshu
 *
 */
public class GamecenterUtils
{
	protected static final int BYTES_IN_MEGA = 1048576;
	protected static final int BYTES_IN_KILO = 1024;

	private final static String[] HEX_DIGITS = { "0", "1", "2", "3", "4", 
		"5", "6", "7", "8", "9", 
		"a", "b", "c", "d","e", "f" };
	public final static char MD5_SPILT_GAME_ID = '_';//假定 该字符不再 hexDigits中
	
	/**
	 * URL 加密密码
	 */
	private static final byte[] URL_KEY = "_&L^W%&*20130724#$U%I)M%I^@".getBytes();
	private static final byte[] HASH_KEY = "_&W^A%&*20120814#$D%T)M%R^@".getBytes();
	
	/**
	 * 客户端显示页面的大小
	 */
	public static final String PAGE_SIZE = "20";
	public static final int PAGE_COUNT_REQUEST = 20;
	
	//必须与AndroidManifest中关于AppDetailActivity的保持一致
	public static final String GAME_MIME_TYPE = "application/mgapk-ota";
	
	/**
	 * 判断UID是否有效
	 * @param uid
	 * @return
	 */
	public static boolean uidIsValid(String uid){
		if(TextUtils.isEmpty(uid)){
			return false;
		}
		//第一个版本的uid全是10000
		if("10000".equals(uid)){
			return false;
		}
		return true;
	}
	
	/**
	 * 加密链接
	 * 包装下，避免外部代码乱起八糟的调用
	 * @param url
	 * @return
	 */
	public static String encryptUrl(String url)
	{
		return Base64.encode(encryptUrl(url.getBytes()));
	}
	
	/**
	 * 包装解密过程
	 * @param url_base64 解密过程一定要注意，参数是base64字符串
	 * @return
	 */
	public static String decryptUrl(String url_base64)
	{
		return new String(encryptUrl(Base64.decode(url_base64)));
	}
	
	/**
	 * 从文件名中获取GameId
	 * @param fullPath
	 * @return
	 */
	public static String getGameId(String fullPath){
		if(!TextUtils.isEmpty(fullPath)){
			String appid = null;
			final int pos = fullPath.indexOf(MD5_SPILT_GAME_ID);
			if(pos != -1){
				final int len = fullPath.length();
				appid = fullPath.substring(pos+1, len);
				if(!TextUtils.isEmpty(appid)){
					return appid;
				}
			}
		}
		return null;
	}

	/**
	 * 获得本地缓存的名字，对url进行hash得到
	 */
	public static final String getCacheFileName( String url )
	{
		return getMD5(url);
	}

	public static final String getMD5(String string) {
		if (TextUtils.isEmpty(string)) {
			return null;
		}
		MessageDigest digester = null;
		try {
			digester = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			if (IConfig.DEBUG) e.printStackTrace();
			return null;
		}
		digester.update(string.getBytes());
		byte[] digest = digester.digest();
		return byteArrayToString(digest);
	}

	/**
	 * 
	 * @param filename
	 * @return
	 */
	public static final String NO_PERMISSION_MD5 = "--NO--PERMISSION--";
	public static final String getFileMD5( String filename ){
		InputStream fis;
		byte[] buffer = new byte[1024];
		int numRead = 0;
		MessageDigest md5;
		try {
			fis = new FileInputStream(filename);
		} catch (FileNotFoundException e) {
			if(IConfig.DEBUG) e.printStackTrace();
			if(e.getMessage().contains("(Permission denied)")){//没有权限引起的访问失败
				return NO_PERMISSION_MD5;
			}else{
				return null;
			}
		}

		try {
			md5 = MessageDigest.getInstance("MD5");
			while ((numRead = fis.read(buffer)) > 0) {
				md5.update(buffer, 0, numRead);
			}
		} catch (NoSuchAlgorithmException e) {
			if(IConfig.DEBUG) e.printStackTrace();
			return null;
		} catch (IOException e) {
			if(IConfig.DEBUG) e.printStackTrace();
			return null;
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				if(IConfig.DEBUG) e.printStackTrace();
			}
		}

		return byteArrayToString( md5.digest() );
	}

	private static String byteArrayToString( byte[] b ){
		StringBuffer resultSb = new StringBuffer();
		for ( int i = 0; i < b.length; i++ ){
			resultSb.append( byteToHexString( b[i] ) );
		}
		return resultSb.toString();
	}

	private static String byteToHexString( byte b ){
		int n = b;
		if (n < 0) {
			n = 256 + n;
		}
		int d1 = n / 16;
		int d2 = n % 16;
		return HEX_DIGITS[d1] + HEX_DIGITS[d2];
	}
	
	/**
	 * 判断一个数组是否为空
	 * @param list
	 * @return
	 */
	public static boolean isEmpty(List<?> list){
		if(list != null && list.size() > 0){
			return false;
		}else{
			return true;
		}
	}
	
	public static boolean isEmpty(SparseArray<?> list){
		if(list != null && list.size() > 0){
			return false;
		}else{
			return true;
		}
	}

	public static boolean isConnected( Context context )
	{
		ConnectivityManager connManager = (ConnectivityManager) 
				context.getSystemService( Context.CONNECTIVITY_SERVICE );
		NetworkInfo networkInfo = connManager.getActiveNetworkInfo();
		return networkInfo != null && networkInfo.isConnectedOrConnecting();
	}

	public static boolean isWifiConnected( Context context ) {
		if(null == context) return false;
		ConnectivityManager connManager = (ConnectivityManager) 
				context.getSystemService( Context.CONNECTIVITY_SERVICE );
		NetworkInfo networkInfo = connManager.getActiveNetworkInfo();
		return (networkInfo != null 
				&& networkInfo.getType() == ConnectivityManager.TYPE_WIFI);
	}

	/**
	 * 返回字节数对应的字符串，换算至KB或MB
	 */
	public static String getByteString( long bytes, String fromat,Context context)
	{
		if ( bytes < 0 )
		{
			return "";
		}
		String value = null;
		int unitRes = 0;
		if ( bytes > BYTES_IN_MEGA ){
			value = String.format( fromat, (double) ( bytes * 1.0 / BYTES_IN_MEGA ) );
			unitRes = R.string.megabytes_unit;
		}else if ( bytes > BYTES_IN_KILO ){
			value = String.format( fromat, (double) ( bytes * 1.0 / BYTES_IN_KILO ) );
			unitRes = R.string.kilobytes_unit;
		}else{
			value = String.valueOf( bytes );
			unitRes = R.string.bytes_unit;
		}
		return context.getString( unitRes, value );
	}

	public static Bitmap makeRoundImage( Bitmap bm, int rx, int ry )
	{
		if ( bm == null ){
			return null;
		}

		int width = bm.getWidth();
		int height = bm.getHeight();
		Bitmap round = MemoryManager.mallocBitmap(width, height, Config.ARGB_8888);
		if(null == round){
			return null;
		}
//			Bitmap.createBitmap( width, height, Config.ARGB_8888 );
		Canvas canvas = new Canvas( round );

		final Paint paint = new Paint( Paint.ANTI_ALIAS_FLAG );
		int minRound = Math.min( width, height ) / 3;
		rx = Math.min( rx, minRound );
		ry = Math.min( ry, minRound );

		canvas.drawARGB( 0, 0, 0, 0 );
		paint.setColor( 0xff424242 );
		canvas.drawRoundRect( new RectF( 0, 0, width, height ), rx, ry, paint );

		paint.setXfermode( new PorterDuffXfermode( Mode.SRC_IN ) );
		canvas.drawBitmap( bm, 0, 0, paint );

		return round;
	}

	/**
	 * 数据加密
	 * 
	 * @param src : 源数据
	 * @param pass ：密钥
	 * @return
	 */
	public static byte[] encrypt( byte[] src, byte[] pass )
	{
		if (null == src) return null;
		if (null == pass) return src;
		final int srcLen = src.length;
		final int passLen = pass.length;
		byte[] res = new byte[srcLen];
		for ( int i = 0; i < srcLen; i += passLen )
		{
			for ( int j = 0; j < passLen && ( i + j < srcLen ); j++ )
			{
				res[i + j] = (byte) ( src[i + j] ^ pass[j] );
			}
		}
		return res;
	}

	/**
	 * 对URL进行加密
	 * 
	 * @param src
	 * @return
	 */
	public static byte[] encryptUrl( byte[] src )
	{
		return encrypt( src, URL_KEY );
	}
	
	/**
	 * 对HASH 进行加密下
	 * @param src
	 * @return
	 */
	public static byte[] encryptApkHash( byte[] src){
		return encrypt( src, HASH_KEY );
	}

	/**
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public static String encodeRequestJson( JSONObject json ) throws Exception{
		return Base64.encode(AESEncryption.Encrypt(json.toString(), 
				Constants.AES_KEY));
	}
	
	/**
	 * @param responseMessage
	 * @return
	 * @throws Exception
	 * @throws JSONException
	 */
	public static String praseEncodeResponseMessage(String responseMessage) {
		try {
			final byte[] decode64 = Base64.decode(responseMessage);
			byte[] jsonB = AESEncryption.Decrypt(decode64, Constants.AES_KEY);
			String jsonStr = new String(jsonB);
			if (TextUtils.isEmpty(jsonStr)) {
				return "";
			}

			return jsonStr;
		} catch (JSONException e) {
			if (IConfig.DEBUG){
				e.printStackTrace();
			}
		} catch (Exception e) {
			if (IConfig.DEBUG){
				e.printStackTrace();
			}
		}
		
		return "";
	}
	
	/**
	 * 通过APP的包名启动APP
	 * @param context
	 * @param pkgName
	 * @return
	 */
	public static void startGameByPkgName(Context context, String pkgName){
		if(context != null && !TextUtils.isEmpty(pkgName)){
			PackageManager packageManager = context.getPackageManager(); 
			Intent intent = packageManager.getLaunchIntentForPackage(pkgName);
			if(intent != null){
				context.startActivity(intent);
			}
		}
	}
	
	/**
	 * 确保SD卡上的Downloads目录存在
	 * @since 2012.10.22
	 */
	public static boolean makesureDownloadsDirExist(){
		boolean success = true;
    	File f = Environment.getExternalStoragePublicDirectory(
    			Environment.DIRECTORY_DOWNLOADS);
    	if(!f.exists()){
    		success = f.mkdirs();
    	}
    	f = null;
    	return success;
	}
	
	/**
	 * 删除下载的部分文件
	 */
	public static boolean deleteExistDownloadPartialFiles(String fileName){
		boolean success = false;
		File f = Environment.getExternalStoragePublicDirectory(
    			Environment.DIRECTORY_DOWNLOADS);
    	if(f.exists()){
    		File file = new File(f.getAbsolutePath(), fileName);
    		if(file.exists()){
    			success = file.delete();
    		}
    	}
    	f = null;
    	
    	return success;
	}
	
	/**获取一个随机整数
	 * @param range:随机数的大小范围
	 * @return 如果range大于0，则返回一个0-range-1之间的一个随机数。如果range小于等于0，则返回0
	 */
	public static int getRandomInt(int range)
	{
		if(range<=0)
		{
			return 0;
		}
		Random ran =new Random(System.currentTimeMillis()); 
		int ret = Math.abs(ran.nextInt())%range;
		return ret;
	}
	
	/**
	 * 将字符串数组用分号链接起来
	 * @param list
	 * @return
	 */
	public static String joinList(ArrayList<String> list){
		if(GamecenterUtils.isEmpty(list)){
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for(String s : list){
			sb.append(s);
			sb.append(Constants.SPLIT_PATTERN_SEMICOLON);
		}
		return sb.toString();
	}
	
	/**
	 * 将子符串用分号切分开
	 * @param str
	 * @return
	 */
	public static void splitList(String str, ArrayList<String> list){
		if(TextUtils.isEmpty(str) || null == list){
			return;
		}
		String[] listArray = str.split(Constants.SPLIT_PATTERN_SEMICOLON);
		if(listArray != null){
			for(String content: listArray){
				list.add(content);
			}
		}
	}
	
    public static long getDiskFreeSize(String path) {
        StatFs sf = new StatFs(path);
        long blockSize = sf.getBlockSize();
        long availCount = sf.getAvailableBlocks();
        return availCount * blockSize;
    }
	
	/**
	 * 
	 * @param localInstalledApp
	 * @return
	 */
	private static final String PKG_VER_SPILT = ",";
	public static Pair<String, String> createQueryGame(Collection<LocalAppInfo> localInstalledApp){
		if(null == localInstalledApp || 0 == localInstalledApp.size()){
			return null;
		}

		StringBuilder pkgBuilder = new StringBuilder();
		StringBuilder versionBuilder = new StringBuilder();
		for(LocalAppInfo appInfo : localInstalledApp){
			pkgBuilder.append(appInfo.mPackageName);
			pkgBuilder.append(PKG_VER_SPILT);
			
			versionBuilder.append(appInfo.mVersionCode);
			versionBuilder.append(PKG_VER_SPILT);
		}
		if(pkgBuilder.length() > 1){
			pkgBuilder.deleteCharAt(pkgBuilder.length()-1);
		}
		if(versionBuilder.length() > 1){
			versionBuilder.deleteCharAt(versionBuilder.length()-1);
		}
		return new Pair<String, String>(pkgBuilder.toString(),
				versionBuilder.toString());
	}
	
	/**
	 * 获取以太网的地址
	 * @return
	 */
	public static String getEth0Address(){
		NetworkInterface NIC;
		StringBuilder sb = new StringBuilder(24);
		try {
			NIC = NetworkInterface.getByName("eth0");
	        byte[] buf = NIC.getHardwareAddress();
	        for (int i = 0; i < buf.length; i++) {
	        	sb.append(GamecenterUtils.byteToHexString(buf[i]));
	        }
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
	
	/**
	 * 
	 * @param ctx
	 * @param isGet
	 * @return
	 */
	public static HashMap<String, String> getRequestBaseParam(Context ctx,
			boolean isGet) {
		HashMap<String, String> param = new HashMap<String, String>();
		param.put(Constants.MID,
				GlobalConfig.getInstance().Get(IUserData.XIAOMI_ID));
		param.put(Constants.UID, GlobalConfig.getInstance().Get(IUserData.UUID));
		param.put(Constants.CLIENT_ID, Client.UUID);
		param.put(Constants.MAC_WIFI, Client.MacWifi);
		param.put(Constants.BID, Constants.MITV_GAMECENTER_BID);
		param.put(Constants.CID, IConfig.GAME_CENTER_CID);
		param.put(Constants.SDK_VERSION, "" + Client.SDK_VERSION);
		try {
			param.put(Constants.UA,
					isGet ? URLEncoder.encode(SystemConfig.get_phone_ua().trim(), "utf-8") :
						SystemConfig.get_phone_ua().trim());
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		param.put(Constants.PLATFORM, "android");
		param.put(Constants.CLIENT_VERSION_CODE, "" + Client.GAMECENTER_VERSION);
		param.put(Constants.VN, Client.GAMECENTER_VERSION_NAME);
		param.put(Constants.VERSION, Client.SYSTEM_VERSION);
		param.put(Constants.LANGUAGE, Locale.getDefault().getLanguage());
		param.put(Constants.COUNTRY, Locale.getDefault().getCountry());
		return param;
	}
	
	/**
	 * 
	 * @param app
	 */
    public static void showSystemSpaceNotEnoughFailNotification(GameItem app) {
    	if(null == app){
    		return;
    	}
        Context context = MiboxGamecenterApplication.getInstance();
        String message = null;
        if(TextUtils.isEmpty(app.name)){
              message = context.getResources().getString(
                      R.string.install_fail, 
                      app.name);
        }else{
            message = context.getResources().getString(
                R.string.notif_install_failed_system_space_not_enough, 
                app.name);
        }
        Toast.makeText(context,
                message,
                Toast.LENGTH_LONG).show();
    }
	
	/**
	 * 空间不足
	 * @param app
	 */
	public static void showSDCardSpaceNotEnoughFailNotification(GameItem app) {
		if (null == app) {
			return;
		}
		Context context = MiboxGamecenterApplication.getInstance();
		String message = null;
		if(TextUtils.isEmpty(app.name)){
	          message = context.getResources().getString(
	                  R.string.install_fail, 
	                  app.name);
		}else{
		    message = context.getResources().getString(
		        R.string.notif_install_failed_system_space_not_enough, 
		        app.name);
		}
		Toast.makeText(context, 
		        message, 
		        Toast.LENGTH_LONG).show();
	}
	
	/**
	 * 签名不一致
	 * @param app
	 */
    public static void showInconsistentFailNotification(GameItem app) {
        if (null == app) {
            return;
        }
        Context context = MiboxGamecenterApplication.getInstance();
        String message = null;
        message = context.getResources().getString(
                R.string.install_inconsistent_fail, 
                app.name);
        Toast.makeText(context, 
                message, 
                Toast.LENGTH_LONG).show();
    }
}
