package com.xiaomi.mibox.gamecenter.bluetooth;

import android.bluetooth.BluetoothDevice;

public interface OnBluetoothHandlerListener {
	/**
	 * 有新的设备连接上
	 * @param device
	 */
	public void connected(BluetoothDevice device);
	
	/**
	 * 有设备断开
	 * @param device
	 */
	public void disconnected(BluetoothDevice device);
}
