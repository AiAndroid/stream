package com.xiaomi.mitv.store.video;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.VolleyHelper;
import com.tv.ui.metro.model.DisplayItem;
import com.tv.ui.metro.model.GenericItemList;
import com.tv.ui.metro.model.VideoItem;
import com.tv.ui.metro.view.ImageChangedListener;
import com.tv.ui.metro.view.TextViewWithTTF;
import com.xiaomi.mibox.gamecenter.*;
import com.xiaomi.mibox.gamecenter.utils.Client;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mitv.store.XiaomiUIHelper;
import com.xiaomi.mitv.store.network.GenericDetailLoader;

import java.util.ArrayList;

/**
 * Created by tv metro on 9/1/14.
 */
public class VideoDetailActivity  extends XiaomiUIHelper implements LoaderManager.LoaderCallbacks<GenericItemList<VideoItem>>, ImageChangedListener {

    GenericItemList<VideoItem> mVideoInfo;
    GridView        relativeVideo;
    RelativeAdapter adater;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.video_detail_layout);
        ImageView iv = (ImageView) findViewById(R.id.logo_movie);

        Button bt = (Button) findViewById(R.id.play_button);
        bt.setOnClickListener(playClicker);

        ObjectAnimator animShime = ObjectAnimator.ofFloat(bt, "ScaleUp",
                new float[] { 1.0F, 1.15F, 1.0F }).setDuration(500);
        animShime.start();

        relativeVideo = (GridView) findViewById(R.id.relative_videos);

        Button play_show = (Button) findViewById(R.id.play_show);
        play_show.setOnClickListener(showClick);

        bt.requestFocus();
        getSupportLoaderManager().initLoader(GenericDetailLoader.VIDEO_LOADER_ID, null, this);
    }


    View.OnClickListener showClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(mVideoInfo != null) {
                Intent intent = new Intent(getApplicationContext(), VideoRelativesActivity.class);
                intent.putExtra("item", mVideoInfo.data.get(0));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        }
    };

    AdapterView.OnItemClickListener itemClicker = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("micontent://" + item.ns + "/" + item.type + "?rid=" + item.id));
                Object tag = view.getTag();
                if(tag != null && tag instanceof DisplayItem){
                    DisplayItem content = (DisplayItem)tag;

                    intent.putExtra("item", content);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    view.getContext().startActivity(intent);
                }else {
                    //just for test
                    intent.putExtra("item", item);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    view.getContext().startActivity(intent);
                }

            }catch (Exception ne){ne.printStackTrace();}
        }
    };

    public class RelativeAdapter extends BaseAdapter {
        public RelativeAdapter(ArrayList<DisplayItem> content){
            super();
            if(content != null) {
                items = content;
                notifyDataSetChanged();
            }
        }

        public void changeContent(ArrayList<DisplayItem> content){
            if(content != null) {
                items = content;
                notifyDataSetChanged();
            }
        }
        private ArrayList<DisplayItem> items;

        @Override
        public int getCount() {
            return items==null?7:items.size();
        }

        @Override
        public Object getItem(int i) {
            return items==null?new Object():items.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        String images[] = {
                "http://file.market.xiaomi.com/download/563/096e0664b3bdcfc6253b22a55a36393833a778e2/dk951926_20130407200411_b1080.jpg",
                "http://file.market.xiaomi.com/download/9e8/04d84bef48457ac2993d7d1d9c5c68c5dbdfbb0c/dk950876_20130327161443_b1080.jpg",
                "http://file.market.xiaomi.com/download/Duokan/c96e0aea-92a6-4515-80a2-ca0343b3569a/dk973988_20140129163805_b1080.jpg",
                "http://file.market.xiaomi.com/download/5fa/f6145cf0aa32b3ff8084052355243afa32a2a70e/dk855694_20130117174220_b1080.jp",
                "http://file.market.xiaomi.com/download/Duokan/a4529e4e-4c87-4987-b495-ea857a631008/dk973990_20140129163834_b1080.jpg",
                "http://file.market.xiaomi.com/download/306/3c81b503564eacbb05eab6e33b0f88209a0346e8/dk833318_20121208164915_b1080.jpg",
                "http://file.market.xiaomi.com/download/Duokan/a4576591-652b-4b25-8465-2cabc018ca5e/dk972601_20131231122950_b1080.jpg",
                "http://file.market.xiaomi.com/download/b64/f113906b6439a28b6444a153b8558e4d3a4dfbac/dk951143_20130402101436_b1080.jpg",
                "http://file.market.xiaomi.com/download/Duokan/fba8d34d-d67f-4e53-9ca7-870e96e0a4a8/dk969822_20131101104025_b1080.jp",
                "http://file.market.xiaomi.com/download/77b/43ea7e7e5b51a45ee1313ba97474e26ca68c3a53/dk946956_20130319130648_b1080.jpg",
                "http://file.market.xiaomi.com/download/477/e982137277ff93decfb471a94102af74d3077a40/dk950748_20130327100053_b1080.jpg",
                "http://file.market.xiaomi.com/download/Duokan/129c3492-a507-4b68-886e-f8f3af29836b/dk964334_20130828104932_b1080.jpg",
                "http://file.market.xiaomi.com/download/db5/360a10bd45b5ddd2d926a98fd0f4351dcc6b082a/dk951972_20130403192348_b1080.jpg",
                "http://file.market.xiaomi.com/download/8ef/8e31c2e0ef66d36a57a487c78cd61ee21c644b26/dk753750_20121219193646_b1080.jpg",
                "http://file.market.xiaomi.com/download/f74/54a09379549b6558329dc79df39eecfd83ef9a17/dk819440_20121207204255_b1080.jpg",
                "http://file.market.xiaomi.com/download/bd1/dcdf68dbf1ab9986e804e9ccb0be01722788e6e6/dk754824_20121219193939_b1080.jpg",
                "http://file.market.xiaomi.com/download/7c0/f9e0f0c1102f9f4661734ae77e3ac5fd38a2472b/dk956011_20130615134754_b1080.jpg",
                "http://file.market.xiaomi.com/download/656/c31c845636beffc6b3abe96d65deeb078c48a77d/dk950175_20130321145449_b1080.jpg",
                "http://file.market.xiaomi.com/download/194/dc1e1f9bb45609697013abbe1ff33fc86fe65c0c/dk951925_20130407200407_b1080.jpg",
                "http://file.market.xiaomi.com/download/508/afd85606883a378bbbeb4dbb5dc17deeeaa8f0d5/dk28830_20121217101433_b1080.jpg"
        };
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if(items == null) {
                ImageView iv = new ImageView(getBaseContext());
                android.widget.AbsListView.LayoutParams lp = new android.widget.AbsListView.LayoutParams(186, 274);
                iv.setLayoutParams(lp);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);

                VolleyHelper.getInstance(getBaseContext()).getImageLoader().get(images[((int) (Math.random() * 100)) % images.length], ImageLoader.getImageListener(iv, R.drawable.icon_v_default, R.drawable.icon_v_default));
                return iv;
            }else {
                ImageView iv = null;
                if(view == null) {
                    iv = new ImageView(getBaseContext());
                    android.widget.AbsListView.LayoutParams lp = new android.widget.AbsListView.LayoutParams(186, 274);
                    iv.setLayoutParams(lp);
                    iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                }else{
                    iv = (ImageView)view;
                }

                iv.setTag(getItem(i));
                String url = "";
                if(((DisplayItem) getItem(i)).images.get("big_poster") != null)
                    url = ((DisplayItem) getItem(i)).images.get("big_poster").url;

                if(url != null && url.length() > 0 && ((DisplayItem) getItem(i)).images.get("small_poster") != null)
                    url = ((DisplayItem) getItem(i)).images.get("small_poster").url;

                VolleyHelper.getInstance(getBaseContext()).getImageLoader().get(url, ImageLoader.getImageListener(iv, R.drawable.icon_v_default, R.drawable.icon_v_default));


                return iv;
            }
        }
    }

    View.OnClickListener playClicker = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            try {
                String videoUrl = "http://payment.icntvcdn.com/media/new/2013/icntv2/media/2014/08/26/b01da2a3af7d44c482e76b9ec68d71c1.ts";
                if(mVideoInfo != null && mVideoInfo.data.get(0).videos.get(0).urls.get("super") != null){
                    videoUrl =  mVideoInfo.data.get(0).videos.get(0).urls.get("super");
                }else if(mVideoInfo != null && mVideoInfo.data.get(0).videos.get(0).urls.get("high") != null){
                    videoUrl =  mVideoInfo.data.get(0).videos.get(0).urls.get("high");
                }

                if(Client.isTV2()){
                    Intent intent = new Intent();
                    intent.setAction(Constants.MITV_VIDEO_INTENT_ACTION);
                    intent.setData(Uri.parse(videoUrl));

                    try{
                        startActivity(intent);
                    }catch(Exception e){
                        Intent videoIntent = new Intent(getApplicationContext(), PlayerActivity.class);
                        videoIntent.putExtra("video_url", videoUrl);
                        startActivity(videoIntent);
                    }
                }else {
                    Intent videoIntent = new Intent(getApplicationContext(), PlayerActivity.class);
                    videoIntent.putExtra("video_url", videoUrl);
                    startActivity(videoIntent);
                }

            }catch (Exception ne){}
        }
    };

    //please override this fun
    protected void createItemLoader(){
        mLoader = GenericDetailLoader.generateVideotLoader(this, item);
    }

    @Override
    public Loader<GenericItemList<VideoItem>> onCreateLoader(int loaderId, Bundle bundle) {
        if(loaderId == GenericDetailLoader.VIDEO_LOADER_ID){
            createItemLoader();
            mLoader.setProgressNotifiable(mLoadingView);
            return mLoader;
        }else{
            return null;
        }
    }

    @Override
    public void onLoadFinished(Loader<GenericItemList<VideoItem>> itemLoader, GenericItemList<VideoItem> item) {
        if(item == null || (mVideoInfo != null && mVideoInfo.update_time != item.update_time)) {
            return;
        }else {
            //set data
            mVideoInfo = item;
            updateUI(mVideoInfo);
        }
    }

    private void updateUI(GenericItemList<VideoItem> item){
        if(item.data != null && item.data.size() > 0) {
            VideoItem vItem = item.data.get(0);
            ImageView iv = (ImageView) findViewById(R.id.logo_movie);
            VolleyHelper.getInstance(getBaseContext()).getImageLoader().get(vItem.images.get("big_poster").url, ImageLoader.getImageListener(iv, 0, 0));

            ((TextViewWithTTF) findViewById(R.id.title)).setText(vItem.name);
            ((TextViewWithTTF) findViewById(R.id.rating)).setText(vItem.score);
            if(vItem.category!= null){
                StringBuilder sb = new StringBuilder();
                int i = 1;
                for(VideoItem.Category cate:  vItem.category){
                    if(i>2)sb.append("\n");
                    sb.append(cate.name);
                    sb.append("  ");
                    i++;
                }
                ((TextViewWithTTF) findViewById(R.id.category)).setText(sb.toString());
            }else{findViewById(R.id.category).setVisibility(View.GONE);}

            if(vItem.directors != null) {
                StringBuilder sb = new StringBuilder();
                for (VideoItem.Director cate : vItem.directors) {
                    sb.append(cate.name);
                    sb.append("  ");
                }
                ((TextViewWithTTF) findViewById(R.id.director_name)).setText(sb.toString());
            }else {findViewById(R.id.director_name).setVisibility(View.GONE);}

            if(vItem.actors != null){
                findViewById(R.id.fading_right).setVisibility(View.GONE);
                findViewById(R.id.fadding_left).setVisibility(View.GONE);

                if(vItem.actors.size()>0){findViewById(R.id.actor_name_1).setVisibility(View.VISIBLE); ((TextViewWithTTF)findViewById(R.id.actor_name_1)).setText(vItem.actors.get(0).name);}
                if(vItem.actors.size()>1){findViewById(R.id.actor_name_2).setVisibility(View.VISIBLE); ((TextViewWithTTF)findViewById(R.id.actor_name_2)).setText(vItem.actors.get(1).name);}
                if(vItem.actors.size()>2){findViewById(R.id.actor_name_3).setVisibility(View.VISIBLE); ((TextViewWithTTF)findViewById(R.id.actor_name_3)).setText(vItem.actors.get(2).name);}
                if(vItem.actors.size()>3){findViewById(R.id.actor_name_4).setVisibility(View.VISIBLE); findViewById(R.id.fading_right).setVisibility(View.VISIBLE);findViewById(R.id.fadding_left).setVisibility(View.VISIBLE);((TextViewWithTTF)findViewById(R.id.actor_name_4)).setText(vItem.actors.get(3).name);}
            }
            ((TextViewWithTTF) findViewById(R.id.description)).setText(vItem.description);

            //update relative
            adater = new RelativeAdapter(vItem.related);
            relativeVideo.setAdapter(adater);
            relativeVideo.setOnItemClickListener(itemClicker);
        }
    }

    @Override
    public void onLoaderReset(Loader<GenericItemList<VideoItem>> itemLoader) {

    }

    @Override
    public void onImageChanged(ImageView view) {

    }
}
