package com.xiaomi.mitv.store.game;


import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.text.Html;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.*;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.VolleyHelper;
import com.tv.ui.metro.model.GameItem;
import com.tv.ui.metro.model.GenericItemList;
import com.tv.ui.metro.view.ImageChangedListener;
import com.xiaomi.mibox.gamecenter.*;
import com.xiaomi.mibox.gamecenter.data.MainHandler;
import com.xiaomi.mibox.gamecenter.data.statics.Report;
import com.xiaomi.mibox.gamecenter.data.statics.ReportManager;
import com.xiaomi.mibox.gamecenter.data.statics.StaticsType;
import com.xiaomi.mibox.gamecenter.ui.IExtraIntent;
import com.xiaomi.mibox.gamecenter.ui.gamedetail.*;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;
import com.xiaomi.mibox.gamecenter.utils.ImageUtils;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;
import com.xiaomi.mibox.gamecenter.ui.view.HorizontalScrollListView;
import com.xiaomi.mitv.store.XiaomiUIHelper;
import com.xiaomi.mitv.store.network.GenericDetailLoader;
import com.xiaomi.mitv.app.view.TitleBar;
import com.xiaomi.mitv.store.utils.Utils;

/**
 * Created by tv metro on 8/28/14.
 */
public class GameDetailActivity extends XiaomiUIHelper implements LoaderManager.LoaderCallbacks<GenericItemList<GameItem>>, ImageChangedListener, GameDetailsLayout.ExcuteKeyProcess {

    protected RelativeLayout mRootView;
    private GameDetailsLayout contentLayout;

    private Bitmap mIconBitmap;
    private String mIcon;
    private GameInfoView mGameInfoView;

    private ThumbListView mScreenShotListView;
    private TextView mScreenShotEmptyView;
    private ImageView mFocusedView;

    private TextView mSummaryView;
    private Button allIntroButton;

    private com.xiaomi.mitv.app.view.TitleBar titleBar;

    private LinearLayout mRelatedGamesLayout;
    private RelatedGameListView mRelatedGameListView;
    private ImageView mRelatedGameFocuedView;

    private static int Y_DISTANCE = 846;

    private boolean mHasRelatedGames = false;//是否有相关游戏
    private boolean mHasScreenShot = false;//是否有截图

    private ImageView mScreenShotMaskLeftView;
    private ImageView mScreenShotMaskRightView;

    private String mFrom;
    private String mCategoryId;
    private String mPosition;

    private long mLastProcessTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupViews();

        mLoadingView = makeEmptyLoadingView(this, (RelativeLayout)findViewById(R.id.tabs_content));

        TitleBar tb = (TitleBar) this.findViewById(R.id.detail_title_bar);
        tb.setTitle(item.name);

        mGameInfoView.setOnImageChangedListener(this);
        construceGameInfo();

        tb.setBackPressListner(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GameDetailActivity.this.finish();
            }
        });
        
        getSupportLoaderManager().initLoader(GenericDetailLoader.GAME_LOADER_ID, null, this);
    }


    private String mGameId ;
    private void construceGameInfo(){
        Intent intent = null;
        intent = getIntent();
        //游戏的ID
        mGameId = intent.getStringExtra(Constants.GAME_ID);
        if (TextUtils.isEmpty(mGameId)){
            Uri uri = intent.getData();
            if(uri != null){
                mGameId = uri.getHost();
            }
        }
        //统计用
        mFrom = intent.getStringExtra(IExtraIntent.FROM);
        mPosition = intent.getStringExtra(IExtraIntent.POSITION);
        mCategoryId = intent.getStringExtra(IExtraIntent.CATEGORY_ID);
    }

    private void setupViews(){
        setContentView(R.layout.game_detail_layout);

        Y_DISTANCE = getResources().getDimensionPixelSize(R.dimen.detail_y_distance);
        mRootView = (RelativeLayout) this.findViewById(R.id.details_container);

        contentLayout = (GameDetailsLayout) this.findViewById(R.id.game_detail_layout);
        contentLayout.setExcuteKeyProcess(this);

        //第一部分
        mGameInfoView = (GameInfoView) this.findViewById(R.id.game_info_view);

        //视频截图
        mScreenShotListView = (ThumbListView) this.findViewById(R.id.game_thumb_list);
        mScreenShotListView.setOnHorizontalScrollClickListener(mThumbListOnClickListener);

        //空截图信息
        mScreenShotEmptyView = (TextView) this.findViewById(R.id.empty_view);

        //游戏简介
        TextView introTitleView = (TextView) this.findViewById(R.id.game_subject);

        mSummaryView = (TextView) this.findViewById(R.id.game_summary);
        mSummaryView.setLineSpacing(20, 1.0f);

        //全部简介按钮
        allIntroButton = (Button) this.findViewById(R.id.all_introduction_button);
        allIntroButton.setOnClickListener(mAllIntroClickListener);
        allIntroButton.setOnKeyListener(mAllIntroKeyListener);

        mRelatedGamesLayout = (LinearLayout) this.findViewById(R.id.relative_games);

        //相关游戏
        mRelatedGameListView = (RelatedGameListView) this.findViewById(R.id.relative_list_games);
        mRelatedGameListView.setOnHorizontalScrollClickListener(mOnRelatedGameListListener);

        mScreenShotMaskLeftView = (ImageView) this.findViewById(R.id.mask_left);
        mScreenShotMaskRightView = (ImageView) this.findViewById(R.id.mask_right);

        //游戏截图的焦点框
        mFocusedView = (ImageView) this.findViewById(R.id.screen_shot_focus_view);
        mScreenShotListView.setFocusedView(mFocusedView);

        mRelatedGameFocuedView = (ImageView) this.findViewById(R.id.relative_focus_view);
        mRelatedGameListView.setFocusedView(mRelatedGameFocuedView);

        //最后添加
        titleBar = (TitleBar) this.findViewById(R.id.detail_title_bar);
        titleBar.setTitle(R.string.game_detail_text);
    }

    private HorizontalScrollListView.OnHorizontalScrollClickListener mOnRelatedGameListListener = new HorizontalScrollListView.OnHorizontalScrollClickListener(){

        @Override
        public void onClick(Object data, int pos) {
            if(!(data instanceof GameItem)){
                return;
            }
            GameItem gameInfo = (GameItem)data;
            Intent intent = new Intent(GameDetailActivity.this, GameDetailActivity.class);
            intent.putExtra(Constants.GAME_ID, gameInfo.id);
            intent.putExtra("item", gameInfo);
            //统计用
            intent.putExtra(IExtraIntent.FROM, StaticsType.PAGE_DETAIL_RECOMMEND);
            intent.putExtra(IExtraIntent.POSITION, StaticsType.PREFIX + pos);
            intent.putExtra(IExtraIntent.CATEGORY_ID, mGameInfo.data.get(0).id);
            startActivity(intent);

            finish();
        }
    };


    //全部游戏简介
    private View.OnClickListener mAllIntroClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            Intent intent = new Intent(GameDetailActivity.this,  GameSummaryPage.class);
            intent.putExtra(Constants.GAME_ID, mGameInfo.data.get(0).id);
            intent.putExtra("item",   mGameInfo.data.get(0));
            intent.putExtra(GameSummaryPage.ICON, mIconBitmap);
            startActivity(intent);

            ReportManager.getInstance().send(Report.createReport(Report.ReportType.STATISTICS, StaticsType.PAGE_DETAIL, mGameInfo.data.get(0).id, null, "intro", null, null, null));
        }
    };

    private View.OnKeyListener mAllIntroKeyListener = new View.OnKeyListener() {

        @Override
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if(KeyEvent.ACTION_DOWN == event.getAction()){
                //屏蔽系统默认的处理方式
                if(KeyEvent.KEYCODE_DPAD_LEFT == keyCode
                        || KeyEvent.KEYCODE_DPAD_RIGHT == keyCode){
                    WLUIUtils.playSoundEffect(v, WLUIUtils.KEYCODE_ERROR);
                    return true;
                }
            }
            return false;
        }
    };

    private HorizontalScrollListView.OnHorizontalScrollClickListener mThumbListOnClickListener = new HorizontalScrollListView.OnHorizontalScrollClickListener(){

        @Override
        public void onClick(Object data, int pos) {
            Intent intent = new Intent(GameDetailActivity.this, ScreenShotActivity.class);
            intent.putExtra(ScreenShotActivity.SELECTED_POS, pos);
            intent.putExtra("item", mGameInfo.data.get(0));
            intent.putExtra(ScreenShotActivity.SCREEN_SHOTS, mGameInfo);
            startActivity(intent);
        }
    };


    //please override this fun
    protected void createItemLoader(){
        mLoader = GenericDetailLoader.generateGametLoader(this, item);
    }
    
    @Override
    public Loader<GenericItemList<GameItem>> onCreateLoader(int loaderId, Bundle bundle) {
        if(loaderId == GenericDetailLoader.GAME_LOADER_ID){
            createItemLoader();
            mLoader.setProgressNotifiable(mLoadingView);
            return mLoader;
        }else{
            return null;
        }
    }

    GenericItemList<GameItem> mGameInfo;
    @Override
    public void onLoadFinished(Loader<GenericItemList<GameItem>> tabsLoader, GenericItemList<GameItem> items) {
        //process items detail UI
        if(items == null || (mGameInfo != null && items.update_time == mGameInfo.update_time)){
            return ;
        }else{
            //update UI
            mGameInfo = items;

            //save GameItem into local cache
            Utils.saveGameInfo(getBaseContext(), mGameInfo.data.get(0));

            if(mGameInfoView != null){
                mGameInfoView.bindGameInfo(mGameInfo.data.get(0), mFrom, mCategoryId, mPosition);
            }
            mSummaryView.setText(Html.fromHtml(mGameInfo.data.get(0).description));
            if(GamecenterUtils.isEmpty(mGameInfo.data.get(0).screenshots)){
                mHasScreenShot = false;
                mScreenShotListView.setVisibility(View.GONE);
                mScreenShotEmptyView.setVisibility(View.VISIBLE);
            }else{
                mHasScreenShot = true;
                mScreenShotEmptyView.setVisibility(View.GONE);
                mScreenShotListView.setVisibility(View.VISIBLE);
                mScreenShotListView.bindScreenShots(mGameInfo.data.get(0));
            }

            if (items.data.get(0).related != null && mRelatedGameListView != null) {
                if(GamecenterUtils.isEmpty(items.data.get(0).related)){
                    mHasRelatedGames = false;
                    mRelatedGamesLayout.setVisibility(View.GONE);
                }else{
                    mHasRelatedGames = true;
                    mRelatedGamesLayout.setVisibility(View.VISIBLE);
                    mRelatedGameListView.bindData(items.data.get(0).related);
                }
            }

            mGameInfo = items;
        }
    }

    @Override
    public void onLoaderReset(Loader<GenericItemList<GameItem>> tabsLoader) {

    }

    @Override
    public boolean excuteKey(KeyEvent event) {
        if(KeyEvent.ACTION_DOWN != event.getAction()){
            return false;
        }
        final long currTime = System.currentTimeMillis();
        if(Math.abs(mLastProcessTime-currTime) < 250){
            return true;
        }
        mLastProcessTime = currTime;
        if(KeyEvent.KEYCODE_DPAD_DOWN == event.getKeyCode()){
            if(contentLayout.needScrollDown()){
                if((mHasScreenShot  && mScreenShotListView.hasFocus())
                        || (!mHasScreenShot && mGameInfoView.focus())){
                    contentLayout.smoothScrollBy(-Y_DISTANCE, 250);
                    allIntroButton.requestFocus();
                    titleBar.setAlpha(0.0f);
                    maskScreenShotDisappear();
                    return true;
                }
            }
        }

        if(KeyEvent.KEYCODE_DPAD_UP == event.getKeyCode()){
            if(allIntroButton.hasFocus()){
                contentLayout.smoothScrollBy(Y_DISTANCE, 250);
                titleBar.setAlpha(1.0f);
                if(mHasScreenShot){
//                    mScreenShotListView.setLayoutAdjustY(Y_DISTANCE);
                    MainHandler.getInstance().postDelayed(new Runnable(){
                        @Override
                        public void run() {
                            if(mScreenShotListView != null){
                                mScreenShotListView.requestFocus();
                            }
                            maskScreenShotAppear();
                        }
                    }, 235);
                }else{
                    mGameInfoView.catchFocus();
                    maskScreenShotAppear();
                }
                return true;
            }
        }

        if(KeyEvent.KEYCODE_BACK == event.getKeyCode()){
            if(contentLayout.needScrollUp()){
                contentLayout.smoothScrollBy(Y_DISTANCE, 250);
                titleBar.setAlpha(1.0f);
                mGameInfoView.catchFocus();
                maskScreenShotAppear();
                return true;
            }
        }

        return false;
    }


    @Override
    public void onImageChanged(ImageView view) {
        if(view != null && view.getDrawable() != null){
            if(TextUtils.isEmpty(mGameInfo.data.get(0).id)){
                return;
            }

            final String url = mGameInfo.data.get(0).images.icon().url;
            if(url.equals(mIcon) == false){//减少虚化icon次数
                VolleyHelper.getInstance(getBaseContext()).getImageLoader().get(url, new ImageLoader.ImageListener() {
                    @Override
                    public void onResponse(ImageLoader.ImageContainer response, boolean isImmediate) {

                        Bitmap tmp = response.getBitmap();
                        Bitmap bmpIn  = ImageUtils.clipBitmap(getBaseContext(), tmp);//ImageUtils.clipBitmap(getBaseContext(), DiskBasedCache.getFilenameForKey(ImageLoader.getCacheKey(url, 0, 0)));
                        if(bmpIn == null){
                            bmpIn = Bitmap.createBitmap(tmp, 10, 10, tmp.getWidth()-20, tmp.getHeight()-20);
                        }
                        if(bmpIn != null){
                            mIcon = url;
                            mIconBitmap = ImageUtils.fastblur(bmpIn, ImageUtils.FASTBLUR_FACTOR);
                            if(mIconBitmap != null && mRootView !=null){

                                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
                                    mRootView.setBackground(new BitmapDrawable(getResources(),mIconBitmap));
                                else
                                    mRootView.setBackgroundDrawable(new BitmapDrawable(getResources(),mIconBitmap));
                            }else if(!bmpIn.isRecycled()){
                                bmpIn.recycle();
                            }
                        }
                        bmpIn = null;
                    }

                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
            }
        }
    }

    //快速消失
    protected void maskScreenShotDisappear(){
        if(mScreenShotMaskLeftView!= null && mScreenShotMaskRightView!= null){
            mScreenShotMaskLeftView.setAlpha(0.0f);
            mScreenShotMaskRightView.setAlpha(0.0f);
        }
    }

    //快速消失
    protected void maskScreenShotQuickAppear(){
        if(mScreenShotMaskLeftView != null && mScreenShotMaskRightView != null){
            mScreenShotMaskLeftView.setAlpha(1.0f);
            mScreenShotMaskRightView.setAlpha(1.0f);
        }
    }

    //缓慢出现
    protected void maskScreenShotAppear(){
        if(mScreenShotMaskLeftView != null && mScreenShotMaskRightView != null){
            ObjectAnimator ol = ObjectAnimator.ofFloat(mScreenShotMaskLeftView, "alpha", 1.0f);
            ObjectAnimator or = ObjectAnimator.ofFloat(mScreenShotMaskRightView, "alpha", 1.0f);
            AnimatorSet lineAnimator = new AnimatorSet();
            lineAnimator.playTogether(ol, or);
            lineAnimator.setDuration(300);
            lineAnimator.start();
        }
    }
}
