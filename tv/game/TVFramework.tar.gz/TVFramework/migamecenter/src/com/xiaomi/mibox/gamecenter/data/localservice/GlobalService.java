package com.xiaomi.mibox.gamecenter.data.localservice;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Pair;


/**
 * 具备多个功能入口的Service，一般为后台自动任务
 * 1.单线程
 * 2.一个Entry干一件事，如果一个Action有多个任务处理就多定义几个Entry，PACKAGE变化事件除外
 * @author smokelee
 *
 */
public class GlobalService extends Service 
{
	public static final String ACTION_DOWNLOAD_COMPELTE = "android.intent.action.DOWNLOAD_COMPLETE";
	private ExecutorService mExecutor;
	private static ArrayList<Pair<String, Class<? extends ServiceEntry>>> mEntryHandler;
	static{
		mEntryHandler = new ArrayList<Pair<String,Class<? extends ServiceEntry>>>();
		mEntryHandler.add(new Pair<String, Class<? extends ServiceEntry>>(ACTION_DOWNLOAD_COMPELTE, DownloadCompeleteEntry.class));
		mEntryHandler.add(new Pair<String, Class<? extends ServiceEntry>>(Intent.ACTION_PACKAGE_ADDED, PackageEntry.class));
		mEntryHandler.add(new Pair<String, Class<? extends ServiceEntry>>(Intent.ACTION_PACKAGE_REPLACED, PackageEntry.class));
		mEntryHandler.add(new Pair<String, Class<? extends ServiceEntry>>(Intent.ACTION_PACKAGE_REMOVED, PackageEntry.class));
	}
	
	@Override
	public void onCreate() {
		mExecutor = Executors.newSingleThreadExecutor();
		super.onCreate();
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null){
            return Service.START_NOT_STICKY;
        }
        if (TextUtils.isEmpty(intent.getAction())){
            return Service.START_NOT_STICKY;
        }
		try {
			action_filter(intent);
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.stopSelf();
		return Service.START_NOT_STICKY;
	}
	
	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}
	
	private void action_filter(Intent intent)
	{
		for(Pair<String, Class<? extends ServiceEntry>> e : mEntryHandler)
		{
			if(e.first.equals(intent.getAction()))
			{
				Class<? extends ServiceEntry> cls = e.second;
				try {
					Constructor<? extends ServiceEntry> cts = cls.getConstructor(Intent.class, Context.class);
					ServiceEntry se = cts.newInstance(intent, this);
					mExecutor.execute(se);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
	}
}
