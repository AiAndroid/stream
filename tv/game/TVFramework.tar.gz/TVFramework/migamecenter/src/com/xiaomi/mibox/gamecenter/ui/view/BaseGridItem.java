package com.xiaomi.mibox.gamecenter.ui.view;

import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import com.android.volley.toolbox.VolleyHelper;
import com.tv.ui.metro.model.DisplayItem;
import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.data.LocalAppManager;
import com.xiaomi.mibox.gamecenter.data.download.DownloadObserver;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationStatus;
import com.xiaomi.mibox.gamecenter.data.LocalAppInfo;
import com.xiaomi.mibox.gamecenter.data.OperateDevice;
import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;
import android.content.Context;
import android.graphics.RectF;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;


/**
 * 基本游戏Item 
 * @author zhaotao
 */
public class BaseGridItem extends RelativeLayout{
	private static final String TAG="BaseGridItem";
	private GameItem mGameInfo;
	
	private ImageView mGameIcon; //游戏图标
	
	private ImageView mGameHandle;  //游戏手柄状态
	
	private ImageView mGameStatus; //更新状态
	
	private TextView mGameName;  //游戏名称
	
	private SummaryView mSizeDownLayout;//游戏包的大小下载量的信息
	private TextView mGameSummary;  //游戏简介
	
	private ProgressBar mProgressBar;
	
	private DownloadObserverImpl mObserver;
	
	private int mItemType = 0;
	
	public static final int ITEM_TYPE_DEFAULT = 0;
	public static final int ITEM_TYPE_SUBJECT = 1;
	public static final int ITEM_TYPE_DETAIL = 2;
	
	private RectF mRect;

    public BaseGridItem(Context context, AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);
        initViews(context);
        mRect = new RectF();
    }
    public BaseGridItem(Context context, AttributeSet as) {
        this(context,as, 0);
    }

	public BaseGridItem(Context context) {
		this(context, null, 0);

	}
	
	private void initViews(Context ctx){
		View viewRoot = LayoutInflater.from(ctx).inflate(R.layout.base_grid_item, null);

		mGameIcon = (ImageView) viewRoot.findViewById(R.id.game_item_icon);
		mGameHandle = (ImageView) viewRoot.findViewById(R.id.game_item_handle);
		mGameStatus = (ImageView) viewRoot.findViewById(R.id.game_item_status);

		mGameName = (TextView) viewRoot.findViewById(R.id.game_item_name);
		mProgressBar = (ProgressBar)viewRoot.findViewById(R.id.game_item_downloading_progressbar);

        //should in linear layout
		mGameSummary = (TextView) viewRoot.findViewById(R.id.game_item_summary);
		mSizeDownLayout = (SummaryView) viewRoot.findViewById(R.id.game_item_size);

        addView(viewRoot);
	}
	
	public GameItem data(){
	    return mGameInfo;
	}
	
	/**
	 * 绑定数据 必须要设置item类型 
	 * @param info
	 * @param type
	 */
	public void bind(GameItem info, int type){
		mGameInfo = info;
		mItemType = type;
		if (mGameInfo == null) {
            if (mObserver != null) {
                mObserver.release();
            }
            return;
        }
        if (mObserver == null) {
            mObserver = new DownloadObserverImpl(getContext(), mGameInfo);
        }
        mObserver.setGameId((GameItem)mGameInfo);
		updateViews(((GameItem)mGameInfo), type);
	}
	
	private void updateViews(GameItem info, int type){
		if(info == null) return;

        VolleyHelper.getInstance(getContext()).getImageLoader().get(info.images.icon().url,  com.android.volley.toolbox.ImageLoader.getImageListener(mGameIcon, R.drawable.icon_default_app, R.drawable.icon_default_app));
        if(info.flags != null)
		    updateGameHandle(info.flags.operate_device);
        else
            Log.e(TAG, "why have no flags");

		updateGameStatus(info);
		mGameName.setText(info.name);
		updateSummary(type, info);
	}
	
	private void updateSummary(int type, GameItem info){
		if(type == ITEM_TYPE_DEFAULT || ITEM_TYPE_DETAIL == type){
			mGameSummary.setVisibility(View.GONE);
	        long size = Integer.valueOf(info.sizes.packaged);
            if(info.assets != null){
                for(GameItem.Assets item: info.assets){
                    size += item.size;
                }
            }

//	        AssetList assertList = info.sizes.data;
//	        if(assertList != null){
//	            size = assertList.getAssetSize();
//	        }
			String sizeText = GamecenterUtils.getByteString(size, "%.2f", getContext());
			mSizeDownLayout.setSizeText(sizeText);
			mSizeDownLayout.setDownloadCountText(getResources().getString(
					R.string.format_download_count, info.counts.download));
//			String download_count = getResources().getString(R.string.item_game_downloadcount, info.downloadCount);
//			mGameSummary.setText(Html.fromHtml(size + download_count));	
		}else if(type == ITEM_TYPE_SUBJECT){
			mSizeDownLayout.setVisibility(View.GONE);
			mGameSummary.setText(info.phrase);
		}
		
		if(ITEM_TYPE_DETAIL == type){
		    mGameSummary.setVisibility(View.GONE);
		    mSizeDownLayout.setVisibility(View.VISIBLE);
		}
	}
	
	private void updateGameStatus(GameItem info){
		int local_version = Integer.valueOf(info.ver.code);
		if(LocalAppManager.getManager().isInstalled(info.packagename)){
			LocalAppInfo appInfo = LocalAppManager.getManager().getLocalAppInfo(
					info.packagename);
			if(appInfo != null){
				local_version = appInfo.mVersionCode;
			}
		} 
		
		if(Integer.valueOf(info.ver.code) > local_version){
			mGameHandle.setVisibility(View.GONE);
			mGameStatus.setVisibility(View.VISIBLE);
		} else {
			mGameHandle.setVisibility(View.VISIBLE);
			mGameStatus.setVisibility(View.GONE);
		}
	}
	
	private void updateGameHandle(int type){
		switch(type){
		case OperateDevice.OperateDeviceMouse:{
			mGameHandle.setImageResource(R.drawable.operator_mouse);
			break;
		}
		case OperateDevice.OperateDeviceController:{
			mGameHandle.setImageResource(R.drawable.operator_controller);
			break;
		}
		
		case OperateDevice.OperateDeviceHandler:{
			mGameHandle.setImageResource(R.drawable.operator_handler);
			break;
		}
		default:{
			mGameHandle.setImageResource(R.drawable.operator_controller);
			break;
		}
		}
	}
	
	@Override
	public void setSelected(boolean selected) {
		super.setSelected(selected);
		if(ITEM_TYPE_SUBJECT == mItemType){
			if(selected){
				mGameSummary.setVisibility(View.VISIBLE);
			}else {
				mGameSummary.setVisibility(View.GONE);
			}
		}else{
			if(selected){
				mSizeDownLayout.setVisibility(View.VISIBLE);
			}else {
				mSizeDownLayout.setVisibility(View.GONE);
			}
		}
	}

	public void setProgress(int progress){
		if(mProgressBar != null){
			mProgressBar.setProgress(progress);	
		}
	}
	
/*	public void onItemClick(){
		Intent intent = new Intent(getContext(), GameDetailActivity.class);
		intent.putExtra(Constants.GAME_ID, mGameInfo.gameId);
		getContext().startActivity(intent);
	}*/
	
	public void setRect(float l, float t, float r, float b){
		mRect.left = l;
		mRect.top = t;
		mRect.right = r;
		mRect.bottom = b;
	}
	
	private class DownloadObserverImpl extends DownloadObserver {

        public DownloadObserverImpl(Context ctx, DisplayItem game) {
            super(ctx, game);
        }

        @Override
        protected void onDownloadStatusChange(int gameId,
                OperationSession session) {
            if (null == mGameInfo) {
                return;
            }
            if (session == null) {
                return;
            }
            if (session.getStatus() == OperationStatus.DownloadQueue) {
//                updateProgressPending(mGameInfo);
            } else if (session.getStatus() == OperationStatus.Downloading) {
                updateProgressDownloading(calc_progress(session));
            } else if (session.getStatus() == OperationStatus.DownloadPause) {
            	bindInstalled();
//                updateProgressPaused(session);
            } else if (session.getStatus() == OperationStatus.DownloadFail) {
            	bindInstalled();
                //下载失败 Google原生的系统是有个超时机制，这样网络不好的情况下就会下载失败，此时可以进入下载管理器点击重新下载
                //看不到下载管理器的话。。。用户只能另点一个游戏下载，然后在通知栏进入下载管理器
//                updateProgressPaused(session);
            } else if (session.getStatus() == OperationStatus.DownloadSuccess) {
                // TODO 下载完成

            } else if (session.getStatus() == OperationStatus.InstallQueue) {
//                updateProgressInstalling(mGameInfo);
            }
            // zwb s
            else if (session.getStatus() == OperationStatus.Unzipping) {
//                updateProgressUnzipping(session.getRadio() + "");
                updateProgressInstalling();
            }
            // zwb e
            else if (session.getStatus() == OperationStatus.Installing) {
                updateProgressInstalling();
            } else if (session.getStatus() == OperationStatus.InstallPause) {
            	bindInstalled();
//                updateProgressPaused(session);
            } else if (session.getStatus() == OperationStatus.InstallNext) {
//                updateProgressInstalling(mGameInfo);
            } else if (session.getStatus() == OperationStatus.Uninstall) {
//                updateProgressReinstall(session);
            } else if (session.getStatus() == OperationStatus.Success) {
                bindInstalled();
            } else if (session.getStatus() == OperationStatus.Remove) {
//                update_Status();
            	bindInstalled();
            }
        }

        @Override
        protected void onPackageStatusChange() {
        	updateViews(mGameInfo, mItemType);
        }
    }
	
	private void updateProgressDownloading(int progress){
		mGameName.setVisibility(View.GONE);
		mProgressBar.setVisibility(View.VISIBLE);
		if(mProgressBar.isIndeterminate()){
		    mProgressBar.setIndeterminate(false);
		}
		mProgressBar.setProgress(progress);
	}
	
	
	private void updateProgressInstalling(){
		if(!mProgressBar.isShown()){
			mProgressBar.setVisibility(View.VISIBLE);
			mGameName.setVisibility(View.GONE);
		}
		mProgressBar.setIndeterminate(true);
	}
	
	private void bindInstalled(){
        if (mProgressBar.isIndeterminate()) {
            mProgressBar.setIndeterminate(false);
        }
        mGameName.setVisibility(View.VISIBLE);
        mProgressBar.setVisibility(View.GONE);
	}
	
	protected int calc_progress(OperationSession session) 
    {
        double r = session.getRecv();
        double t = session.getTotal();
        long percentage;
        if (r < 0 || t <= 0){
            percentage = 0;
        }else{
            percentage = Math.round(100 * r / t);
        }
        return (int) percentage;
    }
}

