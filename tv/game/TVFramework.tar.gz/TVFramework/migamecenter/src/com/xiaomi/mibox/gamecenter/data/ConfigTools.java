package com.xiaomi.mibox.gamecenter.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

public final class ConfigTools {
	
	private SharedPreferences mPref;
	private static ConfigTools sInstance;
	
	public static void init(Context ctx){
		sInstance = new ConfigTools(ctx);
	}
	
	public static ConfigTools getInstance(){
		return sInstance;
	}
	
	private ConfigTools(Context ctx)
	{
		mPref = PreferenceManager.getDefaultSharedPreferences(ctx);
	}
	
	public void setString(String key, String value)
	{
		Editor e = mPref.edit();
		e.putString(key, value);
		e.commit();
	}
	
	public void setInteger(String key, int value)
	{
		Editor e = mPref.edit();
		e.putInt(key, value);
		e.commit();
	}
	
	public void setBoolean(String key, boolean value)
	{
		Editor e = mPref.edit();
		e.putBoolean(key, value);
		e.commit();
	}
	
	public void setFloat(String key, float value)
	{
		Editor e = mPref.edit();
		e.putFloat(key, value);
		e.commit();
	}
	
	public void setLong(String key, long value)
	{
		Editor e = mPref.edit();
		e.putLong(key, value);
		e.commit();
	}
	
	public String getString(String key, String def)
	{
		return mPref.getString(key, def);
	}
	
	public int getInt(String key, int def)
	{
		return mPref.getInt(key, def);
	}

	public boolean getBoolean(String key, boolean def)
	{
		return mPref.getBoolean(key, def);
	}
	
	public float getFloat(String key, float def)
	{
		return mPref.getFloat(key, def);
	}
	
	public long getLong(String key, long def)
	{
		return mPref.getLong(key, def);
	}
	
	public void remove(String key)
	{
		Editor e = mPref.edit();
		e.remove(key);
		e.commit();
	}
}
