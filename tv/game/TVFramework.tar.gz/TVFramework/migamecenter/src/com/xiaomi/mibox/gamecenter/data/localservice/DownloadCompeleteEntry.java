package com.xiaomi.mibox.gamecenter.data.localservice;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;

public class DownloadCompeleteEntry extends ServiceEntry {

	public DownloadCompeleteEntry(Intent ii, Context ctx) {
		super(ii, ctx);
	}

	@Override
	public void run() {
		String action = intent.getAction();
        if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            if (id == -1) {
                return;
            }
            //只要系统启动起来就好，XMDownloadManager会根据结果自动开始安装
        } else {
        }
	}

}
