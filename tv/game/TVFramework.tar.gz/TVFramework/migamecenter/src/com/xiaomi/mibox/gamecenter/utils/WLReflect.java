package com.xiaomi.mibox.gamecenter.utils;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.Executor;

import com.xiaomi.mibox.gamecenter.data.IConfig;

import android.app.DownloadManager;
import android.content.ContentResolver;
import android.content.pm.IPackageDataObserver;
import android.content.pm.IPackageDeleteObserver;
import android.content.pm.IPackageInstallObserver;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.net.Uri;
import android.os.ResultReceiver;
import android.view.Display;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.DatePicker;
import android.widget.ListView;

/**
 * 反射方法调用系统未公开的API
 * @author ROBIN.LIU
 *
 */
public class WLReflect {
	
	public static final int INSTALL_FAILED_INSUFFICIENT_STORAGE = -4;//PackageManager隐藏的常量
	/**
	 * 
	 * @param pckManager
     * Install a package. Since this may take a little while, the result will
     * be posted back to the given observer.  An installation will fail if the calling context
     * lacks the {@link android.Manifest.permission#INSTALL_PACKAGES} permission, if the
     * package named in the package file's manifest is already installed, or if there's no space
     * available on the device.
     *
     * @param packageURI The location of the package file to install.  This can be a 'file:' or a
     * 'content:' URI.
     * @param observer An observer callback to get notified when the package installation is
     * complete. {@link IPackageInstallObserver#packageInstalled(String, int)} will be
     * called when that happens.  observer may be null to indicate that no callback is desired.
     * @param flags - possible values: {@link #INSTALL_FORWARD_LOCK},
     * {@link #INSTALL_REPLACE_EXISTING}, {@link #INSTALL_ALLOW_TEST}.
     * @param installerPackageName Optional package name of the application that is performing the
     * installation. This identifies which market the package came from.
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 * @throws NoSuchMethodException 
     */
	public static void installPackage(PackageManager pckManager,
            Uri packageURI, 
            IPackageInstallObserver observer, 
            int flags,
            String installerPackageName) 
            		throws IllegalArgumentException, 
            		IllegalAccessException, 
            		InvocationTargetException, 
            		NoSuchMethodException{
		Class<?>[] arrayOfClass = new Class[4];
	    arrayOfClass[0] = Uri.class;
	    arrayOfClass[1] = IPackageInstallObserver.class;
	    arrayOfClass[2] = int.class;
	    arrayOfClass[3] = String.class;
	    
	    Object[] arrayOfObject = new Object[4];
	    arrayOfObject[0] = packageURI;
	    arrayOfObject[1] = observer;
	    arrayOfObject[2] = flags;
	    arrayOfObject[3] = installerPackageName;
	    
		Method localMethod;
		localMethod = pckManager.getClass().getMethod(
				"installPackage", arrayOfClass);
		localMethod.setAccessible(true);
		localMethod.invoke(pckManager, arrayOfObject);
	}
	
    /**
     * Attempts to delete a package.  Since this may take a little while, the result will
     * be posted back to the given observer.  A deletion will fail if the calling context
     * lacks the {@link android.Manifest.permission#DELETE_PACKAGES} permission, if the
     * named package cannot be found, or if the named package is a "system package".
     * (TODO: include pointer to documentation on "system packages")
     *
     * @param packageName The name of the package to delete
     * @param observer An observer callback to get notified when the package deletion is
     * complete. {@link android.content.pm.IPackageDeleteObserver#packageDeleted(boolean)} will be
     * called when that happens.  observer may be null to indicate that no callback is desired.
     * @param flags - possible values: {@link #DONT_DELETE_DATA}
     *
     * @hide
     */
    public static boolean deletePackage(PackageManager pm,
            String packageName, IPackageDeleteObserver observer, int flags){
    	boolean success = false;
    	Class<?>[] arrayOfClass = new Class[3];
	    arrayOfClass[0] = String.class;
	    arrayOfClass[1] = IPackageDeleteObserver.class;
	    arrayOfClass[2] = int.class;
	    
	    Object[] arrayOfObject = new Object[3];
	    arrayOfObject[0] = packageName;
	    arrayOfObject[1] = observer;
	    arrayOfObject[2] = flags;
	    
		Method localMethod;
		try {
			localMethod = pm.getClass().getMethod(
					"deletePackage", arrayOfClass);
			localMethod.setAccessible(true);
			localMethod.invoke(pm, arrayOfObject);
			success = true;
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
    	return success;
    }
	
    /**
     * Retrieve the size information for a package.
     * Since this may take a little while, the result will
     * be posted back to the given observer.  The calling context
     * should have the {@link android.Manifest.permission#GET_PACKAGE_SIZE} permission.
     *
     * @param packageName The name of the package whose size information is to be retrieved
     * @param observer An observer callback to get notified when the operation
     * is complete.
     * {@link android.content.pm.IPackageStatsObserver#onGetStatsCompleted(PackageStats, boolean)}
     * The observer's callback is invoked with a PackageStats object(containing the
     * code, data and cache sizes of the package) and a boolean value representing
     * the status of the operation. observer may be null to indicate that
     * no callback is desired.
     *
     * @hide
     */
    public static void getPackageSizeInfo(PackageManager pm, String packageName,
            IPackageStatsObserver observer){
    	Class<?>[] arrayOfClass = new Class[2];
	    arrayOfClass[0] = String.class;
	    arrayOfClass[1] = IPackageStatsObserver.class;
	    
	    Object[] arrayOfObject = new Object[2];
	    arrayOfObject[0] = packageName;
	    arrayOfObject[1] = observer;
	    
		Method localMethod;
		try {
			localMethod = pm.getClass().getMethod(
					"getPackageSizeInfo", arrayOfClass);
			localMethod.setAccessible(true);
			localMethod.invoke(pm, arrayOfObject);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

    }
    
    /**
     * Attempts to delete the cache files associated with an application.
     * Since this may take a little while, the result will
     * be posted back to the given observer.  A deletion will fail if the calling context
     * lacks the {@link android.Manifest.permission#DELETE_CACHE_FILES} permission, if the
     * named package cannot be found, or if the named package is a "system package".
     *
     * @param packageName The name of the package to delete
     * @param observer An observer callback to get notified when the cache file deletion
     * is complete.
     * {@link android.content.pm.IPackageDataObserver#onRemoveCompleted(String, boolean)}
     * will be called when that happens.  observer may be null to indicate that
     * no callback is desired.
     *
     */
    public static boolean deleteApplicationCacheFiles(PackageManager pm,
    		String packageName,
            IPackageDataObserver observer){
    	boolean success = false;
    	Class<?>[] arrayOfClass = new Class[2];
	    arrayOfClass[0] = String.class;
	    arrayOfClass[1] = IPackageDataObserver.class;
	    
	    Object[] arrayOfObject = new Object[2];
	    arrayOfObject[0] = packageName;
	    arrayOfObject[1] = observer;
	    
		Method localMethod;
		try {
			localMethod = pm.getClass().getMethod(
					"deleteApplicationCacheFiles", arrayOfClass);
			localMethod.setAccessible(true);
			localMethod.invoke(pm, arrayOfObject);
			success = true;
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return success;
    }
	
	/**
	 * 
	 * @param exec
	 */
	public static void setDefaultExecutor() {
		Method localMethod;
		Class<?> sp;
		try {
			sp = Class.forName("android.os.AsyncTask");
			localMethod = sp.getMethod("setDefaultExecutor", Executor.class);
			localMethod.setAccessible(true);
			Field f = sp.getField("THREAD_POOL_EXECUTOR");
			f.setAccessible(true);
			Executor exec = (Executor)f.get(null);//静态变量?
			localMethod.invoke(null, exec);//静态方法为null
		} catch (ClassNotFoundException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (NoSuchMethodException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalArgumentException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalAccessException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (InvocationTargetException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (NoSuchFieldException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		}
	}
	
	/**
	 * 将输入法界面调出来
	 * @param inputManager
	 * @param flags
	 * @param resultReceiver
	 */
	public static void showSoftInputUnchecked(InputMethodManager inputManager,
			int flags, ResultReceiver resultReceiver){
		Class<?>[] arrayOfClass = new Class[2];
	    arrayOfClass[0] = int.class;
	    arrayOfClass[1] = ResultReceiver.class;
	    
	    Object[] arrayOfObject = new Object[2];
	    arrayOfObject[0] = 0;
	    arrayOfObject[1] = resultReceiver;
	    
		Method localMethod;
		try {
			localMethod = inputManager.getClass().getMethod(
					"showSoftInputUnchecked", arrayOfClass);
			localMethod.setAccessible(true);
			localMethod.invoke(inputManager, arrayOfObject);
		} catch (NoSuchMethodException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalArgumentException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalAccessException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (InvocationTargetException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * @param view
	 * @param left
	 * @param top
	 * @param right
	 * @param bottom
	 * @return
	 */
	public static boolean setFrame(View view, int left, int top, int right, int bottom) {
		Class<?>[] arrayOfClass = new Class[4];
	    arrayOfClass[0] = int.class;
	    arrayOfClass[1] = int.class;
	    arrayOfClass[2] = int.class;
	    arrayOfClass[3] = int.class;
	    
	    Object[] arrayOfObject = new Object[4];
	    arrayOfObject[0] = left;
	    arrayOfObject[1] = top;
	    arrayOfObject[2] = right;
	    arrayOfObject[3] = bottom;
	    
	    Method localMethod;
	    boolean ret = false;
		try {
			Class<?> cls = Class.forName("android.view.View");
			localMethod = cls.getDeclaredMethod(
					"setFrame", arrayOfClass);
			localMethod.setAccessible(true);
			ret = (Boolean)localMethod.invoke(view, arrayOfObject);
		} catch (NoSuchMethodException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalArgumentException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalAccessException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (InvocationTargetException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (ClassNotFoundException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		}
		return ret;
	}
	
	public static void setViewPrivateVar(View view, 
			String fieldName, int value){
		try {
			Class<?> cls = Class.forName("android.view.View");
			Field f = cls.getDeclaredField(fieldName);
			f.setAccessible(true);
			f.set(view, value);
		} catch (NoSuchFieldException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalArgumentException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalAccessException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (ClassNotFoundException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		}
	}
	
	public static int getViewPrivateVar(View view, 
			String fieldName){
		try {
			Class<?> cls = Class.forName("android.view.View");
			Field f = cls.getDeclaredField(fieldName);
			f.setAccessible(true);
			return (Integer)f.get(view);
		} catch (NoSuchFieldException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalArgumentException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalAccessException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (ClassNotFoundException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		}
		return -1;
	}
	
	/**
	 * 
	 * @param listView
	 * @param position
	 * @param offset
	 */
	public static void smoothScrollToPositionFromTop(ListView listView,
			int position, int offset){
		Class<?>[] arrayOfClass = new Class[2];
	    arrayOfClass[0] = int.class;
	    arrayOfClass[1] = int.class;
	    
	    Object[] arrayOfObject = new Object[2];
	    arrayOfObject[0] = position;
	    arrayOfObject[1] = offset;
		try {
			Method localMethod = listView.getClass().getMethod(
					"smoothScrollToPositionFromTop", 
					arrayOfClass);
			localMethod.invoke(listView, arrayOfObject);
		} catch (NoSuchMethodException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalArgumentException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalAccessException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (InvocationTargetException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		}
	}
	
	/**
	 * 清除selector区域
	 * @param listView
	 */
	public static void clearSelector(AbsListView listView){
		Class<?> cls;
		try {
			cls = Class.forName("android.widget.AbsListView");
			Field f = cls.getDeclaredField("mSelectorRect");
			f.setAccessible(true);
			Rect rect = new Rect(0, 0, 0, 0);
			f.set(listView, rect);
		} catch (ClassNotFoundException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (NoSuchFieldException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalArgumentException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		} catch (IllegalAccessException e) {
			if(IConfig.DEBUG) e.printStackTrace();
		}
	}
	
	public static void setCalendarViewShown(DatePicker d, boolean shown){
		Method localMethod;
		Class<?> sp;
		try {
			sp = Class.forName("android.widget.DatePicker");
			localMethod = sp.getMethod("setCalendarViewShown", boolean.class);
			localMethod.setAccessible(true);
			localMethod.invoke(d, shown);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
	}
	
	public static void setSpinnersShown(DatePicker d, boolean shown){
		Method localMethod;
		Class<?> sp;
		try {
			sp = Class.forName("android.widget.DatePicker");
			localMethod = sp.getMethod("setSpinnersShown", boolean.class);
			localMethod.setAccessible(true);
			localMethod.invoke(d, shown);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 其构造函数是HIDE 没办法只能用反射了
	 * @param resolver
	 * @param packageName
	 * @return
	 */
	public static DownloadManager createDownloadManager(ContentResolver resolver, 
			String packageName){
		DownloadManager downloadManager = null;
		try {
			Constructor<DownloadManager> construct = DownloadManager.class
					.getConstructor(ContentResolver.class, String.class);
			if (construct != null) {
				downloadManager = construct.newInstance(resolver, packageName);
			}
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

		return downloadManager;
	}
	
	public static int getRawWidth(Display display){
		int width = 0;
		try {
			Method m = display.getClass().getMethod("getRawWidth");
			width = (Integer)m.invoke(display);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return width;
	}
	
	public static int getRawHeight(Display display){
		int height = 0;
		try {
			Method m = display.getClass().getMethod("getRawHeight");
			height = (Integer)m.invoke(display);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return height;
	}
    /**
     * Like {@link #screenshot(int, int, int, int)} but includes all
     * Surfaces in the screenshot.
     *
     * @hide
     */
    public static Bitmap screenshot(int width, int height)
    {
    	Bitmap bitmap = null;
    	try {
    		Class<?>[] arrayOfClass = new Class[2];
    	    arrayOfClass[0] = int.class;
    	    arrayOfClass[1] = int.class;
    	    
    	    Object[] arrayOfObject = new Object[2];
    	    arrayOfObject[0] = width;
    	    arrayOfObject[1] = height;
    	    
			Class<?> surface = Class.forName("android.view.Surface");
			Method m = surface.getMethod("screenshot", arrayOfClass);
			bitmap = (Bitmap)m.invoke(null, arrayOfObject);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
    	
    	return bitmap;
    }
    
	/**
	 * 在miui v5系统中，(DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE); 返回的就是
	 * MiuiDownloadManager，但考虑到单发版的移植，故使用了反射的方法实现暂停下载。
	 * @param dm
	 * @param ids
	 */
	public static void pauseDownload(DownloadManager dm ,long[] ids){
		try {
			if(!dm.getClass().getName().equalsIgnoreCase("android.app.MiuiDownloadManager")){
				return;
			}
			Class<?> miuidownlaod = Class.forName("android.app.MiuiDownloadManager");
			Method pauseDownload = miuidownlaod.getMethod("pauseDownload", ids.getClass());
			pauseDownload.setAccessible(true);
			pauseDownload.invoke(dm, ids);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 在miui v5系统中，(DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE); 返回的就是
	 * MiuiDownloadManager，但考虑到单反版的移植，故使用了反射的方法实现恢复下载。
	 * @param dm
	 * @param ids
	 */
	public static void resumeDownload(DownloadManager dm ,long[] ids){
		try {
			if(!dm.getClass().getName().equalsIgnoreCase("android.app.MiuiDownloadManager")){
				return;
			}
			Class<?> miuidownlaod = Class.forName("android.app.MiuiDownloadManager");
			Method resumeDownload = miuidownlaod.getMethod("resumeDownload", ids.getClass());
			resumeDownload.setAccessible(true);
			resumeDownload.invoke(dm, ids);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
