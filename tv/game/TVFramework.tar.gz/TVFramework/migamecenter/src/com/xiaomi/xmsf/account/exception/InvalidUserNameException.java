package com.xiaomi.xmsf.account.exception;

public class InvalidUserNameException extends CloudServiceException {
    private static final long serialVersionUID = 1L;

    public InvalidUserNameException() {
        super("No such a user");
    }
}
