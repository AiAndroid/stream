package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import java.util.Collections;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.utils.Client;

import android.os.StatFs;
import android.util.Log;

public class AppStoreUtils {
	public static <E> ArrayList<E> newArrayList() {
		return new ArrayList<E>();
	}
	
    public static <E> ArrayList<E> newArrayList(E... elements) {
        int capacity = (elements.length * 110) / 100 + 5;
        ArrayList<E> list = new ArrayList<E>(capacity);
        Collections.addAll(list, elements);
        return list;
    }
    
    /**
     * 获取可用的空间
     * @return
     */
    public static long readSystemAvailableSize() {
    	String path = "/data"; 
    	StatFs sf = new StatFs(path);
    	long blockSize = 0;
    	if(Client.SDK_VERSION >= 18){
    		blockSize = getLong(sf, "getBlockSizeLong");//sf.getBlockSizeLong();
    	}else{
    		blockSize = sf.getBlockSize();
    	}
    	if(IConfig.DEBUG) Log.d("block size", "block size: " + blockSize);
    	long availCount = 0;
    	if(Client.SDK_VERSION >= 18){
    		availCount = getLong(sf, "getAvailableBlocksLong");//sf.getAvailableBlocksLong();
    	}else{
    		availCount = sf.getAvailableBlocks();
    	}
    	if(IConfig.DEBUG)Log.d("available count", "available count: " + availCount);
    	return blockSize * availCount;
    }
    
    private static long getLong(StatFs sf, String methodName){
    	long size = 0;
    	Method localMethod;
		try {
			localMethod = sf.getClass().getMethod(methodName);
			localMethod.setAccessible(true);
			size = (Long)localMethod.invoke(sf);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return size;
    }
}
