package com.xiaomi.xmsf.account.utils;

public class MetaLoginData {
    public final String sign;
    public final String qs;
    public final String callback;

    public MetaLoginData(String sign, String qs, String callback) {
        this.sign = sign;
        this.qs = qs;
        this.callback = callback;
    }
}