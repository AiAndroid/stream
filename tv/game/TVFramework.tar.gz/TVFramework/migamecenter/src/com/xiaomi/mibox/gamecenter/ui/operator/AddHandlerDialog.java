package com.xiaomi.mibox.gamecenter.ui.operator;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.data.MainHandler;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.bluetooth.BluetoothUtils;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothInputDevice;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.xiaomi.mitv.store.XiaomiUIHelper;

/**
 * 连接手柄过程的页面
 * 
 * @author liubiqiang
 * 
 */
public class AddHandlerDialog extends XiaomiUIHelper {

	private RelativeLayout mRootLayout;
	private TextView mHintTextView;
	private TextView mSmallHintTextView;
	private ImageView mRotateImageView;
	private ImageView mHintImageView;// 配对成功的提示符

	private ImageView mHandlerView;

	private Animation mRotateAnim;

	public static final String CONNECTED_BLUETOOTH_DEVICE = "bluetooth_device";
	private BluetoothDevice mBluetoothDevice;
	private BluetoothInputDevice mInput;
	private BluetoothAdapter mBluetoothAdapter;
	private BluetoothConnectingReceiver mBluetoothConnectingReceiver;
	private Handler handler = new Handler();
	private boolean mConnectedSuccess = false;
	private static final String TAG = "AddHandlerDialog";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setupViews();

		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (mBluetoothAdapter != null) {
			if(!mBluetoothAdapter.isEnabled()){
        		mBluetoothAdapter.enable();
        	}
			mBluetoothAdapter.getProfileProxy(this, mServiceListener,
					4);
		}
		registBluetoothReceiver();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (KeyEvent.KEYCODE_ENTER == keyCode
				|| KeyEvent.KEYCODE_DPAD_CENTER == keyCode
				|| KeyEvent.KEYCODE_BUTTON_A == keyCode) {// 连接成功后会自动退出的
			if (mConnectedSuccess) {
				return true;
			} else {
				BluetoothUtils.cancelDiscovering();
			}
		}
		return super.onKeyDown(keyCode, event);
	}

	private Runnable connectedSuccess = new Runnable() {
		@Override
		public void run() {
			if(IConfig.DEBUG) Log.e(TAG, "connected success");
			Intent intent = new Intent();
			intent.putExtra(CONNECTED_BLUETOOTH_DEVICE, mBluetoothDevice);
			setResult(RESULT_OK, intent);
			finish();
		}
	};

	@Override
	protected void onDestroy() {
		super.onDestroy();
		unRegistBluetoothReceiver();
		// 关闭接口
		if (mInput != null) {
			mBluetoothAdapter.closeProfileProxy(4,mInput);
		}
	}

	private void registBluetoothReceiver() {
		IntentFilter filter = new IntentFilter();
		filter.addAction(BluetoothInputDevice.ACTION_CONNECTION_STATE_CHANGED);
//		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
//		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
		filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
		filter.addAction(BluetoothDevice.ACTION_FOUND);
		filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);

		mBluetoothConnectingReceiver = new BluetoothConnectingReceiver();
		registerReceiver(mBluetoothConnectingReceiver, filter);
	}

	private void unRegistBluetoothReceiver() {
		if (mBluetoothConnectingReceiver != null) {
			try {
				unregisterReceiver(mBluetoothConnectingReceiver);
				mBluetoothConnectingReceiver = null;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private class BluetoothConnectingReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			if (null == intent) {
				return;
			}
			String action = intent.getAction();
			final BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
			if (null == device) {
				return;
			}

			if (BluetoothInputDevice.ACTION_CONNECTION_STATE_CHANGED.equals(action)) {
				int newState = intent.getIntExtra(BluetoothProfile.EXTRA_STATE,0);
				if (IConfig.DEBUG)Log.e(TAG, action + ":newState=" + newState);
				switch (newState) {
					case BluetoothProfile.STATE_CONNECTED: {
						if(WLUIUtils.isXiaomiBluetoothHandle(device)){
							handler.post(new Runnable() {
								@Override
								public void run() {
									viewStopANimation(mRotateImageView);
									mRotateImageView.setVisibility(View.GONE);
									mHintImageView.setVisibility(View.VISIBLE);
									mSmallHintTextView.setText(
											R.string.add_handler_small_hint_success);
								}
							});
							mBluetoothDevice = device;
							mConnectedSuccess = true;
							MainHandler.getInstance().postDelayed(connectedSuccess, 3000);
							if (IConfig.DEBUG)Log.e(TAG, "connected device:" + device.getName());
						}
						break;
					}
					case BluetoothProfile.STATE_CONNECTING: {
						if (IConfig.DEBUG) Log.e(TAG, "connecting device:" + device.getName());
						break;
					}
				}
			} else if (BluetoothDevice.ACTION_FOUND.equals(action)) {
				if (IConfig.DEBUG)Log.e(TAG, "find:" + action);
				String deviceName = device.getName();
				if (deviceName != null) {
					if (IConfig.DEBUG) Log.e(TAG, "action:" + deviceName);
					if (WLUIUtils.isXiaomiBluetoothHandle(device)) {
						if (mBluetoothAdapter.isDiscovering()) {
							mBluetoothAdapter.cancelDiscovery();
						}
						if (IConfig.DEBUG)Log.e(TAG, "find device:" + deviceName);
						handler.removeCallbacks(timeOut);
						handler.post(new Runnable() {
							@Override
							public void run() {
								mHintTextView.setText(getString(
										R.string.add_handler_hint_searched,
										device.getName()));
								mSmallHintTextView.setText(
										R.string.add_handler_small_hint_matching);
							}
						});
						int bondState = device.getBondState();
						if (IConfig.DEBUG)Log.e(TAG, "find device:" + bondState);
						if (BluetoothDevice.BOND_NONE == bondState) {
							BluetoothUtils.createBond(mInput, device);
						} else if (BluetoothDevice.BOND_BONDED == bondState) {
							handler.post(new Runnable() {
								@Override
								public void run() {
									mSmallHintTextView
											.setText(R.string.add_handler_small_hint_match);
								}
							});
							BluetoothUtils.connectDevice(mInput, device);
						}
					}
				}
			} else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)) {
				if (IConfig.DEBUG)Log.e(TAG, "action:" + device.getBondState());
				switch (device.getBondState()) {
					case BluetoothDevice.BOND_NONE:
						break;
					case BluetoothDevice.BOND_BONDING:
						break;
                    case 13://BluetoothDevice.BOND_SUCCESS:
						break;
					case BluetoothDevice.BOND_BONDED: {
						if (WLUIUtils.isXiaomiBluetoothHandle(device)) {
							handler.post(new Runnable() {
								@Override
								public void run() {
									mSmallHintTextView.setText(
											R.string.add_handler_small_hint_match);
								}
							});
							BluetoothUtils.connectDevice(mInput, device);
						}
						break;
					}
				}
			}
		}
	};

	// 搜索时间到
	private Runnable timeOut = new Runnable() {
		@Override
		public void run() {
			if(IConfig.DEBUG) Log.e(TAG, "timeOut");
			BluetoothUtils.cancelDiscovering();
			finish();
		}
	};

	private BluetoothProfile.ServiceListener mServiceListener = new BluetoothProfile.ServiceListener() {
		@Override
		public void onServiceConnected(int profile, BluetoothProfile proxy) {
			synchronized (this) {
				switch (profile) {
					case 4: {
						if (proxy instanceof BluetoothInputDevice) {
							mInput = (BluetoothInputDevice) proxy;
	
							BluetoothUtils.startDiscovering();
							viewStartAnimation(mRotateImageView);
							handler.postDelayed(timeOut, 15 * 1000);// 15s
						}
						break;
					}
				}
			}
		}

		@Override
		public void onServiceDisconnected(int profile) {
			synchronized (this) {
				switch (profile) {
					case 4: {
						mInput = null;
						break;
					}
				}
			}
		}
	};

	public void viewStartAnimation(View view) {
		if (mRotateAnim == null) {
			mRotateAnim = new RotateAnimation(0f, 360f,
					Animation.RELATIVE_TO_SELF, 0.5f,
					Animation.RELATIVE_TO_SELF, 0.5f);
			mRotateAnim.setInterpolator(new LinearInterpolator());
			mRotateAnim.setRepeatCount(Animation.INFINITE);
			mRotateAnim.setDuration(800);
		}
		view.startAnimation(mRotateAnim);
	}

	public void viewStopANimation(View view) {
		if (mRotateAnim != null) {
			view.clearAnimation();
			mRotateAnim = null;
		}
	}

	private void setupViews() {
        this.setContentView(R.layout.add_handler_dialog_layout);
		mRootLayout = (RelativeLayout) this.findViewById(R.id.add_handler_container);

		mHintTextView = (TextView) this.findViewById(R.id.add_handler_hint);
		mHintTextView.getPaint().setFakeBoldText(false);

        mRotateImageView   = (ImageView) this.findViewById(R.id.rotate_imageview);
        mHintImageView     = (ImageView) this.findViewById(R.id.hint_image_view);
		mSmallHintTextView = (TextView) this.findViewById(R.id.small_hint_textview);
        mHandlerView       = (ImageView) this.findViewById(R.id.handler_view);
	}
}
