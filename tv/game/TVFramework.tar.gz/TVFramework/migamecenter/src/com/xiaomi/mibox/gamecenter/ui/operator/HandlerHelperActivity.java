package com.xiaomi.mibox.gamecenter.ui.operator;

import java.util.ArrayList;

import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.data.MainHandler;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.bluetooth.BluetoothReceiver;
import com.xiaomi.mibox.gamecenter.bluetooth.HandlerCheck;
import com.xiaomi.mibox.gamecenter.bluetooth.OnBluetoothHandlerListener;
import com.xiaomi.mibox.gamecenter.bluetooth.OnFindHanlderCallback;
import com.xiaomi.mibox.gamecenter.data.statics.Report;
import com.xiaomi.mibox.gamecenter.data.statics.ReportManager;
import com.xiaomi.mibox.gamecenter.data.statics.Report.ReportType;
import com.xiaomi.mibox.gamecenter.ui.PictureActivity;
import com.xiaomi.mibox.gamecenter.ui.view.MineScaleFocusedView;
import com.xiaomi.mibox.gamecenter.ui.view.MineView;
import com.xiaomi.mibox.gamecenter.utils.DrawableCache;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;
import com.xiaomi.mibox.gamecenter.ui.view.MirrorView;
import com.xiaomi.mitv.app.view.TitleBar;
import com.xiaomi.mitv.store.XiaomiUIHelper;

/**
 * 手柄助手页面
 * @author liubiqiang
 *
 */
public class HandlerHelperActivity extends XiaomiUIHelper
    implements OnFindHanlderCallback, OnBluetoothHandlerListener {

    private RelativeLayout mRootView;
    private LinearLayout mContentLayout;
    private LinearLayout mContentContainer;
    private MineScaleFocusedView mFocusedView;
    
//    private MineView mAddHandlerView;
    private MineView mConnectedHandlerView;
    private MineView mBuyHandlerView;
    
    private MineView mCurrentSelectedView;
    
    private Object mSyncObject = new Object();
    private int mCurrPos;
    private long mLastProcessTime;
    private SparseArray<MineView> mViewLists = new SparseArray<MineView>(3);
    
    private Object mHandlerObject = new Object();
    private ArrayList<String> mHandlerList = new ArrayList<String>(8);
    private BluetoothReceiver mBlueReceiver;
    private IntentFilter mBluetoothIntentFilter;
    
    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setupView();
        
        mBlueReceiver = new BluetoothReceiver(this);
        mBluetoothIntentFilter = new IntentFilter(/*BluetoothInputDevice.ACTION_HID_INFO*/"android.bluetooth.input.profile.action.HID_INFO");
        mBluetoothIntentFilter.addAction("android.bluetooth.input.profile.action.CONNECTION_STATE_CHANGED"/*BluetoothInputDevice.ACTION_CONNECTION_STATE_CHANGED*/);
    }
   
	@Override
	public void onStart() {
		super.onStart();
		synchronized (mHandlerObject) {
			mHandlerList.clear();
		}
		new HandlerCheck(this, this);
		try {
			this.registerReceiver(mBlueReceiver, mBluetoothIntentFilter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

    @Override
    public void onStop() {
        super.onStop();
        if(mBlueReceiver != null){
            try{
                this.unregisterReceiver(mBlueReceiver);
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    private void setCurrentView(int pos) {
        MineView currentSelectedView = currentView(pos);
        if (null == currentSelectedView || null == mFocusedView) {
            return;
        }

        mFocusedView.setVisibility(View.VISIBLE);
        mCurrentSelectedView = currentSelectedView;
        mFocusedView.setFocusView(mCurrentSelectedView,mCurrPos);
    }
    
    private void onClick(){
        Intent intent = null;
        if(0 == mCurrPos){
            intent = new Intent(this, HandlerMangeActivity.class);
			ReportManager.getInstance().send(
					Report.createReport(ReportType.STATISTICS, null, null), 
					Report.MAIN_ACTION, "connection");
        }else if(1 == mCurrPos){
            intent = new Intent(this, PictureActivity.class);
            intent.putExtra(PictureActivity.INFO, 
                    PictureActivity.PURCHASE_HANDLER_URL);
            
			ReportManager.getInstance().send(
					Report.createReport(ReportType.STATISTICS, null, null), 
					Report.MAIN_ACTION, "buy");
        }
        
        if(intent != null){
            startActivity(intent);
            if(IConfig.DEBUG) Log.e("HandlerHelperActivity", "start buy handler");
        }
    }
    
    private OnFocusChangeListener mFocusChangeListener = new OnFocusChangeListener() {
        
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if (hasFocus) {
                synchronized (mSyncObject) {
                    if(mCurrentSelectedView != null){
                        mFocusedView.setVisibility(View.VISIBLE);
                    }else{
                        setCurrentView(mCurrPos);
                    }
                }
            } else {
                if(mFocusedView != null){
                    mFocusedView.setVisibility(View.INVISIBLE);
                }
            }
        }
    };
    
    private View.OnKeyListener mOnKeyListener = new View.OnKeyListener() {
        @Override
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if (KeyEvent.ACTION_DOWN == event.getAction()) {
                if (KeyEvent.KEYCODE_DPAD_RIGHT == keyCode) {
                    synchronized (mSyncObject) {
                        if (mCurrPos < mViewLists.size() - 1) {
                            mCurrPos++;
                            setCurrentView(mCurrPos);
                            WLUIUtils.playSoundEffect(currentView(mCurrPos), keyCode);
                        }else{
                            WLUIUtils.playSoundEffect(currentView(mCurrPos), -1);
                        }
                    }
                    return true;
                }

                if (KeyEvent.KEYCODE_DPAD_LEFT == keyCode) {
                    synchronized (mSyncObject) {
                        if (mCurrPos > 0) {
                            mCurrPos--;
                            setCurrentView(mCurrPos);
                            WLUIUtils.playSoundEffect(currentView(mCurrPos), keyCode);
                            return true;
                        }else{
                            WLUIUtils.playSoundEffect(currentView(mCurrPos), -1);
                            return true;
                        }
                    }
                }

                if (KeyEvent.KEYCODE_ENTER == keyCode
                        || KeyEvent.KEYCODE_DPAD_CENTER == keyCode
                        || KeyEvent.KEYCODE_BUTTON_A == keyCode) {// A键=遥控器的确定
                    long currTime = System.currentTimeMillis();
                    if (Math.abs(mLastProcessTime - currTime) < 500) {
                        return true;
                    }
                    mLastProcessTime = currTime;
                    WLUIUtils.playSoundEffect(currentView(mCurrPos), keyCode);
                    onClick();
                    return true;
                }
            }
            return false;
        }
    };
    
    /**
     * @param pos
     * @return
     */
    private MineView currentView(int pos) {
        MineView currentView = mViewLists.get(pos);
        return currentView;
    }
    
    private void setupView(){

        this.setContentView(R.layout.handler_help_layout);
        int key = 0;
        mRootView = (RelativeLayout) this.findViewById(R.id.handler_help_container);

        TitleBar titleBar = (TitleBar) this.findViewById(R.id.handler_help_title_bar);
        titleBar.setTitle(R.string.mine_info_handle_manager_title);
        
        mContentLayout = new LinearLayout(this);

        mContentContainer = (LinearLayout) this.findViewById(R.id.handler_help_container_layout);
        mContentContainer.setOnKeyListener(mOnKeyListener);
        mContentContainer.setOnFocusChangeListener(mFocusChangeListener);

        
        mConnectedHandlerView = (MineView) this.findViewById(R.id.handler_help_mine_view);
        mConnectedHandlerView.setItemTitle(R.string.handler_connect_title);
        mConnectedHandlerView.setItemSummary(R.string.handle_connect_none);
        mViewLists.put(key, mConnectedHandlerView);
        key++;
        
        mBuyHandlerView = (MineView) this.findViewById(R.id.handler_help_mine_view_buy);
        mBuyHandlerView.setItemTitle(R.string.buy_handler_title);
        mBuyHandlerView.setItemSummary(R.string.buy_handler_summary);
        mViewLists.put(key, mBuyHandlerView);
        key++;
        
        //Mirror
        MirrorView mirrorView = (MirrorView) this.findViewById(R.id.mirror_view);
        mConnectedHandlerView.setMirrorView(mirrorView);
        mConnectedHandlerView.setBackground(DrawableCache.getInstance().loadByResId(R.drawable.mine_handler));
        
        mirrorView = (MirrorView) this.findViewById(R.id.mirror_second_view);
        mBuyHandlerView.setMirrorView(mirrorView);
        mBuyHandlerView.setBackground(DrawableCache.getInstance().loadByResId(R.drawable.buy_handler));
        
        mFocusedView = (MineScaleFocusedView) this.findViewById(R.id.handler_help_focus_view);
    }

    @Override
    public void findNewHandlerDevice(String address) {
        synchronized(mHandlerObject){
            if(!mHandlerList.contains(address)){
                mHandlerList.add(address);
            }
        }
    }

    @Override
    public void onFinishedFind() {
        refreshList();
    }
    
    private void refreshList(){
        MainHandler.getInstance().post(new Runnable(){
            @Override
            public void run() {
                int connectedHanlderNum = 0;
                synchronized(mHandlerObject){
                    connectedHanlderNum = mHandlerList.size();
                }
                
                MineView connectView = mViewLists.get(0);
                if(null == connectView){
                    return;
                }
                if(0 == connectedHanlderNum){
                    connectView.setItemSummary(R.string.handle_connect_none);
                }else{
                    connectView.setItemSummary(
                            getString(R.string.connected_handler_summary_format,
                                    connectedHanlderNum));
                }
                if(mFocusedView.getVisibility() == View.VISIBLE){
                    if(mFocusedView.focusedView() == mConnectedHandlerView){
                        mFocusedView.invalidate();
                    }
                }
            }
        });
    }

    @Override
    public void connected(BluetoothDevice device) {
    	String address = null;
    	if(device != null){
    		address = device.getAddress();
    	}
    	if(TextUtils.isEmpty(address)){
    		return;
    	}
        synchronized(mHandlerObject){
            if(!mHandlerList.contains(address)){
                mHandlerList.add(address);
                refreshList();
            }
        }
    }

    @Override
    public void disconnected(BluetoothDevice device) {
    	String address = null;
    	if(device != null){
    		address = device.getAddress();
    	}
    	if(TextUtils.isEmpty(address)){
    		return;
    	}
        synchronized(mHandlerObject){
            if(mHandlerList.remove(address)){
                refreshList();
            }
        }
    }
}
