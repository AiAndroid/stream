package com.xiaomi.mitv.store.game;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.VolleyHelper;
import com.tv.ui.metro.model.DisplayItem;
import com.tv.ui.metro.model.GameItem;
import com.tv.ui.metro.model.GenericAlbum;
import com.tv.ui.metro.model.GenericSubjectItem;
import com.tv.ui.metro.view.EmptyLoadingView;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.data.statics.Report;
import com.xiaomi.mibox.gamecenter.data.statics.ReportManager;
import com.xiaomi.mibox.gamecenter.data.statics.StaticsType;
import com.xiaomi.mibox.gamecenter.data.statics.Report.ReportType;
import com.xiaomi.mibox.gamecenter.ui.IExtraIntent;
import com.xiaomi.mibox.gamecenter.ui.OnLoaderControl;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mibox.gamecenter.utils.ViewUtils;
import com.xiaomi.mibox.gamecenter.ui.view.BaseGridItem;
import com.xiaomi.mibox.gamecenter.ui.view.BaseScrollView;
import com.xiaomi.mibox.gamecenter.ui.view.BaseScrollView.OnBaseScrollListener;
import com.xiaomi.mitv.app.view.TitleBar;
import com.xiaomi.mitv.store.XiaomiUIHelper;
import com.xiaomi.mitv.store.network.GenericSubjectLoader;

public class SubjectActivity extends XiaomiUIHelper implements LoaderManager.LoaderCallbacks<GenericSubjectItem<GameItem>>, OnBaseScrollListener, OnLoaderControl {

	private GenericSubjectLoader<GameItem> mLoader;

	
	private String mSubjectId;
	private String mSubjectName;
	private EmptyLoadingView mLoadingView;
	private RelativeLayout mRootView;
	private ImageView mBgPicView;
	private ImageView mBigPicView;
	private ImageView mFuzzyPicView;
	private BaseScrollView mScrollView;
	private TitleBar mTitleBar;
	
	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);

        setContentView(R.layout.subject_layout);
        mRootView = (RelativeLayout) this.findViewById(R.id.subject_container);
        mBgPicView = (ImageView)mRootView.findViewById(R.id.big_pic_bg);

        mBigPicView = (ImageView) this.findViewById(R.id.big_pic);
        mFuzzyPicView = (ImageView) this.findViewById(R.id.fuzzy_pic);

        mScrollView = (BaseScrollView) this.findViewById(R.id.subject_base_scrollview);
        mScrollView.setOnLoaderControl(this);
        mScrollView.setOnBaseScrollListener(this);

        if(item.type.equalsIgnoreCase("category")){
            mBgPicView.setVisibility(View.GONE);
            mBigPicView.setVisibility(View.GONE);
            mFuzzyPicView.setVisibility(View.GONE);

            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams)mScrollView.getLayoutParams();
            lp.topMargin = getResources().getDimensionPixelSize(R.dimen.category_scroll_margin_top);
            mScrollView.setLayoutParams(lp);
            mScrollView.requestLayout();
        }

        findViewById(R.id.subject_container).requestLayout();
        mLoadingView = makeEmptyLoadingView(this, (RelativeLayout) findViewById(com.tv.ui.metro.R.id.tabs_content));
        mTitleBar = (TitleBar) this.findViewById(R.id.subject_title_bar);

        ImageView focusedView = (ImageView) this.findViewById(R.id.subject_focus_view);
        mScrollView.setFocusedView(focusedView);
		
		mSubjectId = item.id;
		mSubjectName = item.name;
		if(!TextUtils.isEmpty(mSubjectName)){
			mTitleBar.setTitle(mSubjectName);
		} else {
            if(item.type.equalsIgnoreCase("category")) {
                mTitleBar.setTitle(getResources().getString(R.string.tag_game_shop));
            }else {
                mTitleBar.setTitle(getResources().getString(R.string.tag_game_subject));
            }
		}
		
		getSupportLoaderManager().initLoader(GenericSubjectLoader.GAME_SUBJECT_LOADER_ID, arg0, this);
	}

	private void updateBgPic(GenericSubjectItem<GameItem> gameSubjectItem){
        if(item.type.equalsIgnoreCase("album") && gameSubjectItem.data.get(0).images != null) {
            GenericAlbum result = gameSubjectItem.data.get(0);
            if (result.images.big() != null && !TextUtils.isEmpty(result.images.big().url)) {
                VolleyHelper.getInstance(getBaseContext()).getImageLoader().get(result.images.big().url, ImageLoader.getImageListener(mBigPicView, 0, 0));
            }
            if (result.images.fuzzy() != null && !TextUtils.isEmpty(result.images.fuzzy().url)) {
                VolleyHelper.getInstance(getBaseContext()).getImageLoader().get(result.images.fuzzy().url, ImageLoader.getImageListener(mFuzzyPicView, 0, 0));
            }
            if (result.images.back() != null && !TextUtils.isEmpty(result.images.back().url)) {
                VolleyHelper.getInstance(getBaseContext()).getImageLoader().get(result.images.back().url, ImageLoader.getImageListener(mBgPicView, 0, 0));
            }
        }
	}

	@Override
	public Loader<GenericSubjectItem<GameItem>> onCreateLoader(int id, Bundle bundle) {
		if(id == GenericSubjectLoader.GAME_SUBJECT_LOADER_ID){
			mLoader = GenericSubjectLoader.generateGameSubjectLoader(this, item);
			mLoader.setProgressNotifiable(mLoadingView);
			return mLoader;
		}
		return null;
	}
    @Override
	public void onLoadFinished(Loader<GenericSubjectItem<GameItem>> loader, GenericSubjectItem<GameItem> result) {
		if(result == null) return;
		if(!TextUtils.isEmpty(result.data.get(0).name)){
			mTitleBar.setTitle(result.data.get(0).name);
		}
		updateBgPic(result);
        if(item.type.equalsIgnoreCase("category")){
            if(item._ui.type.equalsIgnoreCase("metro"))
                mScrollView.update(result.data.get(0).items, BaseGridItem.ITEM_TYPE_DEFAULT, false);
            else
                mScrollView.update(result.data.get(0).items, BaseGridItem.ITEM_TYPE_DEFAULT, false);
        }else {
            mScrollView.update(result.data.get(0).items, BaseGridItem.ITEM_TYPE_SUBJECT, true);
        }
	}

	@Override
	public void onLoaderReset(Loader<GenericSubjectItem<GameItem>> loader) {
		
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		
		mScrollView.release();
		
		if(mLoader != null){
			mLoader = null;
			getSupportLoaderManager().destroyLoader(GenericSubjectLoader.GAME_SUBJECT_LOADER_ID);
		}
		
		if(mRootView != null){
			ViewUtils.unbindDrawables(mRootView);
			mRootView = null;
		}
	}

	private void showBigPicView(){
        if(item.type.equalsIgnoreCase("album")) {
            isFuzzyShow = false;
            mFuzzyPicView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.disappear));
            mFuzzyPicView.setVisibility(View.GONE);
        }
	}
	
	private boolean isFuzzyShow;
	
	private void showFuzzyPicView(){
        if(item.type.equalsIgnoreCase("album")) {
            isFuzzyShow = true;
            mFuzzyPicView.setVisibility(View.VISIBLE);
            mFuzzyPicView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.appear));
        }
	}
	
	@Override
	public void onScroll(int status) {
		switch(status){
		case BaseScrollView.SCROLL_DOWN:
			if(!isFuzzyShow){
				showFuzzyPicView();	
			}
			break;
		case BaseScrollView.SCROLL_UP:
			break;
		case BaseScrollView.SCROLL_END:
			break;
		case BaseScrollView.SCROLL_START:
			if(isFuzzyShow){
				showBigPicView();	
			}
			break;
		}
	}

	@Override
	public boolean nextPage() {
		if(mLoader != null 	&& mLoader.hasMoreData() && !mLoader.isLoading()){
			mLoader.nextPage();
			mLoader.forceLoad();
			return true;
		}else{
			return false;
		}
	}

	@Override
	public void onClick(DisplayItem gameInfo, int pos) {
		if(null == gameInfo){
			return;
		}
		
		final String POSITION = StaticsType.PREFIX + pos;
		
		Intent intent = new Intent(this, GameDetailActivity.class);
		intent.putExtra(Constants.GAME_ID, gameInfo.id);
        intent.putExtra("item",            gameInfo);
		intent.putExtra(IExtraIntent.FROM, StaticsType.PAGE_SUBJECT);
		intent.putExtra(IExtraIntent.POSITION, POSITION);
		intent.putExtra(IExtraIntent.CATEGORY_ID, mSubjectId);
		startActivity(intent);
		
		ReportManager.getInstance().send(Report.createReport(ReportType.STATISTICS,	StaticsType.PAGE_SUBJECT, mSubjectId, null,	StaticsType.PAGE_DETAIL, gameInfo.id, POSITION, null));
	}
}
