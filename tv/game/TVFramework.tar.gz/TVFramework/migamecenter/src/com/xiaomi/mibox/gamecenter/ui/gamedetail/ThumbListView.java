package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import com.tv.ui.metro.model.GameItem;
import com.tv.ui.metro.model.ImageGroup;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.ui.view.HorizontalScrollListView;

/**
 * 详细小截图
 * @author liubiqiang
 *
 */
public class ThumbListView extends HorizontalScrollListView {

    public ThumbListView(Context context) {
        this(context, null, 0);
    }
    public ThumbListView(Context context,  AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);
        if(screen_shot_height == -1){
            initDimens();
        }
    }
    
    private void initDimens(){
        screen_shot_height = getResources().getDimensionPixelSize(R.dimen.screen_shot_thumb_height);
        screen_shot_width  = getResources().getDimensionPixelSize(R.dimen.screen_shot_thumb_width);
        left_margin        = getResources().getDimensionPixelSize(R.dimen.left_margin);
        focus_screen_shot_thumb_x_diff = getResources().getDimensionPixelSize(R.dimen.focus_screen_shot_thumb_x_diff);
        focus_screen_shot_thumb_y_diff = getResources().getDimensionPixelSize(R.dimen.focus_screen_shot_thumb_y_diff);
    }
    public ThumbListView(Context context, AttributeSet as) {
        this(context, as, 0);
    }
    private static int screen_shot_width  = -1;
    private static int screen_shot_height = -1;
    private static int left_margin        = -1;
    private static int focus_screen_shot_thumb_x_diff = -1;
    private static int focus_screen_shot_thumb_y_diff = -1;

    @Override
    protected int itemViewWidth(){
        if(screen_shot_width == -1){
            initDimens();
        }
        return screen_shot_width;
    }
    
    protected int itemViewHeight(){
        if(screen_shot_height == -1){
            initDimens();
        }
        return screen_shot_height;
    }

    @Override
    protected void addItemViews(int startIndex, int endIndex) {
        ScreenShotView shotView = null;
        int key = mViewLists.size();
        LinearLayout.LayoutParams llp;
        for(int i = startIndex; i < endIndex; i++){
            shotView = new ScreenShotView(getContext());
            shotView.setVisibility(View.INVISIBLE);
            llp = new LinearLayout.LayoutParams(
                    itemViewWidth(),
                    itemViewHeight());
            if(i > 0){
                llp.leftMargin = itemHorizontalMargin();
            }
            mContainer.addView(shotView, llp);
            mViewLists.put(key, shotView);
            key++;
        }
    }
    
    public void bindScreenShots(GameItem item){
        if(null == item){
            return;
        }
        final int count = item.screenshots.size();
        ScreenShotView shotView = null;
        if(count > mItemCount){//增加
            removeSpaceView();
            addItemViews(mItemCount,count);
            addRightSpaceView();
        }else if(count < mItemCount){//隐藏
            for(int i = count; i < mItemCount; i++){
                shotView = (ScreenShotView)mViewLists.get(i);
                shotView.setVisibility(View.INVISIBLE);
            }
        }
        
        mItemCount = count;
        for(int i = 0; i < count; i++){
            shotView = (ScreenShotView)mViewLists.get(i);
            shotView.setVisibility(View.VISIBLE);
            bindShotView(shotView, item.screenshots.get(i));
        }
        computeScrollRange();
    }
    
    protected void bindShotView(ScreenShotView shotView, ImageGroup screenShot){
        shotView.bindThumbData(screenShot);
    }

    @Override
    protected int leftSpaceWidth() { if(left_margin == -1)initDimens();return left_margin; }

    @Override
    protected int rightSpaceWidth() {if(left_margin == -1)initDimens();  return  left_margin; }

    @Override
    protected String TAG() {
        return "ThumbListView";
    }
    
    @Override
    protected int itemFocusXDiff(){ if(focus_screen_shot_thumb_x_diff == -1)initDimens();return focus_screen_shot_thumb_x_diff;  }
    
    @Override
    protected int itemFocusYDiff(){if(focus_screen_shot_thumb_y_diff == -1)initDimens();return focus_screen_shot_thumb_y_diff; }

    @Override
    protected int diffY() {
        return 0;
    }
    
    @Override
    protected int diffX() {
        return 0;
    }

    @Override
    protected void onClick() {
        if(mOnClickListener != null){
            mOnClickListener.onClick(null, mCurrPos);
        }
    }
}
