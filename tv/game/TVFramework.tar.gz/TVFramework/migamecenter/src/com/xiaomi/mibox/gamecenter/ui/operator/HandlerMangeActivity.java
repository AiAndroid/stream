package com.xiaomi.mibox.gamecenter.ui.operator;

import java.util.ArrayList;
import java.util.List;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothInputDevice;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;

import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.bluetooth.BluetoothReceiver;
import com.xiaomi.mibox.gamecenter.bluetooth.OnBluetoothHandlerListener;
import com.xiaomi.mibox.gamecenter.data.statics.Report;
import com.xiaomi.mibox.gamecenter.data.statics.ReportManager;
import com.xiaomi.mibox.gamecenter.data.statics.Report.ReportType;
import com.xiaomi.mibox.gamecenter.ui.view.MineScaleFocusedView;
import com.xiaomi.mibox.gamecenter.ui.view.MineView;
import com.xiaomi.mibox.gamecenter.utils.DrawableCache;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;
import com.xiaomi.mibox.gamecenter.ui.view.MirrorView;
import com.xiaomi.mitv.app.view.TitleBar;
import com.xiaomi.mitv.store.XiaomiUIHelper;

/**
 * 手柄管理页面
 * @author liubiqiang
 *
 * 本来这个页面应该是一直监听的，就是在断开或者连接手柄的过程中，都需要监听手柄的状态
 * 但是这个情况比较少见，可以忽略。
 *
 *
 */
public class HandlerMangeActivity extends XiaomiUIHelper implements OnBluetoothHandlerListener {
    private static final String TAG = "HandlerMangeActivity";

	private HorizontalScrollView mScrollView;//
	private LinearLayout mContentLayout;
	private LinearLayout mContentContainer;
	private MineScaleFocusedView mFocusedView;
	
	private MineView mAddHandlerView;
	
	private int mCurrPos = 0;
	private int[] mCurrentViewLocation = new int[2];
	private MineView mCurrentSelectedView;
	
	private LinearLayout mMirrorView;
	
	private Object mSyncObject = new Object();
	
	private ArrayList<MineView> mViewLists = new ArrayList<MineView>(8);

	private long mLastProcessTime;
	private int[] mParentLocation = new int[2];
	
	private int mScrollRange = -1;//最大可滚动的距离
	private int mCurrScrollPos;//当前滚动的位置
	private Rect mVisibleRect = new Rect();
	
	private BluetoothInputDevice mInput;
	private BluetoothAdapter mBluetoothAdapter;
	
	private Object mSyncObejct = new Object();
	private ArrayList<BluetoothDevice> mBluetoothDeviceList = new ArrayList<BluetoothDevice>(8);
	
	//TODO 也需要监听设备的消失
	//小米手柄过一段时间没有变化就自动断开了
	private boolean mManualConnect = false;
	private boolean mManualDisconnect = false;
	private String mBlueAddress;
	
    private BluetoothReceiver mBlueReceiver;
    private IntentFilter mBluetoothIntentFilter;

    private int item_v_width;
    private int item_left_margin;
    private int item_right_space;
    private int TAB_HORIZONTAL_MARGIN;
    private int SCREEN_WIDTH;

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);

        initUIDimens();
        setupView();
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter != null) {
        	if(!mBluetoothAdapter.isEnabled()){
        		mBluetoothAdapter.enable();
        	}
            mBluetoothAdapter.getProfileProxy(this, mServiceListener,
                    4);
        }
        mBlueReceiver = new BluetoothReceiver(this);
        mBluetoothIntentFilter = new IntentFilter(BluetoothInputDevice.ACTION_HID_INFO);
        mBluetoothIntentFilter.addAction(BluetoothInputDevice.ACTION_CONNECTION_STATE_CHANGED);
	}

    private void initUIDimens(){
        item_v_width     = getResources().getDimensionPixelSize(R.dimen.mine_mirror_view_height);
        item_left_margin = getResources().getDimensionPixelSize(R.dimen.mine_view_left_margin);
        item_right_space = getResources().getDimensionPixelSize(R.dimen.right_space_width);
        TAB_HORIZONTAL_MARGIN = getResources().getDimensionPixelSize(R.dimen.TAB_HORIZONTAL_MARGIN);

        SCREEN_WIDTH     = getResources().getDisplayMetrics().widthPixels;//1920
    }
	
	@Override
	public void onStart() {
		super.onStart();
		
		try {
			this.registerReceiver(mBlueReceiver, mBluetoothIntentFilter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onStop() {
		super.onStop();
		
        if(mBlueReceiver != null){
            try{
                this.unregisterReceiver(mBlueReceiver);
            }catch(Exception e){
                e.printStackTrace();
            }
        }
	}

	/**
     * 寻找所有的蓝牙游戏手柄
     */
    private BluetoothProfile.ServiceListener mServiceListener 
        = new BluetoothProfile.ServiceListener() {
        @Override
        public void onServiceConnected(int profile, BluetoothProfile proxy) {
            synchronized (this) {
                switch (profile) {
                    case 4: {
                        if(proxy instanceof BluetoothInputDevice){
                            mInput = (BluetoothInputDevice) proxy;
                        }
                        if(null == mInput){
                            return;
                        }
                        List<BluetoothDevice> devices = mInput.getConnectedDevices();
                        if (devices != null) {
                            int vid = 0;
                            int pid = 0;
                            ArrayList<BluetoothDevice> connectedDevices = new ArrayList<BluetoothDevice>(8);
                            for (BluetoothDevice device : devices) {
									if (WLUIUtils.isXiaomiBluetoothHandle(device)) {
										if (IConfig.DEBUG && !IConfig.CAN_NOT_SUPPORT_NEW_BLUETOOTH) {
											vid = mInput.getHidVid(device);
											pid = mInput.getHidPid(device);
											if (IConfig.DEBUG)Log.e(TAG, "vid" + vid + ";pid=" + pid);
										}
                                   connectedDevices.add(device);
                                } else {
                                    if (!IConfig.CAN_NOT_SUPPORT_NEW_BLUETOOTH) {
                                        try {
                                            vid = mInput.getHidVid(device);
                                            pid = mInput.getHidPid(device);
                                            if (WLUIUtils.isXiaomiBluetoothHandleByHidPid(
                                                            vid, pid)) {
                                                connectedDevices.add(device);
                                            }
                                        } catch (Exception e) {
    
                                        }
                                    }
                                }
                            }// end for
                            
//                            int i = 0;
                            for(BluetoothDevice device : connectedDevices){
                            	addNewBluetoothDevice(device);
//                                i++;
                            }
                            
//                            if(i > 0){
//                               computeScrollRange();
//                            }
                        }
                        break;
                    }
    
                    default: {
                        break;
                    }
                }
            }
        }

        @Override
        public void onServiceDisconnected(int profile) {
            synchronized (this) {
                switch (profile) {
                    case 4: {
                        mInput = null;
                        break;
                    }
                }
            }
        }
    };
	
	/**
	 * 
	 * @param currentView
	 * @param distance
	 */
	private void setCurrentView(MineView currentView, int distance, int adjustX) {
		if (null == currentView || null == mFocusedView) {
			return;
		}
        mFocusedView.setVisibility(View.VISIBLE);
        
        int realDistance = 0;
        if(mScrollRange < 0){
            realDistance = 0;
        }else{
            realDistance = distance;
            if (distance != 0) {
                if (mCurrScrollPos + distance < 0) {
                    realDistance = -mCurrScrollPos;
                } else if (mCurrScrollPos + distance > mScrollRange) {
                    realDistance = mScrollRange - mCurrScrollPos;
                }
            }
            mCurrScrollPos += realDistance;
            
            if(0 == mCurrPos && mCurrScrollPos != 0){
                realDistance -= mCurrScrollPos;
                mCurrScrollPos = 0;
            }else if(isLastColumn() && mCurrScrollPos != mScrollRange){
                realDistance += mScrollRange - mCurrScrollPos;
                mCurrScrollPos = mScrollRange;
            }
        }
        
        if (realDistance != 0) {
            mScrollView.smoothScrollBy(realDistance, 0);
        }

        mCurrentSelectedView = currentView;
        mFocusedView.setFocusView(currentView, mCurrPos);
	}
	
	private OnFocusChangeListener mFocusChangeListener = new OnFocusChangeListener() {
		
		@Override
		public void onFocusChange(View v, boolean hasFocus) {
			if (hasFocus) {
			    if(mCurrentSelectedView != null){
                    if (mFocusedView != null) {
                        mFocusedView.setVisibility(View.VISIBLE);
                    }
			    }else{
    				synchronized (mSyncObject) {
    					setCurrentView(mViewLists.get(mCurrPos), 0, 0);
    				}
			    }
			} else {
				if(mFocusedView != null){
					mFocusedView.setVisibility(View.INVISIBLE);
				}
			}
		}
	};
	
	private View.OnKeyListener mOnKeyListener = new View.OnKeyListener() {
		@Override
		public boolean onKey(View v, int keyCode, KeyEvent event) {
			long currTime = System.currentTimeMillis();
			if (Math.abs(mLastProcessTime - currTime) < 200) {
				return false;
			}
			if (KeyEvent.ACTION_DOWN == event.getAction()) {
				mLastProcessTime = currTime;
				MineView cardView = null;
				if (KeyEvent.KEYCODE_DPAD_RIGHT == keyCode) {
					synchronized (mSyncObject) {
						if (!isLastColumn()) {
							mCurrPos++;
							int distance = 0;
	                        mScrollView.getGlobalVisibleRect(mVisibleRect);
	                        int rightMost = mVisibleRect.right - mVisibleRect.left - item_right_space;
	                        if(IConfig.DEBUG) Log.e(TAG, "visibleRect rightMost="+rightMost);
	                        cardView = mViewLists.get(mCurrPos);
	                        cardView.getLocationInWindow(mCurrentViewLocation);
	                        mScrollView.getLocationInWindow(mParentLocation);
	                        int xPos = mCurrentViewLocation[0] - mParentLocation[0];
	                        if(IConfig.DEBUG) Log.e(TAG, "xPos=" + xPos);
	                        if(xPos + item_v_width > rightMost){
	                            //向右滑动 正值
	                            distance = item_v_width + item_left_margin;
	                        }
							setCurrentView(cardView, distance, 0);
							WLUIUtils.playSoundEffect(currentView(mCurrPos), keyCode);
						}else{
							WLUIUtils.playSoundEffect(currentView(mCurrPos), -1);
						}
					}
					return true;
				}

				if (KeyEvent.KEYCODE_DPAD_LEFT == keyCode) {
					synchronized (mSyncObject) {
						if (mCurrPos > 0) {
							mCurrPos--;
							
							int distance = 0;
	                        mScrollView.getGlobalVisibleRect(mVisibleRect);
	                        int leftMost = mVisibleRect.left + TAB_HORIZONTAL_MARGIN-getResources().getDimensionPixelSize(R.dimen.ITEM_FOCUS_DIFF_X);
	                        cardView = mViewLists.get(mCurrPos);
	                        cardView.getLocationInWindow(mCurrentViewLocation);
	                        mScrollView.getLocationInWindow(mParentLocation);
	                        int xPos = mCurrentViewLocation[0] - mParentLocation[0];
	                        if(xPos < leftMost){
	                            //向左滑动 负值
	                            distance = item_v_width + TAB_HORIZONTAL_MARGIN;
	                        }
							setCurrentView(cardView, -distance, 0);
							WLUIUtils.playSoundEffect(currentView(mCurrPos), keyCode);
							return true;
						}else{
							WLUIUtils.playSoundEffect(currentView(mCurrPos), -1);
							return true;
						}
					}
				}

				if (KeyEvent.KEYCODE_ENTER == keyCode
						|| KeyEvent.KEYCODE_DPAD_CENTER == keyCode
						|| KeyEvent.KEYCODE_BUTTON_A == keyCode) {// A键=遥控器的确定
					WLUIUtils.playSoundEffect(currentView(mCurrPos), keyCode);
					onClick();
					return true;
				}
			}
			return false;
		}
	};
	
	/**
	 * @param pos
	 * @return
	 */
	private MineView currentView(int pos) {
		MineView currentView = mViewLists.get(pos);
		return currentView;
	}
	
	private void onClick(){
		synchronized(mSyncObejct){
			if(mCurrPos == mBluetoothDeviceList.size()){
			    Intent intent = new Intent(this, AddHandlerDialog.class);
	            this.startActivityForResult(intent, REQUEST_CODE_CONNECT);
	            mManualConnect = true;
			}else{
	            Intent intent = new Intent(this, ConnectedHanlderOperatorActivity.class);
	            this.startActivityForResult(intent, REQUEST_CODE_DISCONNECT);
	            this.overridePendingTransition(R.anim.switcher_fade_in, 0);
	            
				ReportManager.getInstance().send(
						Report.createReport(ReportType.STATISTICS, null, null), 
						Report.MAIN_ACTION, "add");
	            mManualDisconnect = true;
			}
		}
	}
	
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(REQUEST_CODE_DISCONNECT == requestCode){
        	mManualConnect = false;
        }else if(REQUEST_CODE_DISCONNECT == requestCode){
        	mManualDisconnect = false;
        }
        if(resultCode != RESULT_OK){
            return;
        }
        if(REQUEST_CODE_DISCONNECT == requestCode){
            int choice = data.getIntExtra("index", -1);
            if(0 == choice){//断开连接
            	synchronized (mSyncObejct) {
	            	MineView mineView = mViewLists.get(mCurrPos);
	            	if(mineView != null){
	            		BluetoothDevice device = mineView.blueDevice();
	            		if(device != null){
	            			if(mInput != null){
	            				mBlueAddress = device.getAddress();
	            				if(IConfig.DEBUG) Log.e(TAG, "disconnect deive:" + mBlueAddress);
	            				mInput.disconnect(device);
	            			}
	            			removeBluetoothDevice(device, mCurrPos);
	            		}
	            	}
            	}
            }
        }else if(REQUEST_CODE_CONNECT == requestCode){//连接成功
        	ReportManager.getInstance().send(
					Report.createReport(ReportType.STATISTICS, null, null), 
					Report.MAIN_ACTION, "add_ok");
        	
            BluetoothDevice device = data.getParcelableExtra(
            		AddHandlerDialog.CONNECTED_BLUETOOTH_DEVICE);
			synchronized (mSyncObejct) {
				if (device != null && -1 == findBluetoothDevice(device)) {
					addNewBluetoothDevice(device);
				}
			}
        }
    }
	
	/**
	 * 
	 * @param device
	 * @param pos
	 */
	private void removeBluetoothDevice(BluetoothDevice device, int pos){
		final int oldDeviceCount = mBluetoothDeviceList.size();
		
		MineView mineView;
		for(int i = pos; i < oldDeviceCount - 1; i++){
			mineView = mViewLists.get(i);
			mineView.setBluetoothDevice(mBluetoothDeviceList.get(pos+1));
		}
		
		mineView = mViewLists.get(oldDeviceCount-1);
		mineView.setBackground(
				DrawableCache.getInstance().loadByResId(
						R.drawable.add_handler));
		mineView.setItemTitle(R.string.add_handler_title);
		mineView.setItemSummary("");
		mineView.setBluetoothDevice(null);
//		ImageView mirrorView = mineView.mirrorView();
//		if(mirrorView != null){
//			mirrorView.setImageDrawable(
//	                DrawableCache.getInstance().loadByResId(
//	                        R.drawable.mirror_add_handler));
//		}
		
		mineView = mViewLists.get(oldDeviceCount);
		mineView.setVisibility(View.INVISIBLE);
		MirrorView mirrorView = mineView.mirrorView();
		if(mirrorView != null){
			mirrorView.setVisibility(View.INVISIBLE);
		}
		
		mBluetoothDeviceList.remove(device);
		computeScrollRange();

		if(mCurrPos >= mBluetoothDeviceList.size() + 1){
			mCurrPos = mBluetoothDeviceList.size();
		}
		mineView = mViewLists.get(mCurrPos);
		mScrollView.getGlobalVisibleRect(mVisibleRect);
		int leftMost = mVisibleRect.left + TAB_HORIZONTAL_MARGIN;
																			//不需要
		mineView.getLocationInWindow(mCurrentViewLocation);
		mScrollView.getLocationInWindow(mParentLocation);
		int xPos = mCurrentViewLocation[0] - mParentLocation[0];
		int distance = 0;
		if (xPos < leftMost) {
			// 向左滑动 负值
			distance += item_v_width + TAB_HORIZONTAL_MARGIN;
		}
		setCurrentView(mineView, -distance, item_v_width);
	}
	
	/**
	 * 都是在第一个位置添加
	 * @param device
	 */
	private void addNewBluetoothDevice(BluetoothDevice device){
		final int oldDeviceCount = mBluetoothDeviceList.size();
		final int itemCount = mViewLists.size();
		int adjustY = 0;
		MineView mineView;
		if(oldDeviceCount + 1 == itemCount){//最后一项是添加手柄
			addConnectView(device);//添加新的一个
			adjustY = item_v_width;
		}else if(oldDeviceCount + 1 < itemCount){//小于的话就直接移动位置 大于不可能出现的
			//最后一项
			mineView = mViewLists.get(oldDeviceCount + 1);
			mineView.setItemTitle(R.string.add_handler_title);
			mineView.setBluetoothDevice(null);
			mineView.setBackground(
					DrawableCache.getInstance().loadByResId(
							R.drawable.add_handler));
			mineView.setVisibility(View.VISIBLE);
//			ImageView mirrorView = mineView.mirrorView();
//			if(mirrorView != null){
//				mirrorView.setImageDrawable(
//		                DrawableCache.getInstance().loadByResId(
//		                        R.drawable.mirror_add_handler));
//			}
			
			for(int i = oldDeviceCount; i >= 1; i--){
				mineView = mViewLists.get(i);
				if(oldDeviceCount == i){//原来这个页面是添加手柄的
					mineView.setBackground(
			                DrawableCache.getInstance().loadByResId(
			                        R.drawable.mine_handler));
					mineView.setItemTitle(R.string.connected_handler_title);
					mineView.setItemSummary(R.string.connected_handler_summary);
					
//					mirrorView = mineView.mirrorView();
//					if(mirrorView != null){
//						mirrorView.setImageDrawable(
//				                DrawableCache.getInstance().loadByResId(
//				                        R.drawable.mirror_handler));
//					}
				}
				mineView.setBluetoothDevice(mBluetoothDeviceList.get(i-1));
			}
			
			//添加的都在第一个位置
			mineView = mViewLists.get(0);
			mineView.setBackground(DrawableCache.getInstance().loadByResId(
					R.drawable.mine_handler));
			mineView.setItemTitle(R.string.connected_handler_title);
			mineView.setItemSummary(R.string.connected_handler_summary);

//			mirrorView = mineView.mirrorView();
//			if (mirrorView != null) {
//				mirrorView.setImageDrawable(DrawableCache.getInstance()
//						.loadByResId(R.drawable.mirror_handler));
//			}
			mineView.setBluetoothDevice(device);
		}else{
			return;
		}
		mBluetoothDeviceList.add(0,device);
		computeScrollRange();
		
		int distance = 0;
		mScrollView.getGlobalVisibleRect(mVisibleRect);
		int rightMost = mVisibleRect.right - mVisibleRect.left - item_right_space;
		if(IConfig.DEBUG)Log.e("visibleRect", "y="+rightMost);
		mineView = mViewLists.get(mCurrPos);
		mineView.getLocationInWindow(mCurrentViewLocation);
        mScrollView.getLocationInWindow(mParentLocation);
        int xPos = mCurrentViewLocation[0] - mParentLocation[0];
		if(xPos + item_v_width > rightMost){
			//向右滑动 正值
			distance = item_v_width + TAB_HORIZONTAL_MARGIN;
		}
       setCurrentView(mineView, distance, adjustY);
	}

    @Override
	protected void onDestroy() {
		super.onDestroy();
		
        // 关闭接口
		if(mInput != null){
            mBluetoothAdapter.closeProfileProxy(
                    4, mInput);
		}
	}
	
	private void setupView(){
		this.setContentView(R.layout.handler_purchase_layout);
		
		TitleBar titleBar = (TitleBar) this.findViewById(R.id.game_title_bar);
		titleBar.setTitle(R.string.connect_handler_title);

		//滚动部分
		mScrollView = (HorizontalScrollView) this.findViewById(R.id.purchase_scroller_view);
		mScrollView.setVerticalScrollBarEnabled(false);
		mScrollView.setHorizontalScrollBarEnabled(false);

		mContentLayout = (LinearLayout) this.findViewById(R.id.content_layout);

		mContentContainer = (LinearLayout) this.findViewById(R.id.content_purchase_container);
		mContentContainer.setOnKeyListener(mOnKeyListener);
		mContentContainer.setOnFocusChangeListener(mFocusChangeListener);
		
		mAddHandlerView = (MineView) this.findViewById(R.id.purchase_add_handler_view);
		mAddHandlerView.setItemTitle(R.string.add_handler_title);

		mViewLists.add(mAddHandlerView);
		
		mMirrorView = (LinearLayout) this.findViewById(R.id.mirror_layout);
		
		MirrorView mirrorView = (MirrorView) this.findViewById(R.id.purchase_mirror_view);
		mAddHandlerView.setMirrorView(mirrorView);
		mAddHandlerView.setBackground(DrawableCache.getInstance().loadByResId(R.drawable.add_handler));

		mFocusedView = (MineScaleFocusedView) this.findViewById(R.id.mine_purchase_focus_view);

		computeScrollRange();
	}
	
	private void addConnectView(BluetoothDevice device){
	    MineView connectView = new MineView(this);
	    connectView.setItemTitle(R.string.connected_handler_title);
	    connectView.setItemSummary(R.string.connected_handler_summary);
	    connectView.setBluetoothDevice(device);
	    LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        llp.leftMargin = getResources().getDimensionPixelSize(R.dimen.mine_view_left_margin);
        mContentContainer.addView(connectView, 1, llp);//第0个是占位试图
        mViewLists.add(0, connectView);
        
        MirrorView mirrorView = new MirrorView(this);
        llp = new LinearLayout.LayoutParams(getResources().getDimensionPixelSize(R.dimen.mine_mirror_view_width),
                getResources().getDimensionPixelSize(R.dimen.mine_mirror_view_height));
        llp.leftMargin = getResources().getDimensionPixelSize(R.dimen.mine_view_left_margin);
        mMirrorView.addView(mirrorView, 0, llp);
        connectView.setMirrorView(mirrorView);
	    connectView.setBackground(
                DrawableCache.getInstance().loadByResId(
                        R.drawable.mine_handler));
        
        computeScrollRange();
	}
	
    private void computeScrollRange() {
		synchronized (mSyncObejct) {
			final int count = mBluetoothDeviceList.size() + 1;
			mScrollRange = TAB_HORIZONTAL_MARGIN + count
					* item_v_width + (count - 1)
					* TAB_HORIZONTAL_MARGIN
					+ item_right_space - SCREEN_WIDTH;
		}
    }
    
    private boolean isLastColumn(){
		synchronized (mSyncObejct) {
			return (mBluetoothDeviceList.size() == mCurrPos);
		}
    }

	@Override
	public void connected(BluetoothDevice device) {
		if(!mManualConnect){
			synchronized (mSyncObejct) {
				int pos = findBluetoothDevice(device);
				if(-1 == pos){//有新的设备连上了
					addNewBluetoothDevice(device);
				}
			}
		}
	}

	@Override
	public void disconnected(BluetoothDevice device) {
		if(!mManualDisconnect){
			if(!TextUtils.isEmpty(mBlueAddress)
					&& device != null
					&& device.getAddress() != null
					&& device.getAddress().equals(mBlueAddress)){
				mBlueAddress = null;
				return;
			}
			synchronized (mSyncObejct) {
				int pos = findBluetoothDevice(device);
				if(pos != -1){//断开一个设备了
					removeBluetoothDevice(device, pos);
				}
			}
		}
	}
	
	private int findBluetoothDevice(BluetoothDevice device){
		if(null == device){
			return -1;
		}
		BluetoothDevice itemDevice;
		for(int i = 0; i < mBluetoothDeviceList.size(); i++){
			itemDevice = mBluetoothDeviceList.get(i);
			if(null == itemDevice){
				continue;
			}
			if(device.getAddress().equals(itemDevice.getAddress())){
				return i;
			}
		}
		return -1;
	}
}
