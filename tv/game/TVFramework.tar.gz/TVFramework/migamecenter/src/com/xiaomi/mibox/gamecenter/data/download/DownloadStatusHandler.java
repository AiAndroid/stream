package com.xiaomi.mibox.gamecenter.data.download;

import android.widget.Toast;
import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationStatus;

import com.xiaomi.mibox.gamecenter.data.statics.Report;
import com.xiaomi.mibox.gamecenter.data.statics.Report.ReportType;
import com.xiaomi.mibox.gamecenter.data.statics.ReportManager;

import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import com.xiaomi.mitv.store.utils.Utils;

public class DownloadStatusHandler extends Handler {

	private static final int EVENT_DOWNLOAD_STATUS_CHANGE = 95550;

	private Context ctx;

	public DownloadStatusHandler(Looper looper, Context ctx) {
		super(looper);
		this.ctx = ctx;
	}

	@Override
	public void dispatchMessage(Message msg) {
		super.dispatchMessage(msg);
		if (EVENT_DOWNLOAD_STATUS_CHANGE == msg.what) {
			OperationSession session = (OperationSession) msg.obj;
			OperationStatus status = null;
			//zyp 20130925 由于跨线程操作的原因，OperationSession 的setStatus 函数触发的状态变化事件，运行到这儿的时候，无法确切的知道session之前的状态是什么
			OperationStatus preStatus = null;
			if (msg.arg1 > -1 && msg.arg1 <= OperationStatus.Remove.ordinal()) {
				status = OperationStatus.values()[msg.arg1];
			}
			
			if(msg.arg2>-1 && msg.arg2 <=  OperationStatus.Remove.ordinal()){
				preStatus = OperationStatus.values()[msg.arg2];
			}
			
			if (session == null || status == null) {
				return;
			}

			switch (status) {
			case Unzipping:
				handle_status_unziping(session);
				break;
			case Downloading:
				handle_status_downloading(session,preStatus);
				break;
			case Installing:
				handle_status_installing(session);
				break;
			case InstallPause:
				handle_status_pause(session);
				break;
			case Success:
				handle_status_success(session);
				break;
			case DownloadSuccess:
				handle_status_downloadsuccess(session);
				break;
			case Remove:
				handle_status_remove(session);
				break;
			default:
				break;
			}
		}
	}

	/**
	 * 下载条目发生了状态变化
	 * 
	 * @param session
	 * @param new_status
	 */
	public void postDownloadStatusChange(OperationSession session,
			OperationStatus new_status) {
		Message msg = obtainMessage(EVENT_DOWNLOAD_STATUS_CHANGE,
				new_status.ordinal(), session.getStatus().ordinal(), session);
		sendMessage(msg);
	}

	private void handle_status_unziping(OperationSession session) {
//		Notification.showUnzippingNotification(session, ctx);
	}

	private void handle_status_downloading(OperationSession session,OperationStatus status) {
		String gid = session.getGameId();
		if (TextUtils.isEmpty(gid)) {
			return;
		}
		if(null != status &&status == OperationStatus.DownloadPause){
			DownloadStatistics.beginDownloadStatistics(gid, ctx,true);
		}else {
			DownloadStatistics.beginDownloadStatistics(gid, ctx,false);
		}
	}

	private void handle_status_installing(OperationSession session) {
		String gid = session.getGameId();
		if (TextUtils.isEmpty(gid)) {
			return;
		}
//		Notification.showInstallingNotification(gid, ctx);
		//开始安装的统计
		DownloadStatistics.beginInstallStatistics(gid);
	}

	private void handle_status_pause(OperationSession session) {
		String gid = session.getGameId();
		if (TextUtils.isEmpty(gid)) {
			return;
		}
		int reason = session.getReason();
		switch (reason) {
		case XMDownloadManager.REASON_INSTALL_INSUFFICIENT_STORAGE: {
			GameItem app = Utils.getGameItem(ctx, gid);
			if (null == app) {
				return;
			}
			GamecenterUtils.showSystemSpaceNotEnoughFailNotification(app);
			DownloadStatistics.installFailedInSufficientStorage(gid,true);
		}
			break;
		case XMDownloadManager.REASON_INSTALL_UNZIPPING_INSUFFICIENT_STORAGE: {
			GameItem app = Utils.getGameItem(ctx, gid);
			if (null == app) {
				return;
			}
			Notification.showUnzippingInsufficientNotification(gid, ctx);
			DownloadStatistics.installFailedInSufficientStorage(gid,false);
		}
			break;
		case XMDownloadManager.REASON_INSTALL_INCONSISTENT_CERTIFICATES: {
			GameItem app = Utils.getGameItem(ctx, gid);
			if (null == app) {
				return;
			}
			//签名不一致
			GamecenterUtils.showInconsistentFailNotification(app);
		}
			break;
		case XMDownloadManager.REASON_INSTALL_UNINSTALL_FAIL:{
			//卸载旧版本失败
			DownloadStatistics.uninstallFailed(gid);
		}
			break;
		case XMDownloadManager.REASON_INSTALL_APK_NOT_EXISTS:{
			//apk包不存在
			DownloadStatistics.apkFileNotExist(gid);
		}
			break;
		case XMDownloadManager.REASON_INSTALL_CANCEL_MANUAL:{
			//非静默安装方式，用户手动取消了安装
			DownloadStatistics.cancelInstallManual(gid);
		}
			break;
		default:{
			Notification.showInstallFailNotification(gid, ctx);
			DownloadStatistics.installFailedWithUnknownError(gid, session.getExtraErrorCode());
		}
			break;
		}
	}

	private void handle_status_success(OperationSession session) {
		String gid = session.getGameId();
		if (TextUtils.isEmpty(gid)) {
			return;
		}
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(ctx);
		if(sp.getBoolean("setting_need_copy_apk_after_install", false)){
			int reason = session.getReason();
			if(XMDownloadManager.REASON_INSTALL_APK_MOVE_FAILED == reason){
				Notification.showInstallSuccessNotification(gid, ctx,false);
			}else{
				Notification.showInstallSuccessNotification(gid, ctx,true);
			}
		}else{
			Notification.showInstallSuccessNotification(gid, ctx,true);
		}
		// 安装成功的统计
		DownloadStatistics.installFinishStatistics(gid);
	}

	private void handle_status_downloadsuccess(OperationSession session) {
		String gid = session.getGameId();
		if (TextUtils.isEmpty(gid)) {
			return;
		}
		DownloadStatistics.downloadFinishStatistics(gid);
	}

	private void handle_status_remove(OperationSession session) {
		int reason = session.getReason();
		String gid = session.getGameId();
		if (TextUtils.isEmpty(gid)) {
			return;
		}
		if (reason == XMDownloadManager.REASON_DOWNLOAD_PAUSED_MANUAL_WHEN_WAITING) {
			DownloadStatistics.cancelDownloadStatistics(gid,false);
		} else if(reason == XMDownloadManager.REASON_DOWNLOAD_PAUSED_MANUAL_WHEN_DOWNLOADING){
			DownloadStatistics.cancelDownloadStatistics(gid,true);
		}
	}

	/**
	 * 负责各种不同的统计点
	 */
	public static class DownloadStatistics {
		/**
		 * 开始下载的统计
		 * 
		 * @param gid
		 *            游戏id
		 */
		public static void beginDownloadStatistics(String gid, Context ctx,boolean isResume) {
			if (TextUtils.isEmpty(gid)) {
				return;
			}
			GameItem game = Utils.getGameItem(ctx, gid);
			if (null == game) {
				return;
			}
//			
//			// 51900之后的版本需要拼接cdn 和 apkurl
//			String cdn = game.cdn;
//			String type = CdnDomainUrl.RES_TYPE_DOWNLOAD;
//			String apkPath = game.url;
//			
//			String url = CdnDomainUrl.getCdnDomainUrl(cdn, type, null, null, apkPath);
//			if (TextUtils.isEmpty(url)) {
//				return;
//			}
//			try {
//				url = URLEncoder.encode(url, "UTF-8");
//			} catch (UnsupportedEncodingException e) {
//				e.printStackTrace();
//			}
//			String wifiStatus = "wifi:no";
//			if (SystemConfig.isWifiNetwork(ctx)) {
//				wifiStatus = "&wifi=1";
//			} else {
//				wifiStatus = "&wifi=0";
//			}
			StringBuilder builder = new StringBuilder();
			if(isResume){
				builder.append("begindownload_re");
			}else{
				builder.append("begindownload");
			}
			
//			builder.append(wifiStatus);
//			builder.append("&url=" + url);
			ReportManager.getInstance().send(
					Report.createReport(ReportType.DOWNLOAD, null, null, null,null,
							gid, null, null), "downloadtask",
					builder.toString());
			builder = null;

		}

		/**
		 * 下载结束的统计
		 * 
		 * @param gid
		 *            游戏id
		 */
		public static void downloadFinishStatistics(String gid) {
			if (TextUtils.isEmpty(gid)) {
				return;
			}
			ReportManager.getInstance().send(
					Report.createReport(ReportType.DOWNLOAD, null, null, null,null,
							gid, null, null), "downloadtask", "downloadfinish");
		}

		/**
		 * 开始安装的统计
		 * 
		 * @param gid
		 *            游戏id
		 */
		public static void beginInstallStatistics(String gid){
			if (TextUtils.isEmpty(gid)) {
				return;
			}
			ReportManager.getInstance().send(
					Report.createReport(ReportType.DOWNLOAD, null, null, null,null,
							gid, null, null), "downloadtask", "begininstall");
		}
		
		
		/**
		 * 安装结束的统计
		 * 
		 * @param gid
		 *            游戏id
		 */
		public static void installFinishStatistics(String gid) {
			if (TextUtils.isEmpty(gid)) {
				return;
			}
			ReportManager.getInstance().send(
					Report.createReport(ReportType.DOWNLOAD, null, null, null,null,
							gid, null, null), "downloadtask", "installsuccess");
		}

		/**
		 * 取消下载的统计，上传统计的时候，需要区分出此时游戏的下载状态
		 * 
		 * @param gid
		 *            游戏id
		 */
		public static void cancelDownloadStatistics(String gid,boolean downloading) {
			if (TextUtils.isEmpty(gid)) {
				return;
			}
			String status = "canceldownload_w";
			if(downloading){
				status = "canceldownload_d";
			}
			ReportManager.getInstance().send(
					Report.createReport(ReportType.DOWNLOAD, null, null, null,null,
							gid, null, null), "downloadtask", status);
		}
		
		/**
		 * 因空间不足导致安装失败的统计
		 * @param gid
		 * @param isSystem  是否因为系统存储空间不足导致的安装失败
		 * 
		 */
		public static void installFailedInSufficientStorage(String gid,boolean isSystem){
			if (TextUtils.isEmpty(gid)) {
				return;
			}
			String client = "if_sys_stor";
			if(!isSystem){
				client = "if_sd_stor";
			}
			ReportManager.getInstance().send(
					Report.createReport(ReportType.DOWNLOAD, null, null, null,null,
							gid, null, null), "downloadtask", client);
		}
		
		
		
		/**
		 * 安装失败，同时安装失败返回的错误码无法识别的事件统计
		 * @param gid
		 * @param errorCode
		 */
		public static void installFailedWithUnknownError(String gid, int errorCode){
			if (TextUtils.isEmpty(gid)) {
				return;
			}
			String client = "if_unko_code_"+errorCode;
			ReportManager.getInstance().send(
					Report.createReport(ReportType.DOWNLOAD, null, null, null,null,
							gid, null, null), "downloadtask", client);
 
		}
		
		/**
		 * 非静默方式安装时，用户手动取消了安装
		 * @param gid
		 */
		public static void cancelInstallManual(String gid){
			if (TextUtils.isEmpty(gid)) {
				return;
			}
			ReportManager.getInstance().send(
					Report.createReport(ReportType.DOWNLOAD, null, null, null,null,
							gid, null, null), "downloadtask", "if_cancel_manual");
		}
		
		
		/**
		 * 安装时，apk包文件不存在
		 * @param gid
		 */
		public static void apkFileNotExist(String gid){
			if (TextUtils.isEmpty(gid)) {
				return;
			}
			ReportManager.getInstance().send(
					Report.createReport(ReportType.DOWNLOAD, null, null, null,null,
							gid, null, null), "downloadtask", "if_apk_not_exist");
		}
		
		/**
		 * 安装时，卸载旧版本失败
		 * @param gid
		 */
		public static void uninstallFailed(String gid){
			if (TextUtils.isEmpty(gid)) {
				return;
			}
			ReportManager.getInstance().send(
					Report.createReport(ReportType.DOWNLOAD, null, null, null,null,
							gid, null, null), "downloadtask", "if_un_old_failed");
		}
	}

	/**
	 * @author zhaoyp 负责各种不同的Notification
	 */
	public static class Notification {

		public static void showUnzippingInsufficientNotification(String gid,
				Context ctx) {
			if (TextUtils.isEmpty(gid) || null == ctx) {
				return;
			}
			GameItem app = Utils.getGameItem(ctx, gid);
			if (null == app) {
				return;
			}
			String body = ctx.getString(
					R.string.download_manager_install_cancel_unzipping,
					app.name);
            Toast.makeText(ctx, 
                    body, 
                    Toast.LENGTH_SHORT).show();
		}

		/**
		 * “安装成功”状态栏通知
		 * 
		 * @param gid
		 */
		public static void showInstallSuccessNotification(String gid,
				Context ctx,boolean moveApkSuccess) {
			if (TextUtils.isEmpty(gid) || null == ctx) {
				return;
			}
			GameItem app = Utils.getGameItem(ctx, gid);
			if (null == app) {
				return;
			}
			String body = null;
			if(moveApkSuccess){
				body = ctx.getString(R.string.notif_install_successful,
						app.name);
			}else{
				body = ctx.getString(R.string.notif_install_successful_apk_reserve_fail,
						app.name);
			}
            Toast.makeText(ctx, 
                    body, 
                    Toast.LENGTH_SHORT).show();
		}

		/**
		 * “安装失败”状态栏通知
		 *
		 */
		public static void showInstallFailNotification(String gid, Context ctx) {
			if (TextUtils.isEmpty(gid) || null == ctx) {
				return;
			}
			GameItem app = Utils.getGameItem(ctx, gid);
			if (null == app) {
				return;
			}
			String message = ctx.getString(R.string.notif_install_failed,
					app.name);
			Toast.makeText(ctx, 
			        message, 
			        Toast.LENGTH_SHORT).show();
		}
	}
}
