package com.xiaomi.mibox.gamecenter.data;

/**
 * 本地保存的数据key
 * @author mengshu
 *
 */
public interface IUserData {
	
	String XIAOMI_ID = "miid";//小米ID
	String WALI_ID = "fuid";//
	String FUID = "fuid";
	/**
	 * 客户端标识
	 */
	String UUID = "UUID";
	
	/**
	 * 是否设置过定时任务，即是否是首次安装后
	 */
	String AUTO_PULL_DATA = "auto_data_pull";
	
	/**
	 * 版本
	 */
	String VERSION_CODE = "version_code";
}
