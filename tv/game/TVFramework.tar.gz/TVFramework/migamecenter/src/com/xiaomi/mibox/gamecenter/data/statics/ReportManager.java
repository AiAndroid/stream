package com.xiaomi.mibox.gamecenter.data.statics;

import java.io.IOException;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.ReportQueue;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumnsMap;
import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;
import com.xiaomi.mibox.gamecenter.utils.SystemConfig;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

/**
 * 自动报告模块，会自动存储没有完成的任务
 * 暂时不支持存储未完成的任务
 * @author smokelee
 *
 */
public class ReportManager 
{
	private static final String URL = "http://p.tongji.wali.com/log/?";
	
	private Context ctx;
	
	private static ReportManager mgr;
	
	public static void Init(Context ctx)
	{
		if(mgr == null)
		{
			mgr = new ReportManager(ctx);
		}
	}
	
	public static ReportManager getInstance()
	{
		return mgr;
	}
	
	private ReportManager(Context ctx)
	{
		this.ctx = ctx;
	}
	
	public void send(Report rep)
	{
		if(rep == null)
		{
			return ;
		}
		if(IConfig.DEBUG)
		{
			Log.e("ReportManager", rep.toString());
		}
		AutoThreadFactory.AppendTask("_rr_", new InsertRecord(rep.toString()), Thread.MIN_PRIORITY);
	}
	
	public void send(Report rep,String ac,String client)
	{
		if(rep == null)
		{
			return ;
		}
		if(IConfig.DEBUG)
		{
			Log.e("ReportManager", rep.toString(ac,client));
		}
		AutoThreadFactory.AppendTask("_rr_", new InsertRecord(rep.toString(ac,client)), Thread.MIN_PRIORITY);
	}
	
	class InsertRecord implements Runnable 
	{
		private String str;
		public InsertRecord(String param)
		{
			this.str = param;
		}
		
		private boolean upload_data(String param) throws ClientProtocolException, IOException
		{
			DefaultHttpClient hc = HttpConnectionManager.getHttpClient();
			HttpGet get = new HttpGet(URL+str);
			try
			{
				HttpResponse response = hc.execute(get);
				int ret = response.getStatusLine().getStatusCode();
				if(response.getEntity()!=null)
				{
					response.getEntity().consumeContent();
				}
				return ret == 200;
			}catch(Exception e)
			{
				try	{get.abort();}catch(Exception ee){}
			}
			finally
			{
				
			}
			return false;
		}
		
		@Override
		public void run() {
			if(SystemConfig.isNetworkAvailable(ctx))
			{
				StringBuffer sb = new StringBuffer();
				sb.append("(");
				Cursor sor = ctx.getContentResolver().query(ReportQueue.URI_REPORT_QUEUE, 
						DataBaseColumnsMap.REPORT_PRJ, 
						null, null, null);
				if(sor.moveToFirst())
				{
					do
					{
						try {
							if(upload_data(GamecenterUtils.decryptUrl(sor.getString(DataBaseColumnsMap.COLUMN_REPORT_PARAM))))
							{
								sb.append(sor.getInt(DataBaseColumnsMap.COLUMN_REPORT_ID));
								sb.append(",");
							}
						} catch (Exception e) {
							e.printStackTrace();
							break;
						}
					}while(sor.moveToNext());
					if(sb.length() > 1){//FIX 否则有可能 in 语句后面只有一个有括号 XXX 2013.09.22
						sb.deleteCharAt(sb.length()-1);
						sb.append(")");
					}
					if(sb.length() > 2)// 不止包含()
					{
						ctx.getContentResolver().delete(ReportQueue.URI_REPORT_QUEUE, 
								"_id in "+sb.toString(), null);
					}
				}
				sor.close();
				try {
					if(upload_data(str))
					{
						return ;
					}
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
			ContentValues cv = new ContentValues();
			cv.put(ReportQueue.PARAM, GamecenterUtils.encryptUrl(str));
			ctx.getContentResolver().insert(ReportQueue.URI_REPORT_QUEUE, cv);
		}
	}
}
