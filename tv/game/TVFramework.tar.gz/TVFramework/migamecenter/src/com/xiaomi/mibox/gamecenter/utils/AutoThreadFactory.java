package com.xiaomi.mibox.gamecenter.utils;

import java.util.Collection;
import java.util.HashMap;
import java.util.Vector;

import android.text.TextUtils;

/**
 * 自动线程管理工厂，可以根据组名来管理一类线程池，
 * 每线程管理一组任务，线程空闲时间为60秒自动销毁。多任务添加时自动队列处理
 * @author smokelee
 *
 */
public final class AutoThreadFactory
{
	private static final int DEFAULT_MAX_LIFE = 60 * 1000;
	private static HashMap<String, TaskQueue> _group = new HashMap<String, TaskQueue>(2);
	
	/**
	 * 添加一个任务
	 * @param group	任务所在任务组
	 * @param r	Runanble对象
	 * @param priority	运行级别
	 */
	public static void AppendTask(String group,  Runnable r, int priority)
	{
		synchronized (_group) {
			TaskQueue w = _group.get(group);
			
			if(w == null)
			{
				w = new TaskQueue(DEFAULT_MAX_LIFE, priority, group);
				_group.put(group, w);
				w.appendTask(r);
			}else
			{
				w.appendTask(r);
			}
		}
	}
	
	/**
	 * 获取某个组的任务数
	 * @param group
	 * @return
	 */
	public static int GetTaskCount(String group)
	{
		TaskQueue w = _group.get(group);
		if(w != null)
		{
			return w.getTaskCount();
		}
		return 0;
	}
	
	/**
	 * 清除某个组的任务队列
	 * @param group
	 */
	public static void ClearTask(String group)
	{
		synchronized (_group) {
			TaskQueue tq = _group.get(group);
			if(tq != null)
			{
				tq.terminat();
			}
		}
	}
	
	
	
	/**
	 * 清除所有任务组
	 */
	public static void clearTasks()
	{
		synchronized (_group) {
			Collection<TaskQueue> list = _group.values();
			for(TaskQueue tq : list)
			{
				tq.terminat();
			}
			_group.clear();
		}
	}
	
	public static class TaskQueue 
	{
		private WorkThreads contoller;
		private long wait_time = DEF_MAX_WAIT_TIME;
		private int priority = 3;
		private String name;
		private static final int DEF_MAX_WAIT_TIME =60 * 1000;
		TaskQueue()
		{
		}
		
		TaskQueue(long wait_time, int priority, String name)
		{
			if(priority < Thread.MIN_PRIORITY || priority > Thread.MAX_PRIORITY)
			{
				this.priority = 3;
			}else
			{
				this.priority = priority;
			}
			
			if(wait_time < DEF_MAX_WAIT_TIME)
			{
				this.wait_time = DEF_MAX_WAIT_TIME;
			}
			else
			{
				this.wait_time = wait_time;
			}
			this.name = name;
		}
		
		public void appendTask(Runnable r)
		{
			checkThreadStatus();
			contoller.append(r);
		}
		
		private void checkThreadStatus()
		{
			if(contoller == null)
			{
				contoller = new WorkThreads();
				if(!TextUtils.isEmpty(name))
				{
					contoller.setName(name);
				}
				contoller.setPriority(priority);
				contoller.start();
				return ;
			}
			if(!contoller.running)
			{
				contoller = null;
				contoller = new WorkThreads();
				if(!TextUtils.isEmpty(name))
				{
					contoller.setName(name);
				}
				contoller.setPriority(priority);
				contoller.start();
			}
		}
		
		public void appendTask(Runnable[] rs)
		{
			checkThreadStatus();
			contoller.append(rs);
		}
		
		public void terminat()
		{
			if(contoller != null)
				contoller.cancel();
		}
		
		public int getTaskCount()
		{
			if(contoller != null)
				return contoller.works.size();
			else
				return 0;
		}
		
		public class WorkThreads extends Thread
		{
			private Vector<Runnable> works = new Vector<Runnable>(5);
			private Object _lock_ = new Object();
			private volatile boolean running = true;
			private Runnable working;
			public void append(Runnable r)
			{
				synchronized (_lock_)
				{
					works.add(r);
					_lock_.notifyAll();
				}
			}
			
			public void append(Runnable[] rs)
			{
				synchronized (_lock_)
				{
					for(Runnable r : rs)
					{
						works.add(r);
					}
					_lock_.notifyAll();
				}
			}
			
			public void cancel()
			{
				synchronized (_lock_)
				{
					running = false;
					_lock_.notifyAll();
				}
			}
			
			public void cancel(Runnable r)
			{
				synchronized (_lock_)
				{
					if(working == r)
					{
						return ;
					}
					works.remove(r);
				}
			}
			
			@Override
			public void run()
			{
				Runnable working;
				while(running)
				{
					if(works.size()>0)
					{
						working = works.firstElement();
						try
						{
							working.run();
						}catch (Exception e) {
							e.printStackTrace();
						}
						works.remove(0);
					}
					
					if(works.size() == 0)
					{
						synchronized (_lock_)
						{
							try
							{
								long start = System.currentTimeMillis();
								_lock_.wait(wait_time);
								if(works.size()>0)
								{
									continue;
								}
								if(System.currentTimeMillis() - start >= wait_time)
								{
									running = false;
									break;
								}
							} catch (InterruptedException e)
							{
							}
						}
					}
					
				}
				works.clear();
				contoller = null;
			}
		}
	}
	
	
}
