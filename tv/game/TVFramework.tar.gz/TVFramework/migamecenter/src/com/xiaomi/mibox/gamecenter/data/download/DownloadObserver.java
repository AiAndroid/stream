package com.xiaomi.mibox.gamecenter.data.download;

import com.tv.ui.metro.model.DisplayItem;
import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.data.localservice.PackageEntry;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
/**
 * 下载状态通知器
 * @author smokelee
 *
 */
public abstract class DownloadObserver  extends BroadcastReceiver{

	private Context ctx ;
	LocalBroadcastManager bm;
	private String action_status_change;
	private DisplayItem game;
	
	private void load_opstatus_by_game_id(Context ctx)
	{
		if(game == null)
		{
			return ;
		}
		OperationSession session = XMDownloadManager.getInstance().getOperationSession(
		        game.id);
		onDownloadStatusChange(Integer.parseInt(game.id), session);
	}
	
	public DownloadObserver(Context ctx, DisplayItem game)
	{
		this.ctx = ctx;
		this.game = game;
		init_gameId_status();
	}

	private void init_gameId_status()
	{
		if(game == null)
		{
			return ;
		}
		action_status_change = XMDownloadManager.ACTION_STATUS_CHANGE+game.id;
		load_opstatus_by_game_id(ctx);
		IntentFilter iif = new IntentFilter();
		iif.addAction(action_status_change);
		iif.addAction(PackageEntry.PACKAGE_ADD_INTERNAL+((GameItem)game).packagename);
		iif.addAction(PackageEntry.PACKAGE_REMOVE_INTERNAL+((GameItem)game).packagename);
		iif.addAction(PackageEntry.PACKAGE_REPLACE_INTERNAL+((GameItem)game).packagename);
		bm = LocalBroadcastManager.getInstance(ctx);
		bm.registerReceiver(this, iif);
	}
	
	public void setGameId(GameItem game)
	{
		this.game = game;
		release();
		init_gameId_status();
	}
	
	public void release()
	{
		try
		{
			bm.unregisterReceiver(this);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Override
	public void onReceive(Context context, Intent intent) {
		OperationSession status = null;
		status = intent.getParcelableExtra("session");
		if(null != status) {
			int gameId = Integer.parseInt(game.id);
			onDownloadStatusChange(gameId, status);
			return ;
		}
		onPackageStatusChange();
	}
	
	protected abstract void onDownloadStatusChange(int gameId, OperationSession session);
	protected abstract void onPackageStatusChange();
}
