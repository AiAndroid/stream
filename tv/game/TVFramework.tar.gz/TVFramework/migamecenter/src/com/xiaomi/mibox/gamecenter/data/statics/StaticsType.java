package com.xiaomi.mibox.gamecenter.data.statics;

/**
 * 统计定义的常量
 * @author mengshu
 *
 */
public interface StaticsType {
	public static final String PREFIX = "L";//位置前缀
	//首页推荐
	public static final String PAGE_RECOMMEND = "recommend";
	
	public static final String PAGE_CATEGORY_LIST = "category_list";
	//首页个人空间
	public static final String PAGE_MAIN_USER = "user";
	//专题
	public static final String PAGE_SUBJECT = "subject";
	//分类
	public static final String PAGE_CATEGORY = "category";
	//游戏详情推荐
	public static final String PAGE_DETAIL_RECOMMEND = "game_related_recommend";
	//游戏详情页面
	public static final String PAGE_DETAIL = "game_detail";
	
	//账户信息页面
	public static final String PAGE_ACCOUNT_LOGIN = "account_login";
	public static final String PAGE_MIBI_CENTER= "account_info";
	
	//手柄连接引导页面
	public static final String PAGE_CONNECT_HANDLER = "connect_or_purcharge_handler";
	
	//手柄管理页面
	public static final String PAGE_HANDLER_MANAGE = "handler_manage";
	
	//手柄操控页面
	public static final String PAGE_OPERATOR_GUIDE = "operator_guide";
}
