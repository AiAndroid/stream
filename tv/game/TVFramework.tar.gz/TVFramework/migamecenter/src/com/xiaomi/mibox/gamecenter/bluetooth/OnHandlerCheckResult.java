package com.xiaomi.mibox.gamecenter.bluetooth;

/**
 * 检测是否有蓝牙手柄
 * @author liubiqiang
 *
 */
public interface OnHandlerCheckResult {
	/**
	 * 
	 * @param hasConnectedDevice: true 有配对的蓝牙手柄
	 */
	public void onCheckFinish(boolean hasConnectedDevice);
}
