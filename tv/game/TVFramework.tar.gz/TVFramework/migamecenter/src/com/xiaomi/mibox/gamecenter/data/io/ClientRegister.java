package com.xiaomi.mibox.gamecenter.data.io;

import java.util.Locale;

import org.json.JSONException;
import org.json.JSONObject;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.data.GlobalConfig;
import com.xiaomi.mibox.gamecenter.data.IUserData;
import com.xiaomi.mibox.gamecenter.utils.Client;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;
import com.xiaomi.mibox.gamecenter.utils.SystemConfig;

import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;

/**
 * 注册
 * @author mengshu
 *
 */
public class ClientRegister extends AsyncTask<Void, Void, Void>{
	private final static String TAG = "ClientRegister";
	@Override
	protected Void doInBackground(Void... params) {
		JSONObject json = createRequestUUIDString();
		if(json != null){
			if(!GamecenterUtils.uidIsValid(GlobalConfig.getInstance().Get(
					IUserData.UUID))){
				Connection conn = new Connection(
						Constants.GAMECENTER_REQUEST_PLATFROM);
				String response = conn.requestByEncodeJson(json, null);
				if(!TextUtils.isEmpty(response)){
					String message = Connection.praseEncodeResponseMessage(
							response);
					if(IConfig.DEBUG){
						Log.e(TAG, message);
					}
					if(!TextUtils.isEmpty(message)){
						try {
							json = new JSONObject(message);
							int errCode = json.getInt("errCode");
							if(200 == errCode){
								if(json.has(Constants.UID)){
									String uid = json.getString(Constants.UID);
									if(!TextUtils.isEmpty(uid)){
										if(IConfig.DEBUG){
											Log.e("register", "uid="+uid);
										}
										GlobalConfig.getInstance().Set(
												IUserData.UUID, uid);
										GlobalConfig.getInstance().SaveNow();
									}
								}
							}
						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
		return null;
	}
	
	public static final JSONObject createRequestUUIDString() {
		JSONObject json = new JSONObject();
		try {
			json.put("msgType", "register");
			json.put("imei", Client.IMEI);
			if(IConfig.MI_TV){
				json.put("bid", Constants.MITV_GAMECENTER_BID);
			}else{
				json.put("bid", Constants.MIBOX_GAMECENTER_BID);
			}
			json.put("cid", IConfig.GAME_CENTER_CID);
			json.put("vn", Client.GAMECENTER_VERSION_NAME);
			json.put(Constants.CLIENT_VERSION_CODE, Client.GAMECENTER_VERSION);
			json.put("ua", SystemConfig.get_phone_ua());
			json.put("platform", "android");
			json.put("clientId", Client.UUID);
			json.put(Constants.MAC_WIFI, Client.MacWifi);
			json.put(Constants.DEVICE, Client.DEVICE);
			String lauguage = Locale.getDefault().getLanguage();
           String country = Locale.getDefault().getCountry();
           json.put(Constants.LANGUAGE, lauguage);
           json.put(Constants.COUNTRY, country);
		} catch (JSONException e) {
			if(IConfig.DEBUG) e.printStackTrace();
			return null;
		}
		
		return json;
	}
}
