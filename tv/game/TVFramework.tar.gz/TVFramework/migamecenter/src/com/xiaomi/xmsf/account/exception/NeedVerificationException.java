package com.xiaomi.xmsf.account.exception;

import com.xiaomi.xmsf.account.utils.MetaLoginData;

public class NeedVerificationException extends CloudServiceException {
    private static final long serialVersionUID = 1L;

    private final MetaLoginData mMetaLoginData;
    private final String mStep1Token;

    public NeedVerificationException(MetaLoginData metaLoginData, String step1Token) {
        super("Need verification code");
        mMetaLoginData = metaLoginData;
        mStep1Token = step1Token;
    }

    public MetaLoginData getMetaLoginData() {
        return mMetaLoginData;
    }

    public String getStep1Token() {
        return mStep1Token;
    }
}
