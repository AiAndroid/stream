package com.xiaomi.mibox.gamecenter.ui;

import android.util.Log;
import com.xiaomi.mibox.gamecenter.utils.Constants;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class InstallPackageByIntent extends Activity {
    private final static String TAG="InstallPackageByIntent";
	private String apk_uri;
	private String pkg_name;
	public static final String INSTALL_ACTIVITY_HAS_RETURN = "com.xiaomi.gamecenter.install_activity_return";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		apk_uri = getIntent().getStringExtra("apk_url");
		pkg_name = getIntent().getStringExtra("pkgName");
		runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				Uri u = Uri.parse(apk_uri);
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setDataAndType(u, Constants.APK_MIME_TYPE);
				try {
					InstallPackageByIntent.this.startActivityForResult(intent, 0);
				} catch (Exception e2) {
					e2.printStackTrace();
				}
				
			}
		});
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		Log.d(TAG, ">>>>>>>>");
		Intent ii = new Intent(INSTALL_ACTIVITY_HAS_RETURN+pkg_name);
		sendBroadcast(ii);
		finish();
	}
}
