package com.xiaomi.mibox.gamecenter.ui.view;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.VolleyHelper;
import com.tv.ui.metro.model.DisplayItem;
import com.tv.ui.metro.model.VideoItem;
import com.xiaomi.mibox.gamecenter.R;

/**
 * Created by liuhuadong on 9/24/14.
 */
public class VideoSeazons extends RelativeLayout {

    public VideoSeazons(Context context) {
        this(context, null, 0);
    }
    public VideoSeazons(Context context, AttributeSet as) {
        this(context, as, 0);
    }
    public VideoSeazons(Context context, AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);
        initViews(context);
    }

    VideoItem.Video content;
    public void setContent(VideoItem.Video item){
        content = item;

        videoCover.setVisibility(GONE);
        title.setText(item.name);
    }

    ImageView      videoIcon;
    View           videoCover;
    TextView       title;
    private void initViews(Context ctx){
        View viewRoot = LayoutInflater.from(ctx).inflate(R.layout.video_item, this);

        videoIcon  = (ImageView) viewRoot.findViewById(R.id.video_item_icon);
        videoCover = viewRoot.findViewById(R.id.video_item_cover);
        title      = (TextView) viewRoot.findViewById(R.id.video_item_name);

        videoCover.setVisibility(GONE);
    }
}
