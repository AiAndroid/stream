package com.xiaomi.mibox.gamecenter.bluetooth;

import java.util.List;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothInputDevice;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.util.Log;

/**
 * 检测当前连接的手柄
 * @author liubiqiang
 * 统一处理下
 */
public class HandlerCheck {
	private static final String TAG = "HandlerCheck";
	private BluetoothInputDevice mInput;
	private BluetoothAdapter mBluetoothAdapter;
	//检测是否有蓝牙设备
	private OnHandlerCheckResult mHandlerCheckCallback;
	//寻找蓝牙设备的个数
	private OnFindHanlderCallback mOnFindHanlderCallback;
	
	/**
	 * 只是检测时候有配对的手柄
	 * @param context
	 * @param resultCallback
	 */
	public HandlerCheck(Context context, OnHandlerCheckResult resultCallback){
		mHandlerCheckCallback = resultCallback;
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if(mBluetoothAdapter != null){
			if(!mBluetoothAdapter.isEnabled()){
        		mBluetoothAdapter.enable();
        	}
			mBluetoothAdapter.getProfileProxy(context, mCheckServiceListener, 
					4);
		}
	}
	
	private BluetoothProfile.ServiceListener mCheckServiceListener =
            new BluetoothProfile.ServiceListener() {
        @Override
        public void onServiceConnected(int profile, BluetoothProfile proxy) {
            synchronized (this) {
                switch (profile) {
                	case 4: {// 4
                		if(proxy instanceof BluetoothInputDevice){
                			mInput = (BluetoothInputDevice) proxy;
                		}
                		if(null == mInput){
                			break;
                		}
						List<BluetoothDevice> devices = mInput.getConnectedDevices();
						if (devices != null) {
							int hidPid = -1;
							int vid;
							for (BluetoothDevice device : devices) {
								if(WLUIUtils.isXiaomiBluetoothHandle(device)){
									mBluetoothAdapter.closeProfileProxy(
											4, proxy);
									if(mHandlerCheckCallback != null){
										mHandlerCheckCallback.onCheckFinish(true);
									}
									return;
								}else if(!IConfig.CAN_NOT_SUPPORT_NEW_BLUETOOTH){
									try{
										vid = mInput.getHidVid(device);
										hidPid = mInput.getHidPid(device);
										if(WLUIUtils.isXiaomiBluetoothHandleByHidPid(vid,hidPid)){
											mBluetoothAdapter.closeProfileProxy(
													4, proxy);
											if(mHandlerCheckCallback != null){
												mHandlerCheckCallback.onCheckFinish(true);
											}
											return;
										}
									}catch(Exception e){

									}
								}
							}
						}
	
						// 关闭接口
						mBluetoothAdapter.closeProfileProxy(
								4, proxy);
						//没有找到配对的手柄
						if(mHandlerCheckCallback != null){
							mHandlerCheckCallback.onCheckFinish(false);
						}
						break;
					}
	
					default: {
						break;
					}
				}
			}
		}
        
		@Override
		public void onServiceDisconnected(int profile) {
			synchronized (this) {
				switch (profile) {
					case 4: {
						mInput = null;
						break;
					}
				}
			}
		}
	};
	
	
	/**
	 * 
	 * @param context
	 * @param findHanlderCallback
	 */
	public HandlerCheck(Context context, OnFindHanlderCallback findHanlderCallback){
		mOnFindHanlderCallback = findHanlderCallback;
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if(mBluetoothAdapter != null){
			if(!mBluetoothAdapter.isEnabled()){
        		mBluetoothAdapter.enable();
        	}
			mBluetoothAdapter.getProfileProxy(context, mServiceListener, 
				4);
		}
	}
	
	/**
	 * 寻找所有的蓝牙游戏手柄
	 */
	private BluetoothProfile.ServiceListener mServiceListener 
		= new BluetoothProfile.ServiceListener() {
		@Override
		public void onServiceConnected(int profile, BluetoothProfile proxy) {
			synchronized (this) {
				switch (profile) {
					case 4: {
						if(proxy instanceof BluetoothInputDevice){
							mInput = (BluetoothInputDevice) proxy;
						}
						if(null == mInput){
							return;
						}
						List<BluetoothDevice> devices = mInput.getConnectedDevices();
						if (devices != null) {
							int vid = 0;
							int pid = 0;
							for (BluetoothDevice device : devices) {
								if (WLUIUtils.isXiaomiBluetoothHandle(device)) {
									if (IConfig.DEBUG && !IConfig.CAN_NOT_SUPPORT_NEW_BLUETOOTH) {
										vid = mInput.getHidVid(device);
										pid = mInput.getHidPid(device);
										if(IConfig.DEBUG) Log.e(TAG, "vid" + vid + ";pid=" + pid);
									}
									if(mOnFindHanlderCallback != null){
										mOnFindHanlderCallback.findNewHandlerDevice(
												device.getAddress());
									}
								} else {
									if (!IConfig.CAN_NOT_SUPPORT_NEW_BLUETOOTH) {
										try {
											vid = mInput.getHidVid(device);
											pid = mInput.getHidPid(device);
											if (WLUIUtils.isXiaomiBluetoothHandleByHidPid(
															vid, pid)) {
												if(mOnFindHanlderCallback != null){
													mOnFindHanlderCallback.findNewHandlerDevice(
															device.getAddress());
												}
											}
										} catch (Exception e) {
	
										}
									}
								}
							}
						}
	
						// 关闭接口
						mBluetoothAdapter.closeProfileProxy(
								4, proxy);
						if(mOnFindHanlderCallback != null){
							mOnFindHanlderCallback.onFinishedFind();
						}
						break;
					}
	
					default: {
						break;
					}
				}
			}
		}

		@Override
		public void onServiceDisconnected(int profile) {
			synchronized (this) {
				switch (profile) {
					case 4: {
						mInput = null;
						break;
					}
				}
			}
		}
	};
}
