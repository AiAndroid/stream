package com.xiaomi.mibox.gamecenter.data.io.protocol;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import org.json.JSONException;
import org.json.JSONObject;

import com.xiaomi.mibox.gamecenter.data.io.Connection.NetworkError;
import com.xiaomi.mibox.gamecenter.utils.Constants;

import android.content.Context;

final class Protocol_LoadMibiKey extends Protocol_Base<String> {
	
	private String verify;
	
	Protocol_LoadMibiKey(Context ctx, String verify) {
		super(ctx);
		this.verify = verify;
	}

	@Override
	String prepare() {
        add_base_param();
        try {
			param.put("data", URLEncoder.encode(verify,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return param_to_url_param();
	}

	@Override
	URL getUrl() {
		try {
			return new URL(Constants.LOAD_SIGN);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	Protocol_Method getMethod() {
		return Protocol_Method.GET;
	}

	@Override
	NetworkError parserResponse(byte[] data) {
		try {
			String msg = new String(data,"UTF-8");
			JSONObject json = new JSONObject(msg);
			response = json.optString("sign");
			return NetworkError.OK;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return NetworkError.RESULT_ERROR;
	}

	@Override
	public String getResponse() {
		return response;
	}

}
