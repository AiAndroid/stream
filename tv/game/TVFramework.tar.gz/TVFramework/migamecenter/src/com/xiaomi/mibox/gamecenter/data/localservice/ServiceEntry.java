package com.xiaomi.mibox.gamecenter.data.localservice;

import android.content.Context;
import android.content.Intent;

/**
 * 通过Receiver过来的消息处理入口
 * @author smokelee
 * 2012-4-17
 */
public abstract class ServiceEntry implements Runnable
{
	protected Intent intent;
	protected Context ctx;
	public ServiceEntry(Intent ii, Context ctx)
	{
		this.intent = ii;
		this.ctx = ctx;
	}
}
