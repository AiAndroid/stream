package com.xiaomi.mibox.gamecenter;

import java.io.File;

import com.xiaomi.mibox.gamecenter.account.LoginManager;
import com.xiaomi.mibox.gamecenter.data.*;
import com.xiaomi.mibox.gamecenter.data.download.XMDownloadManager;
import com.xiaomi.mibox.gamecenter.data.statics.ReportManager;
import com.xiaomi.mibox.gamecenter.utils.*;

import android.app.Application;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

/**
 * 应用程序的入口
 * @author mengshu
 *
 */
public class MiboxGamecenterApplication extends Application {

	private static MiboxGamecenterApplication sInstance;
	@SuppressWarnings("unused")
	private CrashExceptionHandler mCrashExceptionHandler;
	
	@Override
	public void onCreate() {
		super.onCreate();
		
		mCrashExceptionHandler = new CrashExceptionHandler(this);
		// if(IConfig.DEBUG){
		// StrictMode.enableDefaults();
		// }
		sInstance = this;
		MainHandler.init(this);
		GlobalConfig.init(this);
		ConfigTools.init(this);
		Client.init(this);

		if (Client.isLaterThanHoneycombMR2()) {
			// 在HONEYCOMB_MR2之后的AsyncTask使用了顺序执行的方法，会造成显示数据较缓慢
			// 应该判断CPU的个数
			WLReflect.setDefaultExecutor();// 可以解决跨平台编译的问题
		}

		LocalAppManager.init(this);
		XMDownloadManager.Init(this);
		LocalAppManager.getManager().initData();

		Constants.configURLs(this);
		DrawableCache.init(this);

		ReportManager.Init(this);// 统计用

		LoginManager.init(this);

		// 安装后首次启动，要设置定时任务
		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(this);
		boolean firstInit = sp.getBoolean(IUserData.AUTO_PULL_DATA, false);
		if (!firstInit) {
			Editor ed = sp.edit();
			ed.putBoolean(IUserData.AUTO_PULL_DATA, true);
			ed.commit();

//			AutoAsyncManager asyncManager = new AutoAsyncManager(this);
//			asyncManager.update_auto_asyn();
		}

		// 检查版本 版本不一致删除缓存
		if (GamecenterUtils.isConnected(this)) {// 无网络不清除数据 XXX
			int versionCode = sp.getInt(IUserData.VERSION_CODE, 0);
			if (versionCode != Client.GAMECENTER_VERSION) {
				Editor ed = sp.edit();
				ed.putInt(IUserData.VERSION_CODE, Client.GAMECENTER_VERSION);
				ed.commit();

				clearLocalCacheFiles();
			}
		}
	}
	
	//清除本地缓存文件
	private void clearLocalCacheFiles(){
		File cacheDir = this.getCacheDir();
		if ( cacheDir != null 
				&& cacheDir.exists() 
				&& cacheDir.isDirectory() ){
			for ( File item : cacheDir.listFiles() ){
				item.delete();
			}
		}
	}

	@Override
	public void onLowMemory() {
		super.onLowMemory();
		DrawableCache.getInstance().release();
	}

	public static MiboxGamecenterApplication getInstance(){
		return sInstance;
	}
}
