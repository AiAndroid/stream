package com.xiaomi.mibox.gamecenter.data.statics;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Set;
import java.util.Map.Entry;

import com.xiaomi.mibox.gamecenter.data.GlobalConfig;
import com.xiaomi.mibox.gamecenter.data.IUserData;
import com.xiaomi.mibox.gamecenter.utils.Client;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mibox.gamecenter.utils.SystemConfig;

import android.text.TextUtils;

/**
 * 上报对象
 * @author smokelee
 *
 */
public class Report 
{
	public static enum ReportType{
		STATISTICS,
		DOWNLOAD,
		HTTP;
		@Override
		public String toString()
		{
			if(this == STATISTICS){
				return "statistics";
			}else if(this == DOWNLOAD){
				return "download";
			}else{
				return "http";
			}
		}
	}
	
	/**报告日志*/
	private static final String action = "tv_gamecenter";
	
	//首页部分的
	public static final String MAIN_ACTION = "tv_xm_client";
	
	/**附属参数*/
	private HashMap<String, String> params;
	private static final String VERSION = "ver";
	private static final String POSITION = "position";
	private static final String OS = "os";//设备版本号
	private static final String UA = "ua";//设备名称
	
	public static Report createReport(ReportType type, String from, String curPage)
	{
		Report ret = new Report();
		ret.params = new HashMap<String, String>();
		ret.params.put("type", ""+type.toString());
		ret.params.put("from", from);
		ret.params.put("curPage", curPage);
		
		String uid = GlobalConfig.getInstance().Get(IUserData.UUID);
		if(!TextUtils.isEmpty(uid)){
			ret.params.put("uid", uid);
		}
		String os = Client.SYSTEM_VERSION; 
		if(!TextUtils.isEmpty(os)){
			ret.params.put(OS, os);	
		}
		
		if(!TextUtils.isEmpty(Client.PRODUCT)){
			ret.params.put("product", Client.PRODUCT);
		}
		
		GlobalConfig config = GlobalConfig.getInstance();
		String xiaomiId = config.Get(IUserData.XIAOMI_ID);
		if(!TextUtils.isEmpty(xiaomiId)){
			ret.params.put(Constants.MID, xiaomiId);
		}
		
		String fuid = config.Get(IUserData.WALI_ID);
		if(!TextUtils.isEmpty(fuid)){
			ret.params.put(Constants.FUID, fuid);
		}
		
		String ua=null;
		try {
			ua = URLEncoder.encode(SystemConfig.get_phone_ua(),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		if(!TextUtils.isEmpty(ua)){
			ret.params.put(UA, ua);
		}
		
		int version = Client.GAMECENTER_VERSION;
		ret.params.put(VERSION, ""+version);
		
		return ret;
	}
	
	/***
	 * 首页点击
	 * @param type
	 * @param curPage
	 * @param curPageId：点击次数
	 * @param position: 位置
	 * @return
	 */
	public static Report createReport(ReportType type, String curPage, int curPageId,
			String position)
	{
		Report ret = new Report();
		ret.params = new HashMap<String, String>();
		ret.params.put("type", ""+type.toString());
		ret.params.put("curPage", curPage);
		ret.params.put("curPageId", ""+curPageId);
		if(!TextUtils.isEmpty(position)){
			ret.params.put(POSITION, position);
		}
		
		String uid = GlobalConfig.getInstance().Get(IUserData.UUID);
		if(!TextUtils.isEmpty(uid)){
			ret.params.put(Constants.UID, uid);
		}
		
		if(!TextUtils.isEmpty(Client.PRODUCT)){
			ret.params.put("product", Client.PRODUCT);
		}
		
		GlobalConfig config = GlobalConfig.getInstance();
		String xiaomiId = config.Get(IUserData.XIAOMI_ID);
		if(!TextUtils.isEmpty(xiaomiId)){
			ret.params.put(Constants.MID, xiaomiId);
		}
		
		String fuid = config.Get(IUserData.WALI_ID);
		if(!TextUtils.isEmpty(fuid)){
			ret.params.put(Constants.FUID, fuid);
		}
		
		String ua=null;
		try {
			ua = URLEncoder.encode(SystemConfig.get_phone_ua().trim(),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		if(!TextUtils.isEmpty(ua)){
			ret.params.put(UA, ua);
		}
		
		int version = Client.GAMECENTER_VERSION;
		ret.params.put(VERSION, ""+version);
		
		return ret;
	}
	
	/**
	 * 下载完成、安装完成、取消
	 * @param type
	 * @param curPage
	 * @return
	 */
	public static Report createSpecialReport(ReportType type, String curPageId)
	{
		Report ret = new Report();
		ret.params = new HashMap<String, String>();
		ret.params.put("type", ""+type.toString());
		ret.params.put("curPageId", curPageId);
		
		String uid = GlobalConfig.getInstance().Get(IUserData.UUID);
		if(!TextUtils.isEmpty(uid)){
			ret.params.put("uid", uid);
		}
		String os = Client.SYSTEM_VERSION; 
		if(!TextUtils.isEmpty(os)){
			ret.params.put(OS, os);	
		}
		
		if(!TextUtils.isEmpty(Client.PRODUCT)){
			ret.params.put("product", Client.PRODUCT);
		}
		
		GlobalConfig config = GlobalConfig.getInstance();
		String xiaomiId = config.Get(IUserData.XIAOMI_ID);
		if(!TextUtils.isEmpty(xiaomiId)){
			ret.params.put(Constants.MID, xiaomiId);
		}
		
		String fuid = config.Get(IUserData.WALI_ID);
		if(!TextUtils.isEmpty(fuid)){
			ret.params.put(Constants.FUID, fuid);
		}
		
		String ua=null;
		try {
			ua = URLEncoder.encode(SystemConfig.get_phone_ua(),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		if(!TextUtils.isEmpty(ua)){
			ret.params.put(UA, ua);
		}
		
		int version = Client.GAMECENTER_VERSION;
		ret.params.put(VERSION, ""+version);
		
		return ret;
	}

	public static Report createReport(ReportType type, String from, String fromId, String fromLabel,
			String curPage, String curPageId, String position, String tt)
	{
		Report ret = new Report();
		ret.params = new HashMap<String, String>();
		ret.params.put("type", ""+type.toString());
		ret.params.put("from", from);
		ret.params.put("fromId", fromId);
		ret.params.put("curPage", curPage);
		ret.params.put("curPageId", curPageId);
		ret.params.put(POSITION, position);
		ret.params.put("fromLabel", fromLabel);
		ret.params.put("tt", tt);
		
		String uid = GlobalConfig.getInstance().Get(IUserData.UUID);
		if(!TextUtils.isEmpty(uid)){
			ret.params.put(Constants.UID, uid);
		}
		
		if(!TextUtils.isEmpty(Client.PRODUCT)){
			ret.params.put("product", Client.PRODUCT);
		}
		
		GlobalConfig config = GlobalConfig.getInstance();
		String xiaomiId = config.Get(IUserData.XIAOMI_ID);
		if(!TextUtils.isEmpty(xiaomiId)){
			ret.params.put(Constants.MID, xiaomiId);
		}
		
		String fuid = config.Get(IUserData.WALI_ID);
		if(!TextUtils.isEmpty(fuid)){
			ret.params.put(Constants.FUID, fuid);
		}
		
		String ua = null;
		try {
			ua = URLEncoder.encode(SystemConfig.get_phone_ua().trim(),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		if(!TextUtils.isEmpty(ua)){
			ret.params.put(UA, ua);
		}
		
		int version = Client.GAMECENTER_VERSION;
		ret.params.put(VERSION, ""+version);
		
		return ret;
	}
	
	/**
	 * 某些列表需要放入顺序号
	 */
	public void setOrderId(int order)
	{
		if(params == null)
		{
			return;
		}
		params.put("order", String.valueOf(order));
	}

	@Override
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		sb.append("ac=").append(action).append("&");
		sb.append("tm=").append(Calendar.getInstance().getTimeInMillis()).append("&");
		if(params != null)
		{
			Set<Entry<String, String>> set = params.entrySet();
			for(Entry<String, String> e: set)
			{
				if(e.getValue()==null)
				{
					continue;
				}
				sb.append(e.getKey()).append("=").append(e.getValue()).append("&");
			}
			sb.deleteCharAt(sb.length()-1);
		}
		
		return sb.toString();
	}

	
	public String toString(String action,String client){
		StringBuffer sb = new StringBuffer();
		if(TextUtils.isEmpty(action)){
			action = Report.MAIN_ACTION;
		}
		
		sb.append("ac=").append(action).append("&");
		sb.append("tm=").append(Calendar.getInstance().getTimeInMillis()).append("&");
		
		if(!TextUtils.isEmpty(client)){
			sb.append("client=").append(client).append("&");	
		}
		
		if(params != null)
		{
			Set<Entry<String, String>> set = params.entrySet();
			for(Entry<String, String> e: set)
			{
				if(e.getValue()==null)
				{
					continue;
				}
				sb.append(e.getKey()).append("=").append(e.getValue()).append("&");
			}
			sb.deleteCharAt(sb.length()-1);
		}
		
		return sb.toString();
	}
	
	public HashMap<String, String> getParams() {
		return params;
	}
	
}
