package com.xiaomi.xmsf.account.utils;

import java.util.HashMap;

public class EasyMap<K, V> extends HashMap<K, V> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1618991979952096153L;

	public EasyMap() {
        super();
    }

    public EasyMap(K k, V v) {
        super();
        put(k, v);
    }

    public EasyMap<K, V> easyPut(K k, V v) {
        put(k, v);
        return this;
    }

    public EasyMap<K, V> easyPutOpt(K k, V v) {
        if (v != null) {
            put(k, v);
        }
        return this;
    }
}
