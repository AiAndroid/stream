package com.xiaomi.mitv.store.network;

import android.content.Context;

import com.tv.ui.metro.loader.TabsGsonLoader;
import com.tv.ui.metro.model.DisplayItem;
import com.tv.ui.metro.model.Tabs;

public class GameTabsGsonLoader  extends TabsGsonLoader {

    public GameTabsGsonLoader(Context context) {
        super(context);
    }

    @Override
    public void setLoaderURL(DisplayItem item) {
        String url = "https://raw.githubusercontent.com/AiAndroid/stream/master/tv/game/home.json";
        calledURL = new CommonUrl(getContext()).addCommonParams(url);
    }
}
