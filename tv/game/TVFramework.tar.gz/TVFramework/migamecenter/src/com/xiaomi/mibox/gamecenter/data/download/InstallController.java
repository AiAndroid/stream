package com.xiaomi.mibox.gamecenter.data.download;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.Download;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumnsMap;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationRetry;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationStatus;
import com.xiaomi.mibox.gamecenter.data.download.XMDownloadManager.Filter;

import android.app.DownloadManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;

/**
 * 安装控制器
 * @author lihao
 *
 */
final class InstallController {
	
	private static final int EVENT_INIT_INSTALL = 10000;
	private static final int EVENT_RELOAD_INSTALL = 10001;
	private static final int EVENT_START_INSTALL = 10002;
	
	private XMDownloadManager mgr;
	
	private Context ctx;
	
	private InstallHandler handler ;
	
	public InstallController(Context ctx, XMDownloadManager mgr) {
		this.mgr = mgr;
		this.ctx = ctx;
		HandlerThread thread = new HandlerThread("");
		thread.start();
		handler = new InstallHandler(thread.getLooper());
		handler.sendEmptyMessage(EVENT_INIT_INSTALL);
	}
	
	/**
	 * 重新载入安装任务，并且对即将开始的任务开始安装
	 */
	void reloadInstallTask()
	{
		handler.sendEmptyMessage(EVENT_RELOAD_INSTALL);
	}
	
	void retryInstallTask(String gameId, OperationRetry retry)
	{
		OperationSession ops = mgr.getOperationSession(gameId);
		if(ops == null)
		{
			Cursor sor = null;
			try {
				sor = ctx.getContentResolver().query(Download.URI_DOWNLOAD, DataBaseColumnsMap.DOWNLOAD_PROJECTION, 
						Download.APP_ID+"=?", new String[]{gameId}, null);
				if(!sor.moveToFirst())
				{
					return ;
				}
				ops = new OperationSession(mgr, sor);
				mgr.putOperationSession(ops);
			} catch (Exception e) {
			}finally
			{
				if(sor != null)
				sor.close();
			}
		}
		//注意这里，重试安装是有前提条件的。
		if(ops.getStatus() != OperationStatus.InstallPause)
		{
			return ;
		}
		
		ops.setStatus(OperationStatus.InstallNext);
		ops.setRetry(retry);
		ops.update(ctx);
		handle_next_install();
	}
	
	
	/**
	 * 从数据库载入数据
	 */
	private void handle_init_from_db()
	{
		//1.从本地数据中载入安装类型的数据
		OperationSession[] list = mgr.getOperationSessionByFilter(new Filter() {
			@Override
			public boolean onFilter(OperationSession ops) {
				return ops.getStatus().ordinal() > OperationStatus.DownloadFail.ordinal();
			}
		});
		for(OperationSession ops : list)
		{
			if(ops.getStatus() == OperationStatus.Success)
			{
				//安装包已经存在了，不需要再继续安装
				ctx.getContentResolver().delete(Download.URI_DOWNLOAD, Download.APP_ID+"="+ops.getGameId(), null);
				mgr.removeOperationSession(ops.getGameId());
				continue;
			}else if(check_package_exist(ops.getPackageName(), ops.getVersioncode())){
				//正在安装的过程中退出游戏中心，重新启动后
				
				ops.setStatus(OperationStatus.Success);
				ops.update(ctx);
				
				ctx.getContentResolver().delete(Download.URI_DOWNLOAD, Download.APP_ID+"="+ops.getGameId(), null);
				mgr.removeOperationSession(ops.getGameId());
				continue;
			}
		}
		handle_next_install();
	}
	
	/**
	 * 检查当前是否有下载完成的任务开始安装
	 */
	private void handle_install_reload()
	{
		OperationSession[] list = mgr.getOperationSessionByStatus(
				new OperationStatus[]{OperationStatus.DownloadSuccess});
		for(OperationSession ops : list)
		{
			ops.setStatus(OperationStatus.InstallQueue);
			ops.update(ctx);
		}
		handle_next_install();
	}
	
	/**
	 * 开始下一个安装
	 */
	private void handle_next_install()
	{
		OperationSession[] list = mgr.getOperationSessionByFilter(new Filter() {
			@Override
			public boolean onFilter(OperationSession ops) {
				return ops.getStatus().ordinal() > OperationStatus.DownloadFail.ordinal();
			}
		});
		if(list.length == 0)
		{
			return ;
		}
		//排序（倒序，越接近安装完成的越靠上），根据状态进行安装，
		ArrayList<OperationSession> arys = new ArrayList<OperationSession>();
		for(OperationSession ops : list)
		{
			arys.add(ops);
		}
		
		Collections.sort(arys, new Comparator<OperationSession>() {
			@Override
			public int compare(OperationSession lhs, OperationSession rhs) {
				return rhs.getStatus().ordinal() - lhs.getStatus().ordinal();
			}
		});
		Iterator<OperationSession> it = arys.iterator();
		while(it.hasNext())
		{
			OperationSession ops = it.next();
			
			if(ops.getStatus() == OperationStatus.InstallPause && ops.getReason() != 0) 
			{
				it.remove();
			}
		}
		if(arys.size() == 0)
		{
			return ;
		}
		//zwb s 解决反复弹出游戏安装界面（3次）的问题，
		//原因：由InstallQueue到Installing的状态在EVENT_START_INSTALL中修改，所以有延迟
		if (handler.hasMessages(EVENT_RELOAD_INSTALL)) {
			handler.removeMessages(EVENT_RELOAD_INSTALL);
		}
		//zwb e
		handler.sendMessage(handler.obtainMessage(EVENT_START_INSTALL, arys.get(0)));
	}
	
	/**
	 * 检查安装队列中的包是否已经安装完毕
	 * @return
	 */
	private boolean check_package_exist(String pkg, int version)
	{
		PackageInfo pi = null;
		try {
			pi = ctx.getPackageManager().getPackageInfo(pkg, 0);
		} catch (NameNotFoundException e) {
			return false;
		}
		if(pi == null)
		{
			return false;
		}
		if(pi.versionCode >= version)
		{
			return true;
		}
		return false;
	}
	
	
	class InstallHandler extends Handler
	{
		public InstallHandler(Looper looper) {
			super(looper);
		}

		@Override
		public void handleMessage(Message msg) 
		{
			if(EVENT_INIT_INSTALL == msg.what)
			{
				handle_init_from_db();
			}else if(EVENT_RELOAD_INSTALL == msg.what)
			{
				handle_install_reload();
			}else if(EVENT_START_INSTALL == msg.what)
			{
				OperationSession session = new InstallProcessor(ctx, (OperationSession)msg.obj).execute();
				if(session.getStatus() == OperationStatus.Success)
				{
					ctx.getContentResolver().delete(Download.URI_DOWNLOAD, 
							Download.APP_ID+"="+session.getGameId(), null);
					mgr.removeOperationSession(session.getGameId());
					//安装完成后，从系统的downlaodManager里移除下载任务。该操作同时会删除掉下载文件。
					DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
					if(null == dm){
						return;
					}
					long did = session.getDownloadId();
					if(did>-1){
						dm.remove(did);
					}
					//如果有数据包的情况，将数据包删除
					long data_did = session.getDataDownloadId();
					if(data_did>-1){
						dm.remove(data_did);
					}
				}else if(session.getStatus() == OperationStatus.InstallPause
						|| session.getStatus() == OperationStatus.DownloadFail){//暂停的部分删除本次下载数据
					ctx.getContentResolver().delete(Download.URI_DOWNLOAD,
							Download.APP_ID + "=" + session.getGameId(), null);
					mgr.removeOperationSession(session.getGameId());

					// XXX 下载管理器不支持断点续传 直接删除之
					// 安装完成后，从系统的downlaodManager里移除下载任务。该操作同时会删除掉下载文件。
					DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
					if (null == dm) {
						return;
					}
					long did = session.getDownloadId();
					if (did > -1) {
						dm.remove(did);
					}
					// 如果有数据包的情况，将数据包删除
					long data_did = session.getDataDownloadId();
					if (data_did > -1) {
						dm.remove(data_did);
					}
				}
				//检查是否有新的待安装项
				sendEmptyMessage(EVENT_RELOAD_INSTALL);
			}
		}
	}

}
