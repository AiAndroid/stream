package com.xiaomi.mibox.gamecenter.bluetooth;

/**
 * 查找蓝牙设备
 * @author liubiqiang
 *
 */
public interface OnFindHanlderCallback {
	/**
	 * 发现新的蓝牙手柄
	 * @param device
	 */
	public void findNewHandlerDevice(String address);
	
	/**
	 * 检测完成刷新页面
	 */
	public void onFinishedFind();
}
