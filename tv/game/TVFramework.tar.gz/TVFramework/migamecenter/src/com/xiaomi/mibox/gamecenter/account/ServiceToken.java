package com.xiaomi.mibox.gamecenter.account;

import org.json.JSONObject;
import android.text.TextUtils;

/**
 * 用登录后的AuthToken换回来的
 * ServiceToken
 * @author smokelee
 *
 */
public final class ServiceToken
{
	/**事务标记*/
	String session;
	/**签名key*/
	String key;
	/**瓦力id*/
	String uid;
	/**昵称*/
	String nickName;
	/**小米id*/
	String mid;
	/**解密密钥*/
	String aesKey;
	/**时间戳*/
	long timestmp;
	
	JSONObject token;
	
	private static ServiceToken instance; 
	
	public static ServiceToken getServiceToken()
	{
		return instance;
	}
	
	public static ServiceToken parse(String text)
	{
		if(TextUtils.isEmpty( text ))
		{
			return null;
		}
		try
		{
			ServiceToken ret = new ServiceToken();
			JSONObject jo = new JSONObject(text);
			ret.session = jo.getString("session");
			ret.key = jo.getString( "key" );
			ret.uid = jo.getString( "uid" );
			ret.aesKey = jo.getString( "akey" );
			ret.mid = jo.getString( "mid" );
			instance = ret;
			return ret;
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static void resetToken()
	{
		instance = null;
	}
	
	
	public String getSessionId()
	{
		return session;
	}

	public String getKey()
	{
		return key;
	}

	public String getUid()
	{
		return uid;
	}
	

	public String getAesKey()
	{
		return aesKey;
	}

	public String getNickName()
	{
		return nickName;
	}

	public String getMid()
	{
		return mid;
	}
}
