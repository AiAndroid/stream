package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import java.util.ArrayList;

import android.util.AttributeSet;
import com.tv.ui.metro.model.ImageGroup;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

/**
 * 游戏大截图
 * @author liubiqiang
 *
 */
public class ScreenShotListView extends HorizontalScrollView 
    implements OnKeyListener{
    
    protected LinearLayout mContainer;

    protected int mItemCount = 4;
    private int SCREEN_WIDTH;
    private int SCREEN_HEIGHT;
    private int DEFAULT_SCREEN_SHOT_NUM = 4;
    public static String CDN_THUMB_HEIGHT = "w432";//432比较接近405的缩略图 CDN 尺寸


    protected SparseArray<ScreenShotView> mViewLists = new SparseArray<ScreenShotView>(4);
    
    private int mCurrPos = 0;
    private long mLastProcessTime;
    
    private OnSeekBarListener mOnSeekBarListener;

    public ScreenShotListView(Context context) {
        this(context, null, 0);
    }
    public ScreenShotListView(Context context, AttributeSet as) {
        this(context, as, 0);
    }

    public ScreenShotListView(Context context, AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);
        init(context);
    }
    
    public void setOnSeekBarListener(OnSeekBarListener l){
        mOnSeekBarListener = l;
    }
    
    public boolean isFirst(){
        if(mItemCount <= 1){
            return true;
        }else{
            return 0 == mCurrPos;
        }
    }
    
    public boolean isLast(){
        if(mItemCount <= 1){
            return true;
        }else{
            return mCurrPos == mItemCount - 1;
        }
    }
    
    public void bindScreenShots(ArrayList<ImageGroup> screenShots){
        if(null == screenShots){
            return;
        }
        final int count = screenShots.size();
        ScreenShotView shotView = null;
        if(count > mItemCount){//增加
            addItemViews(mItemCount,count);
        }else if(count < mItemCount){//隐藏
            for(int i = count; i < mItemCount; i++){
                shotView = (ScreenShotView)mViewLists.get(i);
                shotView.setVisibility(View.INVISIBLE);
            }
        }
        
        mItemCount = count;
        for(int i = 0; i < count; i++){
            shotView = (ScreenShotView)mViewLists.get(i);
            shotView.setVisibility(View.VISIBLE);
            bindShotView(shotView, screenShots.get(i));
        }
        
        if(mOnSeekBarListener != null){
            mOnSeekBarListener.seerBarTotal(mItemCount);
        }
    }
    
    public void setSelectedPos(int selectedPos){
        if(selectedPos != mCurrPos){
            mCurrPos = selectedPos;
            this.scrollBy(mCurrPos* SCREEN_WIDTH, 0);
            
            if(mOnSeekBarListener != null){
                mOnSeekBarListener.seekBarPositionChanged(mCurrPos);
            }
        }
    }

    private void init(Context context){
        this.setHorizontalScrollBarEnabled(false);
        this.setVerticalScrollBarEnabled(false);
        
        mContainer = new LinearLayout(context);
        mContainer.setOrientation(LinearLayout.HORIZONTAL);
        mContainer.setFocusable(true);
        mContainer.setFocusableInTouchMode(true);
        mContainer.setOnKeyListener(this);
        LinearLayout.LayoutParams llp;
        llp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        this.addView(mContainer, llp);

        SCREEN_WIDTH  = getResources().getDisplayMetrics().widthPixels;//1920
        SCREEN_HEIGHT = getResources().getDisplayMetrics().heightPixels;//1920

        addItemViews(0, DEFAULT_SCREEN_SHOT_NUM);
    }
    
    protected void addItemViews(int startIndex, int endIndex) {
        ScreenShotView shotView = null;
        int key = mViewLists.size();
        LinearLayout.LayoutParams llp;
        for(int i = startIndex; i < endIndex; i++){
            shotView = new ScreenShotView(getContext());
            shotView.setVisibility(View.INVISIBLE);
            llp = new LinearLayout.LayoutParams(SCREEN_WIDTH,          SCREEN_HEIGHT);
            mContainer.addView(shotView, llp);
            mViewLists.put(key, shotView);
            key++;
        }
    }
    
    private void onClick(){
        ScreenShotView shotView = mViewLists.get(mCurrPos);
        if(shotView != null){
            ImageGroup screenShot = shotView.screenShot();
            if(screenShot.thumbnail().type.equals(ScreenShot.TYPE_VIDEOS)){
                Intent intent = new Intent();
                intent.setAction(Constants.MITV_VIDEO_INTENT_ACTION);
                intent.setData(Uri.parse(screenShot.thumbnail().url));

                try{
                    getContext().startActivity(intent);
                }catch(Exception e){
                    e.printStackTrace();
                }
                
                WLUIUtils.playSoundEffect(shotView, WLUIUtils.KEYCODE_NORMAL);
                return;
            }
        }
        
        WLUIUtils.playSoundEffect(this, WLUIUtils.KEYCODE_ERROR);
    }
    
    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        long currTime = System.currentTimeMillis();
        if(KeyEvent.ACTION_DOWN == event.getAction()){
            if(Math.abs(mLastProcessTime - currTime) < 250){
                return true;
            }else{
                mLastProcessTime = currTime;
            }
            View shotView = null;
            if(KeyEvent.KEYCODE_DPAD_RIGHT == keyCode){
                if(mCurrPos < mItemCount - 1){
                    mCurrPos++;
                    shotView = mViewLists.get(mCurrPos);
                    this.smoothScrollBy(SCREEN_WIDTH, 0);
                    WLUIUtils.playSoundEffect(shotView, keyCode);
                    
                    if(mOnSeekBarListener != null){
                        mOnSeekBarListener.seekBarPositionChanged(mCurrPos);
                    }
                }else{
                    WLUIUtils.playSoundEffect(v, 
                            WLUIUtils.KEYCODE_ERROR);
                }
                return true;
            }
            
            if(KeyEvent.KEYCODE_DPAD_LEFT == keyCode){
                if(mCurrPos > 0){
                    mCurrPos--;
                    shotView = mViewLists.get(mCurrPos);
                    this.smoothScrollBy(-SCREEN_WIDTH, 0);
                    WLUIUtils.playSoundEffect(shotView, keyCode);
                    
                    if(mOnSeekBarListener != null){
                        mOnSeekBarListener.seekBarPositionChanged(mCurrPos);
                    }
                }else{
                    WLUIUtils.playSoundEffect(v, 
                            WLUIUtils.KEYCODE_ERROR);
                }
                return true;
            }
            
            if(KeyEvent.KEYCODE_ENTER == keyCode
                    || KeyEvent.KEYCODE_DPAD_CENTER == keyCode
                    || KeyEvent.KEYCODE_BUTTON_A == keyCode){//A键=遥控器的确定
                //播放视频
                onClick();
                return true;
            }
        }
        return false;
    }
    
    protected void bindShotView(ScreenShotView shotView, ImageGroup screenShot){
        shotView.bindScreenShotData(screenShot);
    }

}
