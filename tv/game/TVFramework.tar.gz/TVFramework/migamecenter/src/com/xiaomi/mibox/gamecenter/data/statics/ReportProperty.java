package com.xiaomi.mibox.gamecenter.data.statics;

public class ReportProperty {
 
	public static final String REPORT_FROM = "report_from";
	public static final String REPORT_FROMID = "report_fromid";
	public static final String REPORT_LABEL = "report_label";
	public static final String REPORT_POSITION = "report_position";
}
