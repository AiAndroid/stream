package com.xiaomi.mibox.gamecenter.data;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;

import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.data.localservice.PackageEntry;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * 管理设备中安装的应用，会区分系统应用与非系统应用
 */
public class LocalAppManager {
    private static final String TAG = "LocalAppManager";
    
    private Context mContext;
    private static LocalAppManager sLocalAppManager;

    private ConcurrentHashMap<String, String> mPackageIdMap;

    private ConcurrentHashMap<String, LocalAppInfo> mInstalledApps;
    private ConcurrentHashMap<String, LocalAppInfo> mInstalledNonSysApps;
    
    // 用于监听本地应用的加载与变化
    private CopyOnWriteArraySet<LocalAppInfoUpdateListener> mListeners;

    // 用于通知安装中断以后的应用安装或删除变化
    private ConcurrentHashMap<String,CopyOnWriteArraySet<LocalAppInstallRemoveListener>> mLocalAppListeners;

    // 用于通知每个item安装按钮显示状态
    private CopyOnWriteArraySet<LocalAppLoadListener> mLocalAppLoadListeners;

    private MyPackageMonitor mPackageMonitor = null;



    // 这个变量用于防止数据已初始化后，打开不同界面时的重复加载
    // 在主界面退出时,会被重置为false
    private boolean mIsDataInitialized = false;

    public static void init(Context context) {
        if (sLocalAppManager == null) {
            sLocalAppManager = new LocalAppManager(context);
        }
        // 加载数据与网络相关，不要直接开始加载数据，区分不同场景
    }

    public void initData() {
        if (mIsDataInitialized) {
        	if(IConfig.DEBUG) Log.d(TAG, "IsDataInitialized is true");
            return;
        }
        mIsDataInitialized = true;

        //XXX 小米电视开机太早获取的游戏列表不正确
        //需要PUSH到/system/app下才能测试到
        MainHandler.getInstance().postDelayed(new Runnable() {
            @Override
            public void run() {
                new LocalAppsInfoLoader().execute();
            }
        }, 1500);
    }

    private LocalAppManager(Context context) {
        mContext = context;
        mInstalledApps = new ConcurrentHashMap<String, LocalAppInfo>();
        mInstalledNonSysApps = new ConcurrentHashMap<String, LocalAppInfo>();
        mPackageIdMap = new ConcurrentHashMap<String, String>();
        mPackageMonitor = new MyPackageMonitor();
        mPackageMonitor.register(context);
        mLocalAppListeners = new ConcurrentHashMap<String,
                CopyOnWriteArraySet<LocalAppInstallRemoveListener>>();
        mLocalAppLoadListeners = new CopyOnWriteArraySet<LocalAppLoadListener>();
    }

    @Override
    protected void finalize() throws Throwable {
        mPackageMonitor.unregister();
    }

    public static LocalAppManager getManager() {
        return sLocalAppManager;
    }

    /**
     * 获得应用是否安装
     * 注意：调用该方法时可能数据没有准备好，请先注册监听器
     */
    public boolean isInstalled(String packageName) {
        if (TextUtils.isEmpty(packageName)) {
            return false;
        }
        return mInstalledApps.containsKey(packageName);
    }

    /**
     * 获得本地已经安装的应用
     * 注意：调用该方法时可能数据没有准备好，请先注册监听器
     */
    public Collection<LocalAppInfo> getInstalledNonSortApps() {
        return mInstalledApps.values();
    }

    /**
     * 获得本地已经安装的应用
     * 注意：调用该方法时可能数据没有准备好，请先注册监听器
     */
    public Collection<LocalAppInfo> getInstalledNonSysNonSortApps() {
        return mInstalledNonSysApps.values();
    }
    

    /**
     * 判断某应用是否有更新  --- 这个就可以 TODO
     * 注意：调用该方法时可能数据没有准备好，请先注册监听器
     */
    public boolean isUpdateable(GameItem appInfo) {
    	if(null == appInfo){//可能是推荐页面的专题
    		return false;
    	}
        LocalAppInfo localAppInfo = this.getLocalAppInfo(appInfo.packagename);
        return (localAppInfo != null && localAppInfo.mVersionCode < Integer.parseInt(appInfo.ver.code));
    }

    /**
     * 获得本地应用信息
     * 注意：调用该方法时可能数据没有准备好，请先注册监听器
     */
	public LocalAppInfo getLocalAppInfo(String packageName) {
		if (TextUtils.isEmpty(packageName)) {
			return null;
		}
		return mInstalledApps.get(packageName);
	}

    private void notifyListChanged(LocalAppInfo appInfo) {
		if (mListeners != null) {
			if (IConfig.DEBUG) {
				Log.d(TAG, "local app " + appInfo.mPackageName
						+ " list has changed, notify listeners");
			}
			for (LocalAppInfoUpdateListener listener : mListeners) {
				listener.onListChanged(appInfo);
			}
		}
    }

	private void notifyContentChanged() {
		if (mListeners != null) {
			if (IConfig.DEBUG) {
				Log.d(TAG, "local apps content has changed, notify listeners");
			}
			for (LocalAppInfoUpdateListener listener : mListeners) {
				listener.onContentChanged();
			}
		}
	}

    private void notifyContentChanged(LocalAppInfo appInfo) {
        if (mListeners != null) {
            if (IConfig.DEBUG) {
                Log.d(TAG, "local app " + appInfo.mPackageName + " content has changed, notify listeners");
            }
            for (LocalAppInfoUpdateListener listener : mListeners) {
                listener.onContentChanged(appInfo);
            }
        }
    }

    public interface LocalAppInfoUpdateListener {
        // 第一阶段本地应用信息加载完时
        public void onLocalInstalledLoaded();

        public void onListChanged();

        public void onListChanged(LocalAppInfo appInfo);

        public void onContentChanged();

        public void onContentChanged(LocalAppInfo appInfo);
    }

    public interface LocalAppInstallRemoveListener {
        public void onAppInstalled(String packageName, int uid);

        public void onAppRemoved(String packageName, int uid);
    }

    public interface LocalAppLoadListener {
        public void onLocalAppLoaded();
    }

    private class LocalAppsInfoLoader extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            if (IConfig.DEBUG) {
                Log.d(TAG, "query local apps from system : begin");
            }
        }

        @Override
        protected void onPostExecute(Void result) {


            if (IConfig.DEBUG) {
                Log.d(TAG, "query local apps from system : end");
            }

            notifyLocalInstalledLoaded();
            // 通知安装按钮出现
            notifyLocalAppLoadListener();
            new LocalAppsExtraInfoLoader().execute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            PackageManager packageManager = mContext.getPackageManager();
            List<PackageInfo> infos = packageManager.getInstalledPackages(0);
            ConcurrentHashMap<String, LocalAppInfo> installedApps = new ConcurrentHashMap<String, LocalAppInfo>();
            ConcurrentHashMap<String, LocalAppInfo> installedNonSysApps = new ConcurrentHashMap<String, LocalAppInfo>();

            for (PackageInfo info : infos) {
                if (info.applicationInfo == null) {
                    continue;
                }

                LocalAppInfo appInfo = getLocalAppInfoWithoutNameAndSignature(info);
                if (appInfo != null) {
                    installedApps.put(appInfo.mPackageName, appInfo);
                    if (!appInfo.mIsSystem) {
                        installedNonSysApps.put(appInfo.mPackageName, appInfo);
                    }
                }
            }
            mInstalledApps = installedApps;
            mInstalledNonSysApps = installedNonSysApps;
            return null;
        }
    }

    private class LocalAppsExtraInfoLoader extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            if (IConfig.DEBUG) {
                Log.d(TAG, "query local apps extra from system : begin");
            }
        }

        @Override
        protected void onPostExecute(Void result) {
            if (IConfig.DEBUG) {
                Log.d(TAG, "query local apps extra from system : end");
            }

            //本地数据加载完了,通知列表去更新应用安装状态了
            notifyListChanged();
            if (!mInstalledApps.isEmpty()) {
                // 开始从服务器上获取数据
                queryFromServer(mInstalledApps.values(), null, false);
            }
        }

        @Override
        protected Void doInBackground(Void... params) {
            if (mInstalledApps != null) {
                PackageManager packageManager = mContext.getPackageManager();
                PackageInfo pkgInfo = null;
                for (LocalAppInfo info : mInstalledApps.values()) {
                    try {
                        pkgInfo = packageManager.getPackageInfo(info.mPackageName,
                                PackageManager.GET_SIGNATURES);
                    } catch (NameNotFoundException e) {
                        continue;
                    }
                    if (pkgInfo == null || pkgInfo.applicationInfo == null) {
                        continue;
                    }
                    info.mDisplayName = packageManager.getApplicationLabel(pkgInfo.applicationInfo)
                            .toString();
                    info.mSignature = String.valueOf(pkgInfo.signatures[0].toChars());
                }
            }
            return null;
        }
    }

    private void notifyLocalInstalledLoaded() {
        if (mListeners != null) {
            if (IConfig.DEBUG) {
                Log.d(TAG, "local installed is loaded, notify listeners");
            }
            for (LocalAppInfoUpdateListener listener : mListeners) {
                listener.onLocalInstalledLoaded();
            }
        }
    }

    private void notifyListChanged() {
        if (mListeners != null) {
            if (IConfig.DEBUG) {
                Log.d(TAG, "local apps list has changed, notify listeners");
            }
            for (LocalAppInfoUpdateListener listener : mListeners) {
                listener.onListChanged();
            }
        }
    }

    public synchronized void addLocalAppLoadListener(LocalAppLoadListener listener) {
        if (listener == null) {
            return;
        }
        if (mLocalAppLoadListeners == null) {
            mLocalAppLoadListeners = new CopyOnWriteArraySet<LocalAppLoadListener>();
        }
        mLocalAppLoadListeners.add(listener);
    }

    public synchronized void removeLocalAppLoadListener(LocalAppLoadListener listener) {
        if (listener == null || mLocalAppLoadListeners == null || mLocalAppLoadListeners.isEmpty()) {
            return;
        }
        mLocalAppLoadListeners.remove(listener);
    }

    private void notifyLocalAppLoadListener() {
        if (mLocalAppLoadListeners == null) {
            return;
        }
        for (LocalAppLoadListener listener : mLocalAppLoadListeners) {
            if (listener != null) {
                listener.onLocalAppLoaded();
            }
        }
        mLocalAppListeners.clear();
    }

    private interface NotifyCallback {
        public void notifyListener();
    }
    
    private void organizeUpdates() {
    }
    
    /**
     * 当单个app产生变化时（修改，新增），检查本地更新列表是否需要移除该应用
     * 检查是否有新的更新由{@code organizedUpdates()}负责
     */
    private void refineUpdates() {
    }

    private class MyPackageMonitor extends BroadcastReceiver {
        
        private Context ctx;
        private LocalBroadcastManager mgr;
        
        public void register(Context ctx){
            this.ctx = ctx;
            mgr = LocalBroadcastManager.getInstance(ctx);
            IntentFilter iff = new IntentFilter();
            iff.addAction(PackageEntry.PACKAGE_ADD_INTERNAL);
            iff.addAction(PackageEntry.PACKAGE_REMOVE_INTERNAL);
            iff.addAction(PackageEntry.PACKAGE_REPLACE_INTERNAL);
            ctx.registerReceiver(this, iff);
        }
        
        public void unregister(){
            ctx.unregisterReceiver(this);
        }

        public void onPackageModified(String packageName) {
            // refresh mInfoList
			final LocalAppInfo appInfo = getLocalAppInfo(mContext, packageName);
			if (appInfo != null) {
				if (IConfig.DEBUG) {
					Log.d(TAG, "local app " + appInfo.mPackageName
							+ " modified");
				}
				mInstalledApps.put(packageName, appInfo);
				if (!appInfo.mIsSystem) {
					mInstalledNonSysApps.put(packageName, appInfo);
				}
				
				mgr.sendBroadcast(new Intent(PackageEntry.PACKAGE_REPLACE_INTERNAL+packageName));
				// 不修改包名/app映射表，在与服务器通信完毕后会更新
				// 从服务器获取数据之前和之后都需要通知
				// 增加判断联网的选项，在没联网的情况下，安装我们已经无法处理，所以会设置localAppManager数据过期，重新扫的时机只有等duokantv通知，或者等应用商店activity重启
			}
		}

        public void onPackageRemoved(String packageName, int uid) {
			if (mLocalAppListeners.get(packageName) != null) {
				for (LocalAppInstallRemoveListener listener : mLocalAppListeners
						.get(packageName)) {
					listener.onAppRemoved(packageName, uid);
				}
			}
			// remove the AppInfo from mInfoList
			LocalAppInfo appInfo = mInstalledApps.remove(packageName);
			mInstalledNonSysApps.remove(packageName);
			mgr.sendBroadcast(new Intent(PackageEntry.PACKAGE_REMOVE_INTERNAL+packageName));
			if (appInfo != null) {
				if (IConfig.DEBUG) {
					Log.d(TAG, "local app " + appInfo.mPackageName + " removed");
				}

				// 不修改包名/app映射表和数据库，这个数据仍然是有用的
				notifyListChanged(appInfo);
			}
        }

        public void onPackageAdded(String packageName, int uid) {
			if (mLocalAppListeners.get(packageName) != null) {
				for (LocalAppInstallRemoveListener listener : mLocalAppListeners
						.get(packageName)) {
					listener.onAppInstalled(packageName, uid);
				}
			}
			final LocalAppInfo appInfo = getLocalAppInfo(mContext, packageName);
			if (appInfo != null) {
				if (IConfig.DEBUG) {
					Log.d(TAG, "local app " + appInfo.mPackageName + " added");
				}
				mInstalledApps.put(packageName, appInfo);
				// LuncherUtils.addPackageName(packageName, mContext);
				if (!appInfo.mIsSystem) {
					mInstalledNonSysApps.put(packageName, appInfo);
				}
				mgr.sendBroadcast(new Intent(PackageEntry.PACKAGE_ADD_INTERNAL+packageName));

			}
		}

        @Override
        public void onReceive(Context context, Intent intent) {
            String pkg = intent.getStringExtra("pkg");
            int uid = intent.getIntExtra("uid", 0);
            Log.d(TAG, "LocalAppManager:"+intent.getAction());
//            boolean replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false);
            if(PackageEntry.PACKAGE_ADD_INTERNAL.equals(intent.getAction())){
                onPackageAdded(pkg, uid);
            }else if(PackageEntry.PACKAGE_REPLACE_INTERNAL.equals(intent.getAction())){
                onPackageModified(pkg);
            }else if(PackageEntry.PACKAGE_REMOVE_INTERNAL.equals(intent.getAction())){
                onPackageRemoved(pkg, uid);
            }
//            final LocalAppInfo appInfo = getLocalAppInfo(mContext, pkg);
//            if (appInfo != null) {
//                if (appInfo.mIsSystem) {//不关心系统APP
//                    return;
//                }
//            }
        }
    }

    private LocalAppInfo getLocalAppInfoWithoutNameAndSignature(PackageInfo pkgInfo) {
        if (pkgInfo == null) {
            return null;
        }
        LocalAppInfo appInfo = LocalAppInfo.get(pkgInfo.packageName);
        appInfo.mVersionCode = pkgInfo.versionCode;
        appInfo.mVersionName = pkgInfo.versionName;
        appInfo.mIsSystem = (pkgInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
        if (pkgInfo.applicationInfo != null) {
            // 在此处不做MD5生成,以免降低检查更新速度
            appInfo.mSourceDir = pkgInfo.applicationInfo.sourceDir;
        } else {
            if(IConfig.DEBUG){
            	Log.e(TAG, "get local apk source dir failed : " + appInfo.mDisplayName);
            }
        }
        return appInfo;
    }

    private LocalAppInfo getLocalAppInfo(Context context, PackageInfo pkgInfo) {
        if (pkgInfo == null || context == null) {
            return null;
        }
        PackageManager packageManager = context.getPackageManager();
        LocalAppInfo appInfo = LocalAppInfo.get(pkgInfo.packageName);
        appInfo.mDisplayName = packageManager.getApplicationLabel(pkgInfo.applicationInfo).toString();
        appInfo.mVersionCode = pkgInfo.versionCode;
        appInfo.mVersionName = pkgInfo.versionName;
        appInfo.mSignature = String.valueOf(pkgInfo.signatures[0].toChars());
        appInfo.mIsSystem = (pkgInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
        if (pkgInfo.applicationInfo != null) {
            // 单个应用的添加与修改,直接生成源文件MD5
            appInfo.mSourceDir = pkgInfo.applicationInfo.sourceDir;
            //XXX  目前不需要 就不取MD5码了
//            appInfo.mSourceMD5 = GamecenterUtils.getFileMD5(appInfo.mSourceDir);
        } else {
            if(IConfig.DEBUG) Log.e(TAG, "get local apk source dir failed : " + appInfo.mDisplayName);
        }
        return appInfo;
    }

    private LocalAppInfo getLocalAppInfo(Context context, String packageName) {
        if (context == null || TextUtils.isEmpty(packageName)) {
            return null;
        }
        PackageInfo pkgInfo = null;
        PackageManager packageManager = context.getPackageManager();
        try {
            pkgInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES);
        } catch (NameNotFoundException e) {
            Log.e(TAG, "Cannot found local app with package name : " + packageName);
        }

        if (pkgInfo == null) {
            return null;
        }
        return getLocalAppInfo(context, pkgInfo);
    }
	
    private void queryFromServer(Collection<LocalAppInfo> localAppInfos, NotifyCallback callback, boolean isAppend) {
        // 开始从服务器上获取数据
    }

}
