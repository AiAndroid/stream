package com.xiaomi.mibox.gamecenter.data.localservice;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class PackageEntry extends ServiceEntry {

    public static final String PACKAGE_ADD_INTERNAL = "com.xiaomi.mibox.gamecenter.package.add";
    public static final String PACKAGE_REPLACE_INTERNAL = "com.xiaomi.mibox.gamecenter.package.replace";
    public static final String PACKAGE_REMOVE_INTERNAL = "com.xiaomi.mibox.gamecenter.package.remove";

    public PackageEntry(Intent ii, Context ctx) {
		super(ii, ctx);
	}

	private String getPackageName(Intent intent) {
		Uri uri = intent.getData();
		String pkg = uri != null ? uri.getSchemeSpecificPart() : null;
		return pkg;
	}
	
	@Override
	public void run() {
		String action = intent.getAction();
		String pkg = getPackageName(intent);
		int uid = intent.getIntExtra(Intent.EXTRA_UID, 0);
		boolean replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false);
		if(Intent.ACTION_PACKAGE_ADDED.equals(action)){
			if (replacing) {
				handle_package_replace(pkg, uid, replacing);
			} else {
				handle_package_add(pkg, uid, replacing);
			}
		}else if(Intent.ACTION_PACKAGE_REPLACED.equals(action)){
			replacing = false;
			handle_package_replace(pkg, uid, replacing);
		}else if(Intent.ACTION_PACKAGE_REMOVED.equals(action)){
//			if (!replacing) {//升级安装，只刷新一次
				handle_package_remove(pkg, uid, replacing);
//			}
		}
	}
	
	/**
	 * 处理包安装的添加过程
	 * @param pkg
	 * @param uid
	 */
	private void handle_package_add(String pkg, int uid, boolean replacing)
	{
		Intent ii = new Intent(PACKAGE_ADD_INTERNAL);
		ii.putExtra("pkg", pkg);
		ii.putExtra("uid", uid);
		ii.putExtra(Intent.EXTRA_REPLACING, replacing);
		ctx.sendBroadcast(ii);
	}
	
	/**
	 * 处理包移除过程
	 * @param pkg
	 * @param uid
	 */
	private void handle_package_remove(String pkg, int uid, boolean replacing)
	{
		Intent ii = new Intent(PACKAGE_REMOVE_INTERNAL);
		ii.putExtra("pkg", pkg);
		ii.putExtra("uid", uid);
		ii.putExtra(Intent.EXTRA_REPLACING, replacing);
		ctx.sendBroadcast(ii);
	}
	
	/**
	 * 处理包替换过程
	 * @param pkg
	 * @param uid
	 */
	private void handle_package_replace(String pkg, int uid, boolean replacing)
	{
		Intent ii = new Intent(PACKAGE_REPLACE_INTERNAL);
		ii.putExtra("pkg", pkg);
		ii.putExtra("uid", uid);
		ii.putExtra(Intent.EXTRA_REPLACING, replacing);
		ctx.sendBroadcast(ii);
	}

}
