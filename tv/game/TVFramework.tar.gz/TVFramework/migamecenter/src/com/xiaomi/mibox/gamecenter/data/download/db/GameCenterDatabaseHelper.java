package com.xiaomi.mibox.gamecenter.data.download.db;

import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.BaseColumns;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.Download;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.ReportQueue;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * 
 * @author mengshu
 *
 */
public class GameCenterDatabaseHelper extends SQLiteOpenHelper {

    private static GameCenterDatabaseHelper sInstance = null;
    static final String DATABASE_NAME = "gamecenter.db";
    static final int DATABASE_VERSION = 2004;//

    private GameCenterDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /* package */ 
    static GameCenterDatabaseHelper getInstance(Context context) {
        if (null == sInstance) {
        	synchronized (GameCenterDatabaseHelper.class) {
				if(null == sInstance){
					sInstance = new GameCenterDatabaseHelper(context);
				}
			}
        }
        return sInstance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    	StringBuilder sb = new StringBuilder(1024);
        
        // Download table
        sb.delete(0, sb.length());
        sb.append("CREATE TABLE ");
        sb.append(Download.TABLE );
        sb.append(" (");
        sb.append(Download._ID);
        sb.append(" INTEGER PRIMARY KEY AUTOINCREMENT,");
        sb.append(Download.APP_ID).append(" TEXT,");
        sb.append(Download.DOWNLOAD_ID).append(" INTEGER,");
        sb.append(Download.APK_HASH).append(" TEXT,");
        sb.append(Download.STATUS).append(" INTEGER,");
        sb.append(Download.TOTAL_SIZE_BYTES).append(" INTEGER,");
        sb.append(Download.DOWNLOADED_BYTES).append(" INTEGER, ");
        sb.append(Download.ERRCODE).append(" INTEGER, ");
        sb.append(Download.TIMESTAMP).append(" INTEGER, ");
        sb.append(Download.VERSIONCODE).append(" INTEGER ,");
        sb.append(Download.PACKAGE).append(" TEXT, ");
        sb.append(Download.RETRY).append(" INTEGER,");
        sb.append(Download.DATA_DOWNLOAD_ID).append(" INTEGER, ");
        sb.append(Download.DATA_HAS_DATA).append(" INTEGER, ");
        sb.append(Download.PATCHER).append(" INTEGER");
        sb.append( ");");
        db.execSQL(sb.toString());
        

        //统计数据表
        sb.delete(0, sb.length());
        sb.append("CREATE TABLE ");
        sb.append(ReportQueue.TABLE);
        sb.append("(");
        sb.append(BaseColumns._ID);
        sb.append(" INTEGER PRIMARY KEY AUTOINCREMENT,");
        sb.append(ReportQueue.PARAM).append(" TEXT");
        sb.append(");");
        db.execSQL(sb.toString());
        

    }

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		dropCache(db);
	}
    
	@Override
	public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		dropCache(db);
	}

    public void dropCache(SQLiteDatabase db) {
		db.execSQL("DROP TABLE IF EXISTS " + Download.TABLE + ";");
		db.execSQL("DROP TABLE IF EXISTS " + ReportQueue.TABLE + ";");

		try {
			onCreate(db);
		} catch (Exception e) {

		}
    }
}
