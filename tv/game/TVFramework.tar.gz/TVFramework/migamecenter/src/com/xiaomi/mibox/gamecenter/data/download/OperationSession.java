package com.xiaomi.mibox.gamecenter.data.download;

import java.util.Calendar;

import android.util.Log;
import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.Download;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumnsMap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.xiaomi.mitv.store.utils.Utils;

public final class OperationSession implements Parcelable{
    private final static String TAG = "OperationSession";
	private int orderId;
	
	private String gameId;
	
	private long downloadId;
	
	private long recv;
	
	private long total;
	
	private long lastUpdate;
	
	private int reason;
	
	private OperationStatus status= OperationStatus.None;
	
	private int versioncode;
	
	/**
	 * 记录一些额外的错误码。这个默认值有讲究，最好不能是安装过程中可能抛出的错误码
	 */
	private int extraErrorCode = -20140208;
	
	private String packageName;

	private OperationRetry retry;
	
	private XMDownloadManager mgr;
	
	//zwb 数据包downloadId
	private long dataDownloadId;
	//zwb 是否有数据包:false表示无数据包，true表示有数据包,对应download表中DATA_HAS_DATA：0表示无数据包，1表示有数据包
	private boolean hasData;
	//zwb 解压百分比
	private int radio;

	//是否是增量升级包 false不是 true是
	private boolean patcher;
	
	public static enum OperationRetry
	{
		None,
		UninstallInstall,
	}
	
	public static enum OperationStatus
	{
		None,
		DownloadQueue,//排对中
		Downloading,//下载中
		DownloadPause,//下载暂停
		DownloadFail,
		DownloadSuccess,//下载完成
		InstallQueue,//安装排对中
		Unzipping,//解压中(大包游戏)
		Installing,//安装中
		Uninstall,//卸载
		InstallPause,//安装暂停
		/**
		 * 当发生异常时在用户明确选择了处理结果后，
		 * 优先处理的状态，请参考handle_next_install，的排序
		 */
		InstallNext,
		Success,//下载安装完成
		Remove;//移除
		;
	}
	
	public OperationSession(Parcel in) 
	{
		gameId = in.readString();
		downloadId = in.readLong();
		recv = in.readLong();
		total = in.readLong();
		lastUpdate = in.readLong();
		reason = in.readInt();
		status = OperationStatus.values()[in.readInt()];
		versioncode = in.readInt();
		packageName = in.readString();
		retry = OperationRetry.values()[in.readInt()];
		orderId = in.readInt();
		//ZWB
		dataDownloadId = in.readLong();
		int data_hasData = in.readInt();
		if(data_hasData==0){
			hasData=false;
		}else{
			hasData=true;
		}
		extraErrorCode = in.readInt();
		patcher = in.readInt() == 0 ? false : true;
	}
	
	OperationSession(XMDownloadManager mgr,Context ctx, String gameId)
	{
		this.mgr = mgr;
		GameItem gi = Utils.getGameItem(ctx, gameId);
		this.gameId = gameId;
		reason = 0;
		recv = 0;
		total = 0;
		versioncode = Integer.valueOf(gi.ver.code);
		packageName = gi.packagename;
		lastUpdate = Calendar.getInstance().getTimeInMillis();
		downloadId=-1;
		retry = OperationRetry.None;
		setStatus(OperationStatus.DownloadQueue);
		orderId = -1;
		//ZWB
		dataDownloadId = -1;
		hasData = false;
		patcher = TextUtils.isEmpty(gi.patch_url) ? false : true;
	}
	
	OperationSession(XMDownloadManager mgr, Cursor sor) 
	{
		this.mgr = mgr;
		gameId = sor.getString(DataBaseColumnsMap.COLUMN_DOWNLOAD_APP_ID);
		downloadId = sor.getLong(DataBaseColumnsMap.COLUMN_DOWNLOAD_ID);
		status = OperationStatus.values()[sor.getInt(DataBaseColumnsMap.COLUMN_DOWNLOAD_STATUS)];
		reason = sor.getInt(DataBaseColumnsMap.COLUMN_DOWNLOAD_ERRCODE);
		recv = sor.getInt(DataBaseColumnsMap.COLUMN_DOWNLOAD_DOWNLOADED_BYTES); 
		total = sor.getInt(DataBaseColumnsMap.COLUMN_DOWNLOAD_TOTAL_SIZE_BYTES);
		lastUpdate = sor.getLong(DataBaseColumnsMap.COLUMN_DOWNLOAD_TIMESTAMP);
		versioncode = sor.getInt(DataBaseColumnsMap.COLUMN_DOWNLOAD_VERSIONCODE);
		packageName = sor.getString(DataBaseColumnsMap.COLUMN_DOWNLOAD_PACKAGE);
		retry = OperationRetry.values()[sor.getInt(DataBaseColumnsMap.COLUMN_DOWNLOAD_RETRY)];
		orderId = sor.getInt(DataBaseColumnsMap.COLUMN_DOWNLOAD_ORDER_ID);
		//ZWB
	   dataDownloadId = sor.getLong(DataBaseColumnsMap.COLUMN_DATA_DOWNLOAD_ID);
	   int data_hasData =sor.getInt(DataBaseColumnsMap.COLUMN_DATA_HAS_DATA);
	   if(data_hasData==0){
			hasData=false;
		}else{
			hasData=true;
		}
	   int patcher =sor.getInt(DataBaseColumnsMap.COLUMN_PATCHER);
	   this.patcher = patcher == 0 ? false : true;
	}
	
	public String getGameId() {
		return gameId;
	}


	public long getDownloadId() {
		return downloadId;
	}


	public long getRecv() {
		return recv;
	}


	public long getTotal() {
		return total;
	}


	public long getLastUpdate() {
		return lastUpdate;
	}


	void setGameId(String gameId) {
		this.gameId = gameId;
	}


	void setDownloadId(long downloadId) {
		this.downloadId = downloadId;
	}


	void setRecv(long recv) {
		this.recv = recv;
	}


	void setTotal(long total) {
		this.total = total;
	}


	void setLastUpdate(long lastUpdate) {
		this.lastUpdate = lastUpdate;
	}


	void update_download_status(Context ctx, int _reason, long _recv, long _total, OperationStatus stat , String _download_id)
	{
		ContentValues cv = new ContentValues();
		cv.put(Download.ERRCODE, _reason);
		cv.put(Download.DOWNLOADED_BYTES, _recv);
		cv.put(Download.TOTAL_SIZE_BYTES, _total);
		cv.put(Download.STATUS, stat.ordinal());
		int c = ctx.getContentResolver().update(Download.URI_DOWNLOAD, cv, "download_id=?", new String[]{""+_download_id});
		if(c > 0)
		{
			reason = _reason;
			recv = _recv;
			total = _total;
			setStatus(stat);
		}
	}
	
	void update(Context ctx)
	{
		ContentValues cv = new ContentValues();
		cv.put(Download.DOWNLOAD_ID, downloadId);
		cv.put(Download.ERRCODE, reason);
		cv.put(Download.DOWNLOADED_BYTES, recv);
		cv.put(Download.TOTAL_SIZE_BYTES, total);
		cv.put(Download.STATUS, status.ordinal());
		cv.put(Download.RETRY, retry.ordinal());
		//zwb s
		cv.put(Download.DATA_DOWNLOAD_ID, dataDownloadId);
		if(this.hasData){
			cv.put(Download.DATA_HAS_DATA, 1);
		}else {
			cv.put(Download.DATA_HAS_DATA, 0);
		}
		//zwb e
		ctx.getContentResolver().update(Download.URI_DOWNLOAD, cv, Download.APP_ID+"=?", new String[]{String.valueOf(gameId)});
	}
	
	void insert(Context ctx)
	{
		ContentValues cv = new ContentValues();
		cv.put(Download.APP_ID, gameId);
		cv.put(Download.DOWNLOAD_ID, -1);
		cv.put(Download.ERRCODE, reason);
		cv.put(Download.DOWNLOADED_BYTES, recv);
		cv.put(Download.TOTAL_SIZE_BYTES, total);
		cv.put(Download.STATUS, status.ordinal());
		cv.put(Download.VERSIONCODE, versioncode);
		cv.put(Download.PACKAGE, packageName);
		cv.put(Download.RETRY, 0);
		//zwb s
		cv.put(Download.DATA_DOWNLOAD_ID, -1);
		cv.put(Download.DATA_HAS_DATA, 0);//默认0表示无数据包
		cv.put(Download.PATCHER, patcher ? 1 : 0);
		//zwb e
		Uri ret = ctx.getContentResolver().insert(Download.URI_DOWNLOAD, cv);
		Log.d(TAG, "Insert Uri:" + ret.toString());
		if(ret != null)
		{
			//ZWB ret=content://download/19, sid=19
			String sid = ret.getLastPathSegment();
			try {
				orderId = Integer.parseInt(sid);
			} catch (Exception e) {
				e.printStackTrace();
			}
			Log.d(TAG, "orderId:"+orderId);
		}
	}
	
	
	public OperationStatus getStatus() {
		return status;
	}


	public int getReason() {
		return reason;
	}
	
	void setReason(int r)
	{
		reason = r;
	}

	void setStatus(OperationStatus status) {
		mgr.onSessionStatusChange(this, status);
		this.status = status;
	}


	public int getVersioncode() {
		return versioncode;
	}


	void setVersioncode(int versioncode) {
		this.versioncode = versioncode;
	}


	public String getPackageName() {
		return packageName;
	}


	void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	
	public int getExtraErrorCode() {
		return extraErrorCode;
	}
	
	public void setExtraErrorCode(int errorCode){
		extraErrorCode = errorCode;
	}


	public OperationRetry getRetry() {
		return retry;
	}


	void setRetry(OperationRetry retry) {
		this.retry = retry;
	}

	
	public static final Creator<OperationSession> CREATOR = new Creator<OperationSession>() {

		@Override
		public OperationSession createFromParcel(Parcel source) {
			OperationSession session = new OperationSession(source);
			return session;
		}

		@Override
		public OperationSession[] newArray(int size) {
			return new OperationSession[size];
		}
	};
	
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(gameId);
		dest.writeLong(downloadId);
		dest.writeLong(recv);
		dest.writeLong(total);
		dest.writeLong(lastUpdate);
		dest.writeInt(reason);
		dest.writeInt(status.ordinal());
		dest.writeInt(versioncode);
		dest.writeString(packageName);
		dest.writeInt(retry.ordinal());
		dest.writeInt(orderId);
		dest.writeLong(dataDownloadId);
		if(hasData){
			dest.writeInt(1);
		}else{
			dest.writeInt(0);
		}
		dest.writeInt(extraErrorCode);
		dest.writeInt(patcher ? 1 : 0);
	}

	@Override
	public String toString() {
		return "Session: DownloadId:"+downloadId+"  Status:"+status.toString()+",gid:"+gameId+",rev:"+recv+",total:"+total;
	}

	public int getOrderId() {
		return orderId;
	}
	
	//ZWB S

	public long getDataDownloadId() {
		return dataDownloadId;
	}

	void setDataDownloadId(long dataDownloadId) {
		this.dataDownloadId = dataDownloadId;
	}
	
	public boolean isHasData() {
		return hasData;
	}

	void setHasData(boolean hasData) {
		this.hasData = hasData;
	}

	public int getRadio() {
		return radio;
	}

	void setRadio(int radio) {
		this.radio = radio;
		setStatus(OperationStatus.Unzipping);
	}


 
	//ZWB E
	public boolean isPatcher(){
		return patcher;
	}
}
