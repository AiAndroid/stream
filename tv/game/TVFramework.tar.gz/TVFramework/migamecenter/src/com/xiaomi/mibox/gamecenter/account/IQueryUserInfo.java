package com.xiaomi.mibox.gamecenter.account;

import com.xiaomi.xmsf.account.data.XiaomiUserInfo;

public interface IQueryUserInfo {
	public static final int QUERY_USER_INFO_FAIL = 0;
	public static final int QUERY_USER_INFO_SUCCESS = 1;
	public void onFinish(int code, XiaomiUserInfo userInfo);
}
