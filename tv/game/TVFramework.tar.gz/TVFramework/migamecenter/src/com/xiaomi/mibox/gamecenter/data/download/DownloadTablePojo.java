package com.xiaomi.mibox.gamecenter.data.download;

import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationStatus;

import android.app.DownloadManager;
import android.database.Cursor;

/**
 * 系统下载表
 * @author lihao
 *
 */
final class DownloadTablePojo {
	String downloadId;
	
	long recv;
	
	long total;
	
	long lastUpdate;
	
	int reason;
	
	OperationStatus status;
	
	
	public DownloadTablePojo(Cursor sor) 
	{
		int idColumn =  sor.getColumnIndexOrThrow(DownloadManager.COLUMN_ID);
		int reasonColumn = sor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON);
		int recvColumn = sor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
		int totoalColumn = sor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);
		int statColumn = sor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS);
		downloadId = sor.getString(idColumn);
		reason = sor.getInt(reasonColumn);
		recv = sor.getLong(recvColumn);
		total = sor.getLong(totoalColumn);
		int _stat = sor.getInt(statColumn);
		
		reason+=50000;
		
		if(_stat == DownloadManager.STATUS_PENDING || _stat == DownloadManager.STATUS_RUNNING)
		{
			status = OperationStatus.Downloading;
		}
		else if(_stat == DownloadManager.STATUS_PAUSED)
		{
			status = OperationStatus.DownloadPause;
		}
		else if(_stat == DownloadManager.STATUS_FAILED)
		{
			status = OperationStatus.DownloadFail;
		}
		else if(_stat == DownloadManager.STATUS_SUCCESSFUL)
		{
			status = OperationStatus.DownloadSuccess;
		}
	}
	
	@Override
	public String toString() {
		return "SystemDownload: DownloadID:"+downloadId+ "Status:"+status.toString();
	}

}
