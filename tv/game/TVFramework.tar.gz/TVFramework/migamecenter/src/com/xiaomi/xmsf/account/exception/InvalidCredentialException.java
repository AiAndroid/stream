package com.xiaomi.xmsf.account.exception;

import com.xiaomi.xmsf.account.utils.MetaLoginData;

public class InvalidCredentialException extends CloudServiceException {
    private static final long serialVersionUID = 1L;

    private final MetaLoginData mMetaLoginData;
    private final String mCaptchaUrl;

    public InvalidCredentialException(MetaLoginData metaLoginData, String captchaUrl) {
        super("No password or need password");
        mMetaLoginData = metaLoginData;
        mCaptchaUrl = captchaUrl;
    }

    public MetaLoginData getMetaLoginData() {
        return mMetaLoginData;
    }

    public String getCaptchaUrl() {
        return mCaptchaUrl;
    }
}
