package com.xiaomi.xmsf.account.exception;

public class RegisteredPhoneException extends CloudServiceException {
    private static final long serialVersionUID = 1L;

    public RegisteredPhoneException(String detailMessage) {
        super(detailMessage);
    }
}
