package com.xiaomi.mibox.gamecenter.data.io.protocol;

enum Protocol_Method {
	POST,
	GET
}
