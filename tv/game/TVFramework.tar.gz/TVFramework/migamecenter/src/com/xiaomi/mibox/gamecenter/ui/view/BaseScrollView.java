package com.xiaomi.mibox.gamecenter.ui.view;

import java.util.ArrayList;

import android.util.AttributeSet;
import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.ui.OnLoaderControl;
import com.xiaomi.mibox.gamecenter.utils.ViewUtils;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;
import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.Animator.AnimatorListener;
import android.content.Context;
import android.graphics.Rect;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnKeyListener;

/**
 * 基本滚动列表控件
 * @author zhaotao
 */
public class BaseScrollView extends ScrollView implements OnKeyListener, OnFocusChangeListener{

	private static final String TAG = BaseGridItem.class.getSimpleName();
	
	private static final int MAX_ROW_COUNT = 4;
	
	private ImageView mFoucedView;
	
	private int mScrollRange = -1; //最大可滚动的距离
	private int mCurrScrollPos_y; //当前滚动的位置 y
	
	private int mMoveDistance_y;
	
	private boolean mHasData = true;
	
	private int[] mLocation = new int[2];
	private int[] mParentLayoutLocation = new int[2];
	
	private BaseGridItem mCurrentSelectedItem;
	
	private int mCurrPos;//当前位置
	
	private BaseItemContainer mContainer;
	
	private int mItemCount;
	
	private boolean hasPlaceHolder;
	
	private Rect mRect = new Rect();
	
	public static final int SCROLL_UP = 0; //向上滚动
	public static final int SCROLL_DOWN = 1; //向下滚动
	public static final int SCROLL_END = 2; //滚动到底部
	public static final int SCROLL_START = 3; //滚动到顶部

    private static int default_item_height = -1;

    public BaseScrollView(Context context){
        this(context, null, 0);
    }
    public BaseScrollView(Context context, AttributeSet attrs){
        this(context, attrs, 0);
    }
    public BaseScrollView(Context context, AttributeSet attrs, int defStyle){
        super(context, attrs, defStyle);

        setVerticalScrollBarEnabled(false);
        setHorizontalScrollBarEnabled(false);

        if(default_item_height == -1)
            default_item_height = getResources().getDimensionPixelSize(R.dimen.item_default_height);
    }

	public interface OnBaseScrollListener{
		public void onScroll(int status);
	}
	
	private OnBaseScrollListener mListener;
	private OnLoaderControl mOnLoaderControl;
	
	public void setOnBaseScrollListener(OnBaseScrollListener l){
		mListener = l;
	}

	public void setFocusedView(ImageView imageView){
		mFoucedView = imageView;
	}
	
	public void setOnLoaderControl(OnLoaderControl control){
		mOnLoaderControl = control;
	}
	
	public void update(ArrayList<GameItem> infos, int type, boolean hasPlaceHolder){
		this.hasPlaceHolder = hasPlaceHolder;
		int count = 0;
		if(null == mContainer){
			mContainer = new BaseItemContainer(getContext(), hasPlaceHolder);
			FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(-1,-1);
			flp.setMargins(getResources().getDimensionPixelSize(R.dimen.container_margin_left), 0, getResources().getDimensionPixelSize(R.dimen.container_margin_left), 0);
			addView(mContainer, flp);
			count = mContainer.update(infos, type);
			mContainer.setOnFocusChangeListener(this);
			mContainer.setOnKeyListener(this);
			mContainer.setFocusable(true);
			mContainer.setFocusableInTouchMode(true);
			mContainer.requestFocus();
		}else{
			count = mContainer.update(infos, type);
		}
		computeScrollRange(count);
		if(0 == mCurrPos){
			setCurrentView(mContainer.getViewList().get(0), 0, 
					KeyEvent.KEYCODE_DPAD_CENTER);
		}
	}
	
	private void computeScrollRange(int count){
		mItemCount = count;
		int mob = count % MAX_ROW_COUNT;
		int row = mob > 0 ? count / MAX_ROW_COUNT + 1 : count/MAX_ROW_COUNT;
		mScrollRange = default_item_height * (row - 1);
	}
	
	@Override
	protected void onScrollChanged(int l, int t, int oldl, int oldt) {
		super.onScrollChanged(l, t, oldl, oldt);
		
	}
	

	private void setCurrentView(final BaseGridItem currentSelectedItem,
			 int distance_y, int keyCode){
		if(null == mFoucedView 
				|| null == currentSelectedItem){
			return;
		}
		
		if(mHasData){
			if(currentSelectedItem != null){
				mFoucedView.setVisibility(View.VISIBLE);
			}
		}else{
			mFoucedView.setVisibility(View.INVISIBLE);
		}
		//播放音响效果
		if(currentSelectedItem != null){//首次不播放音效
			WLUIUtils.playSoundEffect(currentSelectedItem, keyCode);
		}

		if(mScrollRange < 0){
			mMoveDistance_y = 0;
			if(mCurrScrollPos_y > 0){
				mMoveDistance_y = -mCurrScrollPos_y;
				mCurrScrollPos_y = 0;
			}
		}else{
			mMoveDistance_y = distance_y;
			if (distance_y != 0) {
				if (mCurrScrollPos_y + distance_y < 0) {
					mMoveDistance_y = -mCurrScrollPos_y;
				} else if (mCurrScrollPos_y + distance_y > mScrollRange) {
					mMoveDistance_y = mScrollRange - mCurrScrollPos_y;
				}
			}
			mCurrScrollPos_y += mMoveDistance_y;
		}

		if (null == mLocation) {
			mLocation = new int[2];
		}
		currentSelectedItem.getLocationInWindow(mLocation);

		if (null == mParentLayoutLocation) {
			mParentLayoutLocation = new int[2];
			
		}
		this.getLocationInWindow(mParentLayoutLocation);
		
		int x = mLocation[0] - mParentLayoutLocation[0];
		int y = mLocation[1];

		if (IConfig.DEBUG) {
			Log.d(TAG, "x=" + x);
			Log.d(TAG, "y=" + y);
		}


		if (null == mCurrentSelectedItem) {// 首次不执行动画效果
			x += getResources().getDimensionPixelSize(R.dimen.container_margin_left);
			if(hasPlaceHolder){
				y += default_item_height;
			}
			mFoucedView.setX(x);
			mFoucedView.setY(y);
			if (mMoveDistance_y != 0) {
				this.smoothScrollBy(0, mMoveDistance_y);
			}
			
			if(mHasData && null == mCurrentSelectedItem){
				mFoucedView.setVisibility(View.VISIBLE);
			}
		} else {
			if (mMoveDistance_y != 0) {
				this.smoothScrollBy(0, mMoveDistance_y);
			}
			ObjectAnimator ox = ObjectAnimator.ofFloat(mFoucedView, "x", x);
			ObjectAnimator oy = ObjectAnimator.ofFloat(mFoucedView, "y", y - mMoveDistance_y);
			AnimatorSet lineAnimator = new AnimatorSet();
			lineAnimator.playTogether(ox, oy);
			lineAnimator.setDuration(100);
			lineAnimator.addListener(new AnimatorListener() {
				@Override
				public void onAnimationStart(Animator animation) {

				}

				@Override
				public void onAnimationRepeat(Animator animation) {

				}

				@Override
				public void onAnimationEnd(Animator animation) {
					currentSelectedItem.setSelected(true);
					if(hasPlaceHolder){
						if(mCurrScrollPos_y <= 0){
							if(mListener != null){
								mListener.onScroll(SCROLL_START);
							}
						}	
					}
				}

				@Override
				public void onAnimationCancel(Animator animation) {

				}
			});
			lineAnimator.start();
		}
		mCurrentSelectedItem = currentSelectedItem;
	}
	
	@Override
	public void onFocusChange(View view, boolean hasFocus) {
//		if(hasFocus){
//			BaseGridItem item = mContainer.getViewList().get(mCurrPos);
//			if(item != null){
//				setCurrentView(item, 0, KeyEvent.KEYCODE_DPAD_CENTER);	
//			}
//		}
	}
	
	private long mLastProcessTime;
	
	@Override
	public boolean onKey(View view, int keyCode, KeyEvent event) {
		
		if(KeyEvent.ACTION_DOWN != event.getAction()){
			return false;
		}
		
		//响应时间保护，否则动画没有完成就改变了焦点位置，造成焦点混乱
		long currTime = System.currentTimeMillis();
		if(Math.abs(mLastProcessTime - currTime) < 200){
			return true;
		}else{
			mLastProcessTime = currTime;
		}
		
		int perPos;
		BaseGridItem per_item;
		if(keyCode == KeyEvent.KEYCODE_DPAD_LEFT){
			perPos = mCurrPos;
			int distance_y = 0;
			mCurrPos--;
			if(mCurrPos >= 0){
				per_item = mContainer.getViewList().get(perPos);
				mContainer.getViewList().get(mCurrPos).getLocationInWindow(mLocation);
				this.getLocationInWindow(mParentLayoutLocation);
				int yPos = mLocation[1] - mParentLayoutLocation[1];
				if(yPos < 0){
					if(mListener != null){
						mListener.onScroll(SCROLL_UP);
					}
					distance_y = -default_item_height;
				}else {
					if(hasPlaceHolder){
						if(yPos < default_item_height-2) {
							if(mListener != null){
								mListener.onScroll(SCROLL_UP);
							}
							distance_y = -default_item_height;
						}
					}
				}
				per_item.setSelected(false);
				setCurrentView(mContainer.getViewList().get(mCurrPos), distance_y, keyCode);
			}else {
				mCurrPos++;
				WLUIUtils.playSoundEffect(mContainer.getViewList().get(mCurrPos), -1);	
			}
			return true;
		}
		if(keyCode == KeyEvent.KEYCODE_DPAD_RIGHT){
			if(mCurrPos == mItemCount - 1){
				if(mOnLoaderControl != null && mOnLoaderControl.nextPage()){
					return true;
				}else{
					WLUIUtils.playSoundEffect(mContainer.getViewList().get(mCurrPos), -1);
					return true;
				}
			}
			perPos = mCurrPos;
			mCurrPos++;
			if(mCurrPos <= mItemCount - 1){
				int distance_y = 0;
				per_item = mContainer.getViewList().get(perPos);
				this.getGlobalVisibleRect(mRect);
				int topMost = mRect.bottom - mRect.top;
				mContainer.getViewList().get(mCurrPos).getLocationInWindow(mLocation);
				this.getLocationInWindow(mParentLayoutLocation);
				int yPos = mLocation[1] - mParentLayoutLocation[1];
				if(yPos + default_item_height > topMost){
					if(mListener != null){
						mListener.onScroll(SCROLL_DOWN);
					}
					distance_y = default_item_height;
				}
				per_item.setSelected(false);
				setCurrentView(mContainer.getViewList().get(mCurrPos), distance_y, keyCode);
			}else{
				mCurrPos--;
				WLUIUtils.playSoundEffect(mContainer.getViewList().get(mCurrPos), -1);
			}
			return true;
		}
		if(keyCode == KeyEvent.KEYCODE_DPAD_DOWN){
			if(mCurrPos == mItemCount -1){
				if(mOnLoaderControl != null && mOnLoaderControl.nextPage()){
					return true;
				}else{
					WLUIUtils.playSoundEffect(mContainer.getViewList().get(mCurrPos), -1);
					return true;
				}
			}
			perPos = mCurrPos;
			mCurrPos += MAX_ROW_COUNT;
			if(mCurrPos > mItemCount -1){
				if(mOnLoaderControl != null && mOnLoaderControl.nextPage()){
					mCurrPos -= MAX_ROW_COUNT;
					return true;
				}else if ((perPos / MAX_ROW_COUNT) != ((mItemCount -1) / MAX_ROW_COUNT)){//保护下 是不是最后一行
					mCurrPos = mItemCount - 1;
				}
			}
			if(mCurrPos <= mItemCount -1){
				int distance_y = 0;
				per_item = mContainer.getViewList().get(perPos);
				this.getGlobalVisibleRect(mRect);
				int topMost = mRect.bottom - mRect.top;
				mContainer.getViewList().get(mCurrPos).getLocationInWindow(mLocation);
				this.getLocationInWindow(mParentLayoutLocation);
				int yPos = mLocation[1] - mParentLayoutLocation[1];
				if(yPos + default_item_height > topMost){
					if(mListener != null){
						mListener.onScroll(SCROLL_DOWN);	
					}
					distance_y = default_item_height;
				}
				per_item.setSelected(false);
				setCurrentView(mContainer.getViewList().get(mCurrPos), distance_y, keyCode);
			}else {
				mCurrPos -= MAX_ROW_COUNT;
				WLUIUtils.playSoundEffect(mContainer.getViewList().get(mCurrPos), -1);
			}
			return true;
		}
		if(keyCode == KeyEvent.KEYCODE_DPAD_UP){
			perPos = mCurrPos;
			int distance_y = 0;
			mCurrPos -= MAX_ROW_COUNT;
			if(mCurrPos >= 0){
				per_item = mContainer.getViewList().get(perPos);
				mContainer.getViewList().get(mCurrPos).getLocationInWindow(mLocation);
				this.getLocationInWindow(mParentLayoutLocation);
				int yPos = mLocation[1] - mParentLayoutLocation[1];
				if(yPos < 0){
					if(mListener != null){
						mListener.onScroll(SCROLL_UP);
					}
					distance_y = -default_item_height;
				}else {
					if(hasPlaceHolder){
						if(yPos < default_item_height-2) {
							if(mListener != null){
								mListener.onScroll(SCROLL_UP);
							}
							distance_y = -default_item_height;
						}
					}
				} 
				per_item.setSelected(false);
				setCurrentView(mContainer.getViewList().get(mCurrPos), distance_y, keyCode);
			}else {
				mCurrPos += MAX_ROW_COUNT;
				WLUIUtils.playSoundEffect(mContainer.getViewList().get(mCurrPos), -1);	
			}
			return true;
		}
		
		if(KeyEvent.KEYCODE_ENTER == keyCode
				|| KeyEvent.KEYCODE_DPAD_CENTER == keyCode
				|| KeyEvent.KEYCODE_BUTTON_A == keyCode){
			if(mOnLoaderControl != null){
				GameItem gameInfo = mContainer.getViewList().get(mCurrPos).data();
				mOnLoaderControl.onClick(gameInfo, mCurrPos);
			}
			return true;
		}
		return false;
	}
	
	public void release(){
		if(mContainer != null){
			ViewUtils.unbindDrawables(mContainer);
			mContainer = null;
		}
	}
}
