package com.xiaomi.mibox.gamecenter.ui.view;

import android.os.Build;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.utils.DrawableCache;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 
 * @author liubiqiang
 *
 */
public class SummaryView extends LinearLayout{
	
	private TextView mSizeView;//包的大小
	private TextView mDownloadCountView;//下载量

	public SummaryView(Context context) {
	    this(context, null, 0);        
	}
	
	public SummaryView(Context context, AttributeSet as, int Uistyle) {
        super(context, as, Uistyle);
        init(context);
    }
	
	public SummaryView(Context context, AttributeSet as) {
        this(context, as, 0);
    }
	
	public void setSizeText(CharSequence size){
		mSizeView.setText(size);
	}
	
	public void setDownloadCountText(CharSequence download){
		mDownloadCountView.setText(download);
	}

	private void init(Context context){
		this.setOrientation(LinearLayout.HORIZONTAL);
		
		LinearLayout.LayoutParams llp;
		mSizeView = createTextView(context);
		llp = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.WRAP_CONTENT,
				LinearLayout.LayoutParams.WRAP_CONTENT);
		llp.gravity = Gravity.CENTER_VERTICAL;
		this.addView(mSizeView, llp);
		
		ImageView dividerView = new ImageView(context);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
		    dividerView.setBackground(DrawableCache.getInstance().loadByResId(R.drawable.divider));
        else
            dividerView.setBackgroundDrawable(DrawableCache.getInstance().loadByResId(R.drawable.divider));

		llp = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.WRAP_CONTENT,
				LinearLayout.LayoutParams.WRAP_CONTENT);
		llp.gravity = Gravity.CENTER_VERTICAL;
		this.addView(dividerView, llp);
		
		mDownloadCountView = createTextView(context);
		llp = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.WRAP_CONTENT,
				LinearLayout.LayoutParams.WRAP_CONTENT);
		llp.gravity = Gravity.CENTER_VERTICAL;
		this.addView(mDownloadCountView, llp);
	}
	
	private TextView createTextView(Context context){
		TextView textView = new TextView(context);
		textView.setTextColor(Color.WHITE);
		textView.setTextSize(14);
		textView.setSingleLine(true);
		textView.setEllipsize(TruncateAt.END);
		textView.setGravity(Gravity.CENTER);
		return textView;
	}
}
