package com.xiaomi.mitv.store.video;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import com.tv.ui.metro.model.VideoItem;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.ui.view.SmoothGridView;
import com.xiaomi.mibox.gamecenter.ui.view.VideoSeazons;
import com.xiaomi.mibox.gamecenter.utils.Client;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mitv.app.view.TitleBar;
import com.xiaomi.mitv.store.XiaomiUIHelper;

import java.util.ArrayList;

/**
 * Created by liuhuadong on 9/24/14.
 */
public class VideoRelativesActivity extends XiaomiUIHelper {
    TitleBar mTitleBar;
    SmoothGridView gridView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.video_album_detail);

        mTitleBar = (TitleBar) this.findViewById(R.id.video_title_bar);
        mTitleBar.setTitle(item.name);
        gridView = (SmoothGridView) findViewById(R.id.list_content);

        gridView.setOnItemSelectedListener(focusListener);

        updateUI();
    }

    View firstView;
    View preView;
    AdapterView.OnItemSelectedListener focusListener = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            if(view != null){
                //view.requestFocus();
                if(preView != null) {
                    preView.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start();
                    preView.findViewById(R.id.video_item_cover).setVisibility(View.GONE);
                }


                //remove first view status
                int pos = adapterView.getSelectedItemPosition();
                if(pos != 0 && firstView != null && justNeedDoOneTime_DONE == false){
                    adapterView.getChildAt(0).animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start();
                    adapterView.getChildAt(0).findViewById(R.id.video_item_cover).setVisibility(View.GONE);
                    firstView = null;
                    justNeedDoOneTime_DONE = true;
                }

                view.findViewById(R.id.video_item_cover).setVisibility(View.VISIBLE);//.setBackgroundResource(R.drawable.item_highlight);
                view.animate().scaleX(1.1f).scaleY(1.1f).setDuration(200).alpha(1.0f).start();
                preView = view;
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
            adapterView.setSelection(0);
        }
    };


    public void updateUI() {
        if(!TextUtils.isEmpty(item.name)){
            mTitleBar.setTitle(item.name);
        }

        //update UI
        RelativeAdapter adapter = new RelativeAdapter(((VideoItem)item).videos);
        gridView.setAdapter(adapter);
        gridView.setOnItemClickListener(itemClicker);
    }


    AdapterView.OnItemClickListener itemClicker = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            try {
                String videoUrl = ((VideoItem)item).videos.get(i).urls.get("high");
                if(videoUrl == null) {
                    videoUrl = ((VideoItem) item).videos.get(i).urls.get("super");
                }

                if(Client.isTV2()){
                    Intent intent = new Intent();
                    intent.setAction(Constants.MITV_VIDEO_INTENT_ACTION);
                    intent.setData(Uri.parse(videoUrl));

                    try{
                        startActivity(intent);
                    }catch(Exception e){
                        Intent videoIntent = new Intent(getApplicationContext(), PlayerActivity.class);
                        videoIntent.putExtra("video_url", videoUrl);
                        startActivity(videoIntent);
                    }
                }else {
                    Intent videoIntent = new Intent(getApplicationContext(), PlayerActivity.class);
                    videoIntent.putExtra("video_url", videoUrl);
                    startActivity(videoIntent);
                }

            }catch (Exception ne){}
        }
    };


    boolean justNeedDoOneTime_DONE=false;
    public class RelativeAdapter extends BaseAdapter {
        public RelativeAdapter(ArrayList<VideoItem.Video> content){
            super();
            items = content;
        }

        private ArrayList<VideoItem.Video> items;

        @Override
        public int getCount() {
            return items==null?0:items.size();
        }

        @Override
        public Object getItem(int i) {
            return items==null?new Object():items.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }


        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            VideoSeazons root = null;
            if(view == null) {
                root = new VideoSeazons(getBaseContext());
            }else{
                root = (VideoSeazons)view;
            }

            root.setTag(getItem(i));
            root.setContent((VideoItem.Video) getItem(i));

            if(i == 0 && justNeedDoOneTime_DONE == false){
                firstView = root;
                root.findViewById(R.id.video_item_cover).setVisibility(View.VISIBLE);
                root.animate().scaleX(1.1f).scaleY(1.1f).setDuration(200).alpha(1.0f).start();
            }
            return root;
        }
    }
}