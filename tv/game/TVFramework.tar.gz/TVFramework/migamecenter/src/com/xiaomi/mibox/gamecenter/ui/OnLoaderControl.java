package com.xiaomi.mibox.gamecenter.ui;

import com.tv.ui.metro.model.DisplayItem;

public interface OnLoaderControl {
	public boolean nextPage();
	public void onClick(DisplayItem item, int pos);
}

