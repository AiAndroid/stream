package com.xiaomi.mibox.gamecenter.data.localservice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * 可配置多个消息，目前的消息有，安装/卸载.
 * Receiver接收到消息后立刻将消息转入Service处理
 * @author smokelee
 *
 */
public class GlobalReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) 
	{
		intent.setClass(context, GlobalService.class);
		context.startService(intent);
	}

}
