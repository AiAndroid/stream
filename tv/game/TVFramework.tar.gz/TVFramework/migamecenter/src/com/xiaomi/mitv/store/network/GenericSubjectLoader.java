package com.xiaomi.mitv.store.network;

import android.content.Context;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.VolleyHelper;
import com.google.gson.reflect.TypeToken;
import com.tv.ui.metro.loader.BaseGsonLoader;
import com.tv.ui.metro.model.*;

/**
 * Created by liuhuadong on 9/16/14.
 */
public abstract class GenericSubjectLoader<T> extends BaseGsonLoader<GenericSubjectItem<T>>{
    public static int GAME_SUBJECT_LOADER_ID    = 0x801;
    public static int VIDEO_SUBJECT_LOADER_ID   = 0x901;
    public GenericSubjectLoader(Context con, DisplayItem item){
        super(con, item);
    }

    public static GenericSubjectLoader<GameItem> generateGameSubjectLoader(Context con, DisplayItem item){
        GenericSubjectLoader<GameItem> loader = new GenericSubjectLoader<GameItem>(con, item){

            @Override
            public void setCacheFileName() {
                cacheFileName = "game_album_";
            }

            @Override
            protected void loadDataByGson() {
                RequestQueue requestQueue = VolleyHelper.getInstance(getContext().getApplicationContext()).getAPIRequestQueue();
                GsonRequest<GenericSubjectItem<GameItem>> gsonRequest = new GsonRequest<GenericSubjectItem<GameItem>>(calledURL, new TypeToken<GenericSubjectItem<GameItem>>(){}.getType(), null, listener, errorListener);
                gsonRequest.setCacheNeed(getContext().getCacheDir() + "/" + cacheFileName + mItem.id + ".cache");
                requestQueue.add(gsonRequest);
            }
        };
        return  loader;
    }

    public static GenericSubjectLoader<VideoItem> generateVideoSubjectLoader(Context con, DisplayItem item){
        GenericSubjectLoader<VideoItem> loader = new GenericSubjectLoader<VideoItem>(con, item){
            @Override
            public void setCacheFileName() {
                cacheFileName = "video_album_";
            }

            @Override
            protected void loadDataByGson() {
                RequestQueue requestQueue = VolleyHelper.getInstance(getContext().getApplicationContext()).getAPIRequestQueue();
                GsonRequest<GenericSubjectItem<VideoItem>> gsonRequest = new GsonRequest<GenericSubjectItem<VideoItem>>(calledURL, new TypeToken<GenericSubjectItem<VideoItem>>(){}.getType(), null, listener, errorListener);
                gsonRequest.setCacheNeed(getContext().getCacheDir() + "/" + cacheFileName + mItem.id + ".cache");
                requestQueue.add(gsonRequest);
            }
        };
        return  loader;
    }

    @Override
    public void setLoaderURL(DisplayItem _item) {
        mItem = _item;
        String url = CommonUrl.BaseURL + mItem.ns + "/" + mItem.type + "?id=" + mItem.id + "&page="+page;
        calledURL = new CommonUrl(getContext()).addCommonParams(url);
    }

    public boolean hasMoreData() {
        if(mResult != null && mResult.data.get(0).items.size() == page_size){
            return  true;
        }
        return false;
    }

    public boolean isLoading() {
        return mIsLoading;
    }

    public void nextPage() {
        page++;

        String url = CommonUrl.BaseURL + mItem.ns + "/" + mItem.type + "?id=" + mItem.id + "&page="+page;
        calledURL = new CommonUrl(getContext()).addCommonParams(url);
        loadDataByGson();
    }
}
