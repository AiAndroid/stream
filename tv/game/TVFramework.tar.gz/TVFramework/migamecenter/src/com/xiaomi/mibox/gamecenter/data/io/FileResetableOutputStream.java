package com.xiaomi.mibox.gamecenter.data.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

class FileResetableOutputStream extends ResetableOutputStream {
    private File mFile;

    public FileResetableOutputStream(File file) throws FileNotFoundException {
        super(new FileOutputStream(file));
        mFile = file;
    }

    @Override
    public void reset() {
        try {
            mOutputStream.close();
        } catch (IOException e) {
            // do nothing
        	if(e != null) e.printStackTrace();
        }
        mFile.delete();
        try {
            mOutputStream = new FileOutputStream(mFile);
        } catch (FileNotFoundException e) {
            // 这里不会执行到，构造方法会抛出异常
        	if(e != null) e.printStackTrace();
        }
    }
}
