package com.xiaomi.xmsf.account.utils;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.json.JSONException;
import org.json.JSONObject;

import miui.accounts.ExtraAccountManager;
import miui.cloud.AccountUtils;
import miui.cloud.CloudCoder;
import miui.cloud.CloudManager;
import miui.cloud.ExtendedAuthToken;
import miui.cloud.SecureRequest;
import miui.cloud.SimpleRequest;
import miui.cloud.exception.AccessDeniedException;
import miui.cloud.exception.AuthenticationFailureException;
import miui.cloud.exception.CipherException;
import miui.cloud.exception.InvalidResponseException;
import android.accounts.Account;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.account.IQueryUserInfo;
import com.xiaomi.xmsf.account.data.AccountInfo;
import com.xiaomi.xmsf.account.data.XiaomiUserInfo;
import com.xiaomi.xmsf.account.exception.InvalidCredentialException;
import com.xiaomi.xmsf.account.exception.InvalidUserNameException;
import com.xiaomi.xmsf.account.exception.NeedCaptchaException;
import com.xiaomi.xmsf.account.exception.NeedVerificationException;

/**
 * Helper class to perform account related tasks.
 */
public final class CloudHelper {

	private static final String TAG = "CloudHelper";

	public static final boolean USE_PREVIEW = new File(
			"/data/system/account_preview").exists();

	// Base url of APIs used to query user-specific info
	public static final String URL_ACCOUNT_SAFE_API_BASE = USE_PREVIEW ? "http://api.account.preview.n.xiaomi.net/pass/v2/safe"
			: "http://api.account.xiaomi.com/pass/v2/safe";

	public static final String API_SAFE_URL_BASE = URL_ACCOUNT_SAFE_API_BASE;
	public static final String URL_GET_USER_CORE_INFO = API_SAFE_URL_BASE
			+ "/user/%s/coreInfo";
	private static final Integer INT_0 = 0;
	private static final String ICON_SIZE_SUFFIX = "_320";
//	private static final String ICON_SMALL_SIZE_SUFFIX = "_150";
//	private static final String ICON_SIZE_SUFFIX = "_120";
	private static final int USER_ADDR_TYPE_PHONE = 1;

	private static final int USER_ADDR_TYPE_EMAIL = 2;

	private static final int USER_ADDR_TYPE_ALIAS = 9;
	private static final String PASSPORT_SID = "passport";
	public static final String ACCOUNT_URL_BASE = CloudManager.URL_ACCOUNT_BASE;
	public static final String URL_LOGIN = ACCOUNT_URL_BASE + "/serviceLogin";
	private static final String SAFE_PREFIX = "&&&START&&&";
	private static final int RESULT_CODE_SUCCESS = 0;
	private static final int RESULT_CODE_USERNAME = 20003;
	private static final int RESULT_CODE_PASSWORD = 70016;
	private static final int RESULT_CODE_CAPTCHA = 87001;
	private static final int RESULT_CODE_VERIFICATION = 81003;
//	private static final int RESULT_CODE_REGISTERED_PHONE = 25001;

	public static void handleQueryUserInfo2(final Activity context,
			final IQueryUserInfo callback) {
		new Thread() {
			@Override
			public void run() {
				Account account = ExtraAccountManager.getXiaomiAccount(context);
				if (account == null) {
					if (callback != null) {
						callback.onFinish(IQueryUserInfo.QUERY_USER_INFO_FAIL, null);
					}
					if (IConfig.DEBUG){
						Log.w(TAG, "no Xiaomi account, skip to query user info");
					}
					return;
				}
				final String userId = account.name;
				final ExtendedAuthToken passToken = AccountUtils.getPassToken(
						context, account);
				boolean retry = true;
				int authFailureCount = 0;
				while (!Thread.currentThread().isInterrupted() && retry) {
					retry = false;
					if (passToken != null) {
						String token = passToken.authToken;
						String security = passToken.security;// bundle.getString(CloudManager.KEY_USER_SECURITY);
						if (token != null && security != null) {
							XiaomiUserInfo userInfo = null;
							try {
								userInfo = CloudHelper.getXiaomiUserInfo(
										userId, token, security);
							} catch (InvalidResponseException e) {
								Log.e(TAG,"invalid response when get user info",e);
							} catch (CipherException e) {
								Log.e(TAG,"CipherException when get user info", e);
							} catch (IOException e) {
								Log.e(TAG, "IOException when get user info", e);
							} catch (AuthenticationFailureException e) {
								Log.e(TAG, "auth failure when get user info", e);
								// cm.invalidateUserSecurity(token, security);
								++authFailureCount;
								if (authFailureCount < 2) {
									retry = true;
								}
							} catch (AccessDeniedException e) {
								Log.e(TAG, "access denied when get user info",
										e);
							}
							if (userInfo != null) {
								if (callback != null) {
									callback.onFinish(
											IQueryUserInfo.QUERY_USER_INFO_SUCCESS, 
											userInfo);
									return;
								}
							}
						}
					}
				}// end of while
				if (callback != null) {
					callback.onFinish(IQueryUserInfo.QUERY_USER_INFO_FAIL, null);
				}
			}
		}.start();
	}

	static XiaomiUserInfo getXiaomiUserInfo(String userId,
			String serviceToken, String security)
			throws InvalidResponseException, CipherException, IOException,
			AuthenticationFailureException, AccessDeniedException {
		EasyMap<String, String> cookies = new EasyMap<String, String>()
				.easyPut("userId", userId)
				.easyPut("serviceToken", serviceToken);
		String url = String.format(URL_GET_USER_CORE_INFO, userId);
		SimpleRequest.MapContent mapContent = SecureRequest.getAsMap(url, null,
				cookies, true, security);
		Object code = mapContent.getFromBody("code");
		if (INT_0.equals(code)) {
			Object data = mapContent.getFromBody("data");
			if (data instanceof Map) {
				XiaomiUserInfo userInfo = new XiaomiUserInfo(userId);
				Map<?, ?> dataMap = (Map<?, ?>) data;
				Object userNameObj = dataMap.get("userName");
				Object userAddressesObj = dataMap.get("userAddresses");
				if (userNameObj instanceof String) {
					userInfo.setUserName((String) userNameObj);
				}
				Object avatarAddrObj = dataMap.get("icon");
				if (avatarAddrObj instanceof String) {
					String avatarAddress = (String) avatarAddrObj;
					int lastDotPosition = avatarAddress.lastIndexOf(".");
					if (avatarAddress.length() > 0 && lastDotPosition > 0) {
						// protection in case that address is "" or invalid
						// string
						String absoluteName = avatarAddress.substring(0,
								lastDotPosition); // absolute name without file
													// type
						String fileType = avatarAddress.substring(avatarAddress
								.lastIndexOf(".")); // file type suffix
						userInfo.setAvatarAddress(absoluteName
								+ ICON_SIZE_SUFFIX + fileType);
					}
				}
				if (userAddressesObj instanceof List) {
					List<?> userAddressList = (List<?>) userAddressesObj;
					for (Object userAddrObj : userAddressList) {
						if (userAddrObj instanceof Map) {
							Map<?, ?> userAddrMap = (Map<?, ?>) userAddrObj;
							Object addrTypeObj = userAddrMap.get("addressType");
							Object addrObj = userAddrMap.get("address");
							Object secureObj = userAddrMap.get("flags");
							if (addrTypeObj instanceof Integer
									&& addrObj instanceof String) {
								Integer addrType = (Integer) addrTypeObj;
								String address = (String) addrObj;
								Integer secureFlag = INT_0;
								if (secureObj instanceof Integer) {
									secureFlag = (Integer) secureObj;
								}
								boolean secure = ((secureFlag & 2) != 0); // wiki:flags&2
																			// !=
																			// 0(按位与)
																			// 表示是一个密保地址。
								switch (addrType) {
								case USER_ADDR_TYPE_PHONE:
									if (secure) {
										// only secure address matters
										userInfo.setPhone(address);
									}
									break;
								case USER_ADDR_TYPE_EMAIL:
									if (secure) {
										// only secure address matters
										userInfo.setEmail(address);
									}
									break;
								case USER_ADDR_TYPE_ALIAS:
									int spIndex = address.lastIndexOf("@ALIAS");
									if (spIndex > 0) {
										address = address.substring(0, spIndex);
									}
									userInfo.setNickName(address);
									break;
								}
							}
						}
					}
				}
				return userInfo;
			}
		}
		throw new InvalidResponseException("failed to get user info");
	}

	/**
	 * 查询小米账户信息 需要缓存么?
	 * 
	 * @param context
	 * @param handler
	 * @param msgWhat
	 */
	public static void handleQueryUserInfo(final Context context,
			final Handler handler, final int msgWhat) {
		new Thread() {
			@Override
			public void run() {
				Account account = ExtraAccountManager.getXiaomiAccount(context);
				if (account == null) {
					if (IConfig.DEBUG)
						Log.w(TAG, "no Xiaomi account, skip to query user info");
					return;
				}
				final String userId = account.name;

				CloudManager cm = CloudManager.get(context);
				boolean retry = true;
				int authFailureCount = 0;
				while (!Thread.currentThread().isInterrupted() && retry) {
					retry = false;
					CloudManager.CloudManagerFuture<Bundle> f = null;
					try {
						f = cm.getUserSecurity();
					} catch (Exception e) {
						e.printStackTrace();
						return;
					}
					Bundle bundle = null;
					try {
						bundle = f.getResult();
					} catch (Exception e) {
						Log.e(TAG, "error when get user security", e);
					}
					if (bundle != null) {
						String token = bundle
								.getString(CloudManager.KEY_USER_TOKEN);
						String security = bundle
								.getString(CloudManager.KEY_USER_SECURITY);
						if (token != null && security != null) {
							XiaomiUserInfo userInfo = null;
							try {
								userInfo = CloudHelper.getXiaomiUserInfo(
										userId, token, security);
							} catch (InvalidResponseException e) {
								Log.e(TAG,
										"invalid response when get user info",
										e);
							} catch (CipherException e) {
								Log.e(TAG,
										"CipherException when get user info", e);
							} catch (IOException e) {
								Log.e(TAG, "IOException when get user info", e);
							} catch (AuthenticationFailureException e) {
								Log.e(TAG, "auth failure when get user info", e);
								cm.invalidateUserSecurity(token, security);
								++authFailureCount;
								if (authFailureCount < 2) {
									retry = true;
								}
							} catch (AccessDeniedException e) {
								Log.e(TAG, "access denied when get user info",
										e);
							}
							if (userInfo != null) {
								if (IConfig.DEBUG) {
									StringBuilder sb = new StringBuilder();
									String xiaomiId = userInfo.getUserId();
									sb.append("XiaomiId:" + xiaomiId);
									sb.append("\n");
									String nickName = userInfo.getUserName();
									sb.append("昵称:" + nickName);
									sb.append("\n");
									String phoneNumber = userInfo.getPhone();
									sb.append("电话号码:" + phoneNumber);
									sb.append("\n");
									String avtarUrl = userInfo
											.getAvatarAddress();
									sb.append("avtarUrl:" + avtarUrl);
									sb.append("\n");
									String email = userInfo.getEmail();
									sb.append("电子邮件:" + email);
									sb.append("\n");
									Log.e(TAG, sb.toString());
								}

								if (handler != null) {
									Message msg = handler
											.obtainMessage(msgWhat);
									msg.obj = userInfo;
									handler.sendMessage(msg);
								}
							}
						}
					}
				}
			}
		}.start();
	}

	public static AccountInfo getServiceTokenByPassToken(Context context,
			String userId, String passToken, String serviceId)
			throws IOException, InvalidResponseException,
			InvalidCredentialException, AccessDeniedException,
			AuthenticationFailureException, InvalidUserNameException {
		if (TextUtils.isEmpty(serviceId)) {
			serviceId = PASSPORT_SID;
		}

		EasyMap<String, String> params = new EasyMap<String, String>()
				.easyPutOpt("sid", serviceId).easyPut("_json", "true");

		String deviceId = hashDeviceInfo(getDeviceId(context));
		EasyMap<String, String> cookies = new EasyMap<String, String>()
				.easyPut("userId", userId).easyPut("deviceId", deviceId)
				.easyPutOpt("passToken", passToken);

		SimpleRequest.StringContent loginContent = SimpleRequest.getAsString(
				URL_LOGIN, params, cookies, true);
		if (loginContent == null) {
			throw new IOException("failed to get response from service server");
		}
		try {
			return processLoginContent(loginContent, serviceId);
		} catch (NeedVerificationException e) {
			throw new InvalidResponseException(
					"Unexpected NeedVerificationException");
		} catch (NeedCaptchaException e) {
			throw new InvalidResponseException(
					"Unexpected NeedCaptchaException");
		}
	}

	protected static AccountInfo processLoginContent(
			SimpleRequest.StringContent loginContent, String serviceId)
			throws InvalidResponseException, InvalidCredentialException,
			IOException, AccessDeniedException, NeedVerificationException,
			NeedCaptchaException, InvalidUserNameException {
		String body = loginContent.getBody();
		Log.e("", body);
		if (!body.startsWith(SAFE_PREFIX)) {

			throw new InvalidResponseException("Result does not start with "
					+ SAFE_PREFIX);
		}
		try {
			String realBody = body.substring(SAFE_PREFIX.length());
			JSONObject o = new JSONObject(realBody);
			int code = o.getInt("code");
			switch (code) {
			case RESULT_CODE_SUCCESS: {
				// location where to get the service token
				String userId = loginContent.getHeader("userId");
				String passToken = loginContent.getHeader("passToken");
				String extParams = loginContent.getHeader("extension-pragma");

				if (TextUtils.isEmpty(userId)) {
					throw new InvalidResponseException("no user Id");
				}
				if (TextUtils.isEmpty(passToken)) {
					throw new InvalidResponseException(
							"no passToken in login response");
				}

				if (TextUtils.isEmpty(extParams)) {
					throw new InvalidResponseException("empty extension-pragma");
				}
				String security = null;
				Long nonce = null;
				String psecurity = null;
				try {
					JSONObject jObj = new JSONObject(extParams);
					security = jObj.optString("ssecurity");
					nonce = jObj.optLong("nonce");
					psecurity = jObj.optString("psecurity");
				} catch (JSONException e) {
					// ignore
				}

				if (security == null || nonce == null || psecurity == null) {
					throw new InvalidResponseException(
							"security, nonce or psecurity is null");
				}

				if (TextUtils.isEmpty(serviceId)
						|| PASSPORT_SID.equals(serviceId)) {
					// no need to request service token, return result now
					return new AccountInfo(userId, passToken, psecurity);
				}

				String clientSign = getClientSign(nonce, security);
				if (clientSign == null) {
					Log.e(TAG, "failed to get client sign");
					throw new InvalidResponseException(
							"sign parameters failure");
				}
				EasyMap<String, String> params = new EasyMap<String, String>(
						"clientSign", clientSign);
				SimpleRequest.StringContent serviceTokenContent = null;
				String serviceTokenLocation = o.getString("location");
				try {
					serviceTokenContent = SimpleRequest.getAsString(
							serviceTokenLocation, params, null, false);
				} catch (AuthenticationFailureException e) {
					Log.w(TAG, "processLoginContent", e);
				}
				if (serviceTokenContent == null) {
					throw new InvalidResponseException(
							"no response when get service token");
				}
				String serviceToken = serviceTokenContent
						.getHeader("serviceToken");
				if (TextUtils.isEmpty(serviceToken)) {
					throw new InvalidResponseException(
							"no service token contained in response");
				}
				return new AccountInfo(userId, passToken, serviceToken,
						security, psecurity);
			}
			case RESULT_CODE_USERNAME: {
				throw new InvalidUserNameException();
			}
			case RESULT_CODE_PASSWORD: {
				String sign = o.getString("_sign");
				String qs = o.getString("qs");
				String callback = o.getString("callback");
				String captchaUrl = o.getString("captchaUrl");
				if (TextUtils.equals("null", captchaUrl)) {
					captchaUrl = null;
				}
				throw new InvalidCredentialException(new MetaLoginData(sign,
						qs, callback), captchaUrl);
			}
			case RESULT_CODE_CAPTCHA: {
				String captchaUrl = o.getString("captchaUrl");
				throw new NeedCaptchaException(captchaUrl);
			}
			case RESULT_CODE_VERIFICATION: {
				String sign = o.getString("_sign");
				String qs = o.getString("qs");
				String callback = o.getString("callback");
				String step1Token = loginContent.getHeader("step1Token");
				throw new NeedVerificationException(new MetaLoginData(sign, qs,
						callback), step1Token);
			}
			default: {
				throw new InvalidResponseException("Unknown result code "
						+ code);
			}
			}
		} catch (JSONException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * hash deviceId or imsi
	 * 
	 * @param plain
	 *            plain representation of device id or imsi
	 * @return 16 bytes long hash value
	 */
	private static String hashDeviceInfo(String plain) {
		return CloudCoder.hashDeviceInfo(plain);
	}

	protected static String getClientSign(Long nonce, String security) {
		TreeMap<String, String> params = new TreeMap<String, String>();
		params.put("nonce", String.valueOf(nonce));
		return CloudCoder.generateSignature(null, null, params, security);
	}

	private static String getDeviceId(Context context) {
		String deviceId = Settings.Secure.getString(
				context.getContentResolver(), "android_id");
		if (null == deviceId) {
			return "";
		} else {
			return deviceId;
		}
		// TelephonyManager tm =
		// (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
		// if(tm != null){
		// return tm.getDeviceId();
		// }else{
		// return null;
		// }
	}
}
