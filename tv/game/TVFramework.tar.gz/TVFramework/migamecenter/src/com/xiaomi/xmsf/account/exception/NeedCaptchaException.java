package com.xiaomi.xmsf.account.exception;

public class NeedCaptchaException extends CloudServiceException {
    private static final long serialVersionUID = 1L;

    private final String mCaptchaUrl;

    public NeedCaptchaException(String captchaUrl) {
        super("Need captcha code or wrong captcha code");
        mCaptchaUrl = captchaUrl;
    }

    public String getCaptchaUrl() {
        return mCaptchaUrl;
    }
}
