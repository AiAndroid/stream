package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import android.util.AttributeSet;
import com.xiaomi.mibox.gamecenter.R;
import android.content.Context;
import android.util.SparseArray;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * 图片标识位置
 * @author mengshu
 *
 */
public class QSeekBarPositionView extends LinearLayout implements OnSeekBarListener {

    private static final int SCREENSHOT_DEFAULT_COUNT = 4;
	private SparseArray<ImageView> mViewLists;
	private int mKey = 0;
	private int mTotalCount = SCREENSHOT_DEFAULT_COUNT;
	
	public QSeekBarPositionView(Context context) {
		this(context, null, 0);
	}

    public QSeekBarPositionView(Context context, AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);
        init(context);
    }

    public QSeekBarPositionView(Context context, AttributeSet as) {
        this(context, as, 0);
    }
	
	private void init(Context context){
		this.setOrientation(LinearLayout.HORIZONTAL);
		
		mViewLists = new SparseArray<ImageView>(4);
		
		for(int i = 0; i < SCREENSHOT_DEFAULT_COUNT; i++){
			addBarView(0 == i);
		}
	}
	
	private void addBarView(boolean first){
		ImageView imageView = new ImageView(getContext());
		imageView.setImageResource(R.drawable.screen_view_seekpoint_normal);
		LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.WRAP_CONTENT,
				LinearLayout.LayoutParams.WRAP_CONTENT);
		if(!first){
			llp.leftMargin = getResources().getDimensionPixelSize(R.dimen.seekbar_left_margin);
		}
		llp.gravity = Gravity.CENTER_VERTICAL;
		this.addView(imageView, llp);
		
		mViewLists.put(mKey, imageView);
		mKey++;
	}

	@Override
	public void seerBarTotal(int total) {
		ImageView imageView = null;
		if(total < mTotalCount){
			for(int i = mTotalCount - 1; i >= total; i--){
				mKey--;
				imageView = mViewLists.get(mKey);
				this.removeView(imageView);
				mViewLists.remove(mKey);
			}
		}else if(total > mTotalCount){
			for(int i = 0; i < total - mTotalCount; i++){
				addBarView(false);
			}
		}
		
		mTotalCount = total;
	}

	@Override
	public void seekBarPositionChanged(int newPos) {
		for(int i = 0; i < mTotalCount; i++){
			if(i == newPos){
				mViewLists.get(i).setImageResource(
						R.drawable.screen_view_seekpoint_highlight);
			}else{
				mViewLists.get(i).setImageResource(
						R.drawable.screen_view_seekpoint_normal);
			}
		}
	}
}
