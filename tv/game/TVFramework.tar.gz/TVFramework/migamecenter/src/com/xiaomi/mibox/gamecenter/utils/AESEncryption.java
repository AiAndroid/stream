package com.xiaomi.mibox.gamecenter.utils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import android.text.TextUtils;

/**
 * AES加密解密
 * 
 * @author smokelee
 * 
 */
final public class AESEncryption
{
	/**
	 * AES加密
	 * @param sSrc
	 * @param sKey
	 * @return
	 * @throws Exception
	 */
	public static byte[] Encrypt(String sSrc, String sKey) throws Exception
	{
		if (TextUtils.isEmpty(sKey))
		{
			throw new IllegalArgumentException("Key is null");
		}
		// 判断Key是否为16位
		if (sKey.length() != 16)
		{
			throw new IllegalArgumentException("Key length != 16");
		}
		byte[] raw = sKey.getBytes();
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");// "算法/模式/补码方式"
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		return cipher.doFinal(sSrc.getBytes());
	}
	
	/**
	 * AES加密
	 * @param sSrc
	 * @param sKey
	 * @return
	 * @throws Exception
	 */
	public static byte[] Encrypt(byte[] data, String sKey) throws Exception
	{
		if (TextUtils.isEmpty(sKey))
		{
			throw new IllegalArgumentException("Key is null");
		}
		// 判断Key是否为16位
		if (sKey.length() != 16)
		{
			throw new IllegalArgumentException("Key length != 16");
		}
		byte[] raw = sKey.getBytes();
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");// "算法/模式/补码方式"
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		return cipher.doFinal(data);
	}

	/**
	 * AES解密
	 * @param src
	 * @param sKey
	 * @return
	 * @throws Exception
	 */
	public static byte[] Decrypt(byte[] src, String sKey) throws Exception
	{
		if (sKey == null)
		{
			throw new IllegalArgumentException("Key is null");
		}
		// 判断Key是否为16位
		if (sKey.length() != 16)
		{
			throw new IllegalArgumentException("Key length != 16位");
		}
		byte[] raw = sKey.getBytes();
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, skeySpec);
		return cipher.doFinal(src);
	}

	/**
	 * Hex字符串转化为Byte数组
	 * @param strhex
	 * @return
	 */
	public static byte[] hex2byte(String strhex)
	{
		if (strhex == null)
		{
			return null;
		}
		int l = strhex.length();
		if (l % 2 == 1)
		{
			return null;
		}
		byte[] b = new byte[l / 2];
		for (int i = 0; i != l / 2; i++)
		{
			b[i] = (byte) Integer.parseInt(strhex.substring(i * 2, i * 2 + 2),
					16);
		}
		return b;
	}

	/**
	 * Byte数组转化为Hex字符串
	 * @param b
	 * @return
	 */
	public static String byte2hex(byte[] b)
	{
		String hs = "";
		String stmp = "";
		for (int n = 0; n < b.length; n++)
		{
			stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
			if (stmp.length() == 1)
			{
				hs = hs + "0" + stmp;
			} else
			{
				hs = hs + stmp;
			}
		}
		return hs.toUpperCase();
	}

}
