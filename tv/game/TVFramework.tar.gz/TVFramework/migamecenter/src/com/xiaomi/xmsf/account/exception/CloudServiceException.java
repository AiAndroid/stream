package com.xiaomi.xmsf.account.exception;

public class CloudServiceException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 4885516352073039694L;

	public CloudServiceException(String detailMessage) {
        super(detailMessage);
    }
}
