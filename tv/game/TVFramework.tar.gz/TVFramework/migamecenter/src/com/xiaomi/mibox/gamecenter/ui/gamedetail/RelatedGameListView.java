package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import java.util.ArrayList;

import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.ui.view.BaseGridItem;
import com.xiaomi.mibox.gamecenter.ui.view.HorizontalScrollListView;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

/**
 * 相关游戏视图
 * @author liubiqiang
 *
 */
public class RelatedGameListView extends HorizontalScrollListView{

    private ArrayList<GameItem> mGameList  = new ArrayList<GameItem>(4);
    
    public RelatedGameListView(Context context, AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);
        initDimens();
    }

    private void initDimens(){
        if(item_default_height == -1){
            item_default_height = getResources().getDimensionPixelSize(R.dimen.item_default_height);
            item_default_width  = getResources().getDimensionPixelSize(R.dimen.base_grid_item_width);
            left_margin         = getResources().getDimensionPixelSize(R.dimen.left_margin);
            horizontal_margin   = getResources().getDimensionPixelSize(R.dimen.horizontal_margin);
            item_border_width   = getResources().getDimensionPixelSize(R.dimen.item_border_width);
        }
    }
    public RelatedGameListView(Context context, AttributeSet as) {
        this(context, as, 0);
        initDimens();
    }
    
    public RelatedGameListView(Context context) {
        this(context, null, 0);
        initDimens();
    }

    private static int item_default_width = -1;
    private static int item_default_height = -1;
    private static int left_margin         = -1;
    private static int horizontal_margin   = -1;
    private static int item_border_width   = -1;
    /**
     * 
     * @param gameList
     */
    public void bindData(ArrayList<GameItem> gameList){
        mGameList.clear();
        if(null == gameList){
            return;
        }
        mGameList.addAll(gameList);
        final int count = gameList.size();
        BaseGridItem shotView = null;
        if(count > mItemCount){//增加
            removeSpaceView();
            addItemViews(mItemCount,count);
            addRightSpaceView();
        }else if(count < mItemCount){//隐藏
            for(int i = count; i < mItemCount; i++){
                shotView = (BaseGridItem)mViewLists.get(i);
                shotView.setVisibility(View.INVISIBLE);
            }
        }
        
        mItemCount = count;
        for(int i = 0; i < count; i++){
            shotView = (BaseGridItem)mViewLists.get(i);
            shotView.setVisibility(View.VISIBLE);
            shotView.bind(gameList.get(i), BaseGridItem.ITEM_TYPE_DETAIL);
        }
        computeScrollRange();
    }

    @Override
    protected void addItemViews(int startIndex, int endIndex) {
        BaseGridItem shotView = null;
        int key = mViewLists.size();
        LinearLayout.LayoutParams llp;
        for(int i = startIndex; i < endIndex; i++){
            shotView = new BaseGridItem(getContext());
            shotView.setVisibility(View.INVISIBLE);
            llp = new LinearLayout.LayoutParams(
                    item_default_width,
                    item_default_height);
            if(i > 0){
                llp.leftMargin = itemHorizontalMargin();
            }
            mContainer.addView(shotView, llp);
            mViewLists.put(key, shotView);
            key++;
        }
    }
    
    @Override
    protected int itemViewWidth(){
        if(item_default_width == -1){
            initDimens();
        }
        return item_default_width;
    }
    
    @Override
    protected int itemHorizontalMargin(){
        if(item_default_width == -1){
            initDimens();
        }
        return horizontal_margin;
    }

    @Override
    protected int leftSpaceWidth() {
        if(item_default_width == -1){
            initDimens();
        }
        return left_margin;
    }

    @Override
    protected int rightSpaceWidth() {
        if(item_default_width == -1){
            initDimens();
        }
        return left_margin;
    }

    @Override
    protected String TAG() {
        return "RelatedGameListView";
    }

    @Override
    protected int diffY() {
        if(item_default_width == -1){
            initDimens();
        }
        return item_border_width;
    }
    
    protected int diffX() {
        if(item_default_width == -1){
            initDimens();
        }
        return item_border_width;
    }

    @Override
    protected void onClick() {
        if(mOnClickListener != null){
            GameItem gameInfo = null;
            if(mCurrPos < mGameList.size() && mCurrPos >= 0){
                gameInfo = mGameList.get(mCurrPos);
            }
            mOnClickListener.onClick(gameInfo, mCurrPos);
        }
    }
}
