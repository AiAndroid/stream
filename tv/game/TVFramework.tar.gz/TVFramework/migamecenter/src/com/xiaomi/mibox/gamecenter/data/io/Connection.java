package com.xiaomi.mibox.gamecenter.data.io;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.MiboxGamecenterApplication;
import com.xiaomi.mibox.gamecenter.data.GlobalConfig;
import com.xiaomi.mibox.gamecenter.data.IUserData;
import com.xiaomi.mibox.gamecenter.utils.AESEncryption;
import com.xiaomi.mibox.gamecenter.utils.Base64;
import com.xiaomi.mibox.gamecenter.utils.Client;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;
import com.xiaomi.mibox.gamecenter.utils.SystemConfig;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

public final class Connection {
    private static final String TAG = "GameCenterConnection";

    private static final String PROTOCAL = "http";

    private static final int CONNECT_TIMEOUT = 10000;
    private static final int WIFI_READ_TIMEOUT = 15000;
    private static final int GPRS_READ_TIMEOUT = 35000;

    public static enum NetworkError {
        OK,
        URL_ERROR,
        NETWORK_ERROR,
        IO_ERROR,
        CLIENT_ERROR,
        SERVER_ERROR,
        RESULT_ERROR,
        UNKNOWN_ERROR
    }

    private JSONObject mResponse;
    private URL mUrl;
    private Parameter mParameter;

    private boolean mNeedBaseParameter;
    private boolean mUseGet;

    public Connection(String urlstring) {
        URL url = null;
        try {
            url = new URL(urlstring);
        } catch (MalformedURLException e) {
            Log.e(TAG, "URL error: " + e);
        }
        init(url);
    }

    public Connection(String baseUrlString, String appendUrlString, Context context) {
        String urlString = connect(baseUrlString, appendUrlString);
        URL url = null;
        try {
            url = new URL(urlString);
        } catch (MalformedURLException e) {
            Log.e(TAG, "URL error: " + e);
        }
        init(url);
    }

    public Connection(URL url, Context context) {
        init(url);
    }

    public static String connect(String baseUrlString, String appendUrlString) {
        if (TextUtils.isEmpty(baseUrlString)) {
            return appendUrlString;
        }
        if (TextUtils.isEmpty(appendUrlString)) {
            return baseUrlString;
        }

        if (baseUrlString.charAt(baseUrlString.length() - 1) == '/') {
            baseUrlString = baseUrlString.substring(0, baseUrlString.length() - 1);
        }
        if (appendUrlString.charAt(0) == '/') {
            appendUrlString = appendUrlString.substring(1);
        }
        return baseUrlString + "/" + appendUrlString;
    }

    private void init(URL url) {
        mNeedBaseParameter = true;
        mUseGet = false;
        if (checkURL(url)) {
            mUrl = url;
        }
    }

    public JSONObject getResponse() {
    	if(IConfig.DEBUG){
    		Log.e(TAG, "******"+mResponse.toString());	
    	}
        return mResponse;
    }
    
    /**
     * 添加参数
     * @param key
     * @param value
     */
    public void addParameter(String key, String value) {
    	if(!mNeedBaseParameter){
    		mNeedBaseParameter = true;
    	}
    	
    	if(null == mParameter){
    		mParameter = new Parameter();
    	}
    	mParameter.add(key, value);
    }

    public Parameter getParameter() {
        return mParameter;
    }

    public void setUseGet(boolean useGet) {
        mUseGet = useGet;
    }

    public void setNeedBaseParameter(boolean need) {
        mNeedBaseParameter = need;
    }
    
    /**
     * 简单get
     * @return
     */
    public NetworkError requestResponse() {
    	NetworkError error = requestJSON();
    	if(NetworkError.OK == error){
    		try {
				int errCode = mResponse.getInt(Constants.JSON_ERROR_CODE);
				if(errCode != 200){// XXX
					return NetworkError.RESULT_ERROR;
				}
			} catch (JSONException e) {
				if(IConfig.DEBUG) e.printStackTrace();
				return NetworkError.RESULT_ERROR;
			}
    	}
        return error;
    }

    public NetworkError requestJSON() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        NetworkError resp = request(new MemoryResetableOutputStream(baos));
        try {
            if (resp == NetworkError.OK) {
                mResponse = new JSONObject(baos.toString());
                if(IConfig.DEBUG){
                	if(mResponse != null){
                		Log.d(this.getClass().getSimpleName(), 
                			""+mResponse.optInt(Constants.JSON_ERROR_CODE));
                	}else{
                		Log.d(this.getClass().getSimpleName(), 
                				"server response is null");
                	}
                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSON error: " + e);
            return NetworkError.RESULT_ERROR;
        } finally {
            try {
                baos.close();
            } catch (IOException e) {
            	if(e != null) e.printStackTrace();
            }
        }
        return resp;
    }
    
    public NetworkError requestFile(File outFile) throws FileNotFoundException {
        if (outFile == null) {
            return null;
        }
        FileResetableOutputStream fos = null;
        try {
            fos = new FileResetableOutputStream(outFile);
        } catch (FileNotFoundException e) {
            Log.e(TAG, "File not found: " + e);
            throw e;
        }
        NetworkError resp = request(fos);
        try {
            fos.close();
            if (resp != NetworkError.OK) {
            	if(IConfig.DEBUG) Log.e(TAG, "loading image fail");
                outFile.delete();
            }else{
            	if(IConfig.DEBUG) Log.d(TAG, "loading image success");
            }
        } catch (IOException e) {
        	if(IConfig.DEBUG){
        		e.printStackTrace();
        	}
        }
        return resp;
    }
    
    /**
     * 加密请求接口
     * @param json
     * @param uploadData : 要上传的数据
     * @return
     */
    public String requestByEncodeJson(JSONObject json,byte[] uploadData) {
    	String jsonStr = "";
		if (json != null) {
			try {
				jsonStr = Connection.encodeRequestJson(json);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		if (TextUtils.isEmpty(jsonStr)) {
			return "";
		}
		
		String resultData = "";
		// 声明HttpURLConnection对象
		HttpURLConnection urlConn = null;
		// 声明DataOutputStream流
		OutputStream out = null;
		ResetableOutputStream outputStream = null;
		BufferedInputStream bis = null;
		try {
			// 使用HttpURLConnection打开连接
			urlConn = (HttpURLConnection) mUrl.openConnection();
			urlConn.setConnectTimeout(CONNECT_TIMEOUT);
	        if(GamecenterUtils.isWifiConnected(
	        		MiboxGamecenterApplication.getInstance())){
	            urlConn.setReadTimeout(WIFI_READ_TIMEOUT);
	        }else{
	            urlConn.setReadTimeout(GPRS_READ_TIMEOUT);
	        }
			// 因为这个是POST请求所以要设置为true
			urlConn.setDoInput( true );
			urlConn.setDoOutput( true );
			// 设置POST方式
			urlConn.setRequestMethod( "POST" );
			// POST请求不能设置缓存
			urlConn.setUseCaches( false );
			urlConn.setInstanceFollowRedirects( false );
			// 配置本次连接的Content-type，配置为application/x-www-form-urlencoded的
			urlConn.setRequestProperty( "Content-Type", "application/x-www-form-urlencoded" );
			
			if(uploadData!=null){
				urlConn.setRequestProperty( "AttachLength", uploadData.length+"");
			}
			
			// 连接，从postUrl.openConnection()至此的配置必须要在connect之前完成
			// 要注意的是connectio.getOutputStream会隐含的进行connect
			urlConn.connect();
			// DataOutputStream流
			out = urlConn.getOutputStream();
			// 将要上传的内容写入流中
			out.write(jsonStr.getBytes());
			if(uploadData !=null ){
				out.write(uploadData);
			}
			out.close();
			
			bis = new BufferedInputStream(urlConn.getInputStream(), 8192);
            byte[] buffer = new byte[1024];
            int count = -1;
    		ByteArrayOutputStream baos = new ByteArrayOutputStream();
    		outputStream = new MemoryResetableOutputStream(baos);
            while ((count = bis.read(buffer, 0, 1024)) > 0) {
                outputStream.write(buffer, 0, count);
            }
            outputStream.flush();
            return baos.toString();
		} catch (IOException e) {
			e.printStackTrace();
			if (outputStream != null) {
				outputStream.reset();
			}
		} finally {
			try {
				if (out != null) {
					out.flush();
					out.close();
				}
				// 关闭InputStreamReader
				if (outputStream != null){
					outputStream.close();
				}
				
				if(bis != null){
					bis.close();
				}
				// 关闭URL连接
				if (urlConn != null){
					urlConn.disconnect();
				}
			} catch (IOException e) {
				if(IConfig.DEBUG) e.printStackTrace();
			}
		}
		return resultData;
	}
    
    /**
     * 获取文件的大小 : 通过Head
     * @return : 0 表示失败
     */
    public long requestFileLength(){
    	long length = 0;
    	if (mUrl == null) {
            return length;
        }
    	HttpURLConnection conn = null;
        try {
            URL url = mUrl;
            if (IConfig.DEBUG) {
                Log.d(TAG, "connection url: "+ url);
            }
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(CONNECT_TIMEOUT);
            if(GamecenterUtils.isWifiConnected(
            		MiboxGamecenterApplication.getInstance())){
            	conn.setReadTimeout(WIFI_READ_TIMEOUT);
            }else{
            	conn.setReadTimeout(GPRS_READ_TIMEOUT);
            }
            conn.setRequestMethod("HEAD");
            conn.connect();
            if(HttpURLConnection.HTTP_OK == conn.getResponseCode()){
            	length = conn.getContentLength();
            }
        } catch (ProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    	return length;
    }

    private NetworkError request(ResetableOutputStream outputStream) {
        if (mUrl == null) {
            return NetworkError.URL_ERROR;
        }
        
        if(!GamecenterUtils.isConnected(
        		MiboxGamecenterApplication.getInstance())){
        	return NetworkError.NETWORK_ERROR;
        }
        HttpURLConnection conn = null;
        try {
            URL url = mUrl;
            if (mUseGet) {
                // get parameters
                if (mParameter == null) {
                    // 如果用户没有指定参数，则加上基础参数
                    mParameter = this.new Parameter();
                }
            }
            
			if (!mParameter.isEmpty()) {
				String query = mUrl.getQuery();
				String urlString = mUrl.toString();
				if (TextUtils.isEmpty(query)) {
					urlString = urlString + "?" + mParameter.toString();
				} else {
					urlString = urlString + "&" + mParameter.toString();
				}
				url = new URL(urlString);
			}

            if (IConfig.DEBUG) {
                Log.d(TAG, "connection url: "+ url);
            }
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(CONNECT_TIMEOUT);
            if(GamecenterUtils.isWifiConnected(
            		MiboxGamecenterApplication.getInstance())){
            	conn.setReadTimeout(WIFI_READ_TIMEOUT);
            }else{
            	conn.setReadTimeout(GPRS_READ_TIMEOUT);
            }
            if (mUseGet) {
                conn.setRequestMethod("GET");
                conn.setDoOutput(false);
            } else {
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
            }
            conn.connect();

            // post parameters
            if (!mUseGet) {
                if (mParameter == null) {
                    // 如果用户没有指定参数，则加上基础参数
                    mParameter = this.new Parameter();
                }

                if (!mParameter.isEmpty()) {
                    OutputStream out = conn.getOutputStream();
                    out.write(mParameter.toString().getBytes());
                    if (IConfig.DEBUG) {
                        Log.d(TAG, "[post]" + mParameter.toString());
                    }
                    out.close();
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "Connection I/O Exception :" + e);
            if (conn != null) {
                conn.disconnect();
            }
            return NetworkError.IO_ERROR;
        } catch (Exception e) {
            Log.e(TAG, "Connection Exception :" + e);
            if (conn != null) {
                conn.disconnect();
            }
            return NetworkError.UNKNOWN_ERROR;
        }

        BufferedInputStream bis = null;
        try {
            NetworkError code = handleResponseCode(conn.getResponseCode());
            if (code == NetworkError.OK) {
                if (outputStream != null) {
                    try {
                        bis = new BufferedInputStream(conn.getInputStream(), 8192);
                        byte[] buffer = new byte[1024];
                        int count;
                        while ((count = bis.read(buffer, 0, 1024)) > 0) {
                            outputStream.write(buffer, 0, count);
                        }
                        outputStream.flush();
                    } catch (Exception e) {
                        // 读取文件流的过程中异常有可能造成文件损坏，页面读取时造成ANR
                        Log.e(TAG, "Connection Exception for " + mUrl + " : read file stream error " + e);
                        outputStream.reset(); // 重置输出流
                        return NetworkError.IO_ERROR;
                    } finally {
                        if (bis != null) {
                            bis.close();
                        }
                    }
                }
            }
            return code;
        } catch (IOException e) {
        	if(IConfig.DEBUG) Log.e(TAG, "Connection I/O Exception :" + e);
            return NetworkError.IO_ERROR;
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    if(IConfig.DEBUG) e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private boolean checkURL(URL url) {
        if (url != null && TextUtils.equals(url.getProtocol(), PROTOCAL)) {
            return true;
        }
        return false;
    }

    private NetworkError handleResponseCode(int code) {
        if (code == HttpURLConnection.HTTP_OK) {
            return NetworkError.OK;
        } else {
            Log.e(TAG, "Network Error : " + code);
            return NetworkError.IO_ERROR;
        }
    }

    public final class Parameter {
        private Map<String, String> params;

        /**
         * 用户使用当前对象的构造方法时与相对应的Connection绑定.<br>
         * 例如：<br>
         * Connection conn = new Connection();<br>
         * Parameter para = conn.new Parameter();<br>
         * 返回的para已经被加载到conn中
         */
        public Parameter() {
            params = new HashMap<String, String>();
            if (mNeedBaseParameter) {
                createBaseParameter();
            }
            Connection.this.mParameter = this;// XXX 这样用法值得... ???
        }

        /**
         * 公共部分
         */
		private void createBaseParameter() {
			add(Constants.CLIENT_ID, Client.UUID);
			add(Constants.SDK_VERSION, String.valueOf(Client.SDK_VERSION));
			add(Constants.VERSION, Client.SYSTEM_VERSION);
			String lauguage = Locale.getDefault().getLanguage();
			String country = Locale.getDefault().getCountry();
			add(Constants.LANGUAGE, lauguage);
			add(Constants.COUNTRY, country);
			add(Constants.DEVICE, Client.DEVICE);
			String ua = SystemConfig.get_phone_ua().trim();
			if (!TextUtils.isEmpty(ua)) {
				add(Constants.UA, ua);
			}

			add("product", Client.PRODUCT);
			add(Constants.CLIENT_VERSION_CODE, "" + Client.GAMECENTER_VERSION);

			final String uid = GlobalConfig.getInstance().Get(IUserData.UUID);
			if (!TextUtils.isEmpty(uid)) {
				add(Constants.UID, uid);
			}
			
			final String fuid = GlobalConfig.getInstance().Get(IUserData.FUID);
			if (!TextUtils.isEmpty(fuid)) {
				add("fuid", fuid);
			}
			
			final String xiaomiId = GlobalConfig.getInstance().Get(IUserData.XIAOMI_ID);
			if (!TextUtils.isEmpty(xiaomiId)) {
				add("mid", xiaomiId);
			}
		}

        public Parameter add(String key, String value) {
            params.put(key, value);
            return this;
        }

        public Parameter add(String key, boolean value) {
            if (value) {
                params.put(key, "true");
            } else {
                params.put(key, "false");
            }
            return this;
        }

        public String get(String key) {
            return params.get(key);
        }

        public boolean isEmpty() {
            return params.isEmpty();
        }

		public String toString() {
			StringBuilder sb = new StringBuilder();
			String value = null;
			for (String key : params.keySet()) {
				if (TextUtils.isEmpty(key)) {
					continue;
				}
				value = params.get(key);
				if (TextUtils.isEmpty(value)) {
					continue;
				}
				sb.append(key);
				sb.append("=");
				if (mUseGet) {
					try {
						sb.append(URLEncoder.encode(value, "UTF-8"));
					} catch (UnsupportedEncodingException e) {
					}
				} else {//POST 不需要URLEncoder
					sb.append(value);
				}
				sb.append("&");
			}
			return sb.deleteCharAt(sb.length() - 1).toString();
		}
    }
    
    /**
 	 * @param json
 	 * @return
 	 * @throws Exception
 	 */
 	public static String encodeRequestJson( JSONObject json ) throws Exception{
 		return Base64.encode(AESEncryption.Encrypt(json.toString(), 
 				Constants.AES_KEY));
 	}
 	
 	/**
 	 * 解析返回的加密数据
 	 * @param responseMessage
 	 * @return
 	 * @throws Exception
 	 * @throws JSONException
 	 */
 	public static String praseEncodeResponseMessage(String responseMessage) {
 		try {
 			final byte[] decode64 = Base64.decode(responseMessage);
 			byte[] jsonB = AESEncryption.Decrypt(decode64, Constants.AES_KEY);
 			String jsonStr = new String(jsonB);
 			if (TextUtils.isEmpty(jsonStr)) {
 				return "";
 			}

 			return jsonStr;
 		} catch (JSONException e) {
 			if (IConfig.DEBUG){
 				e.printStackTrace();
 			}
 		} catch (Exception e) {
 			if (IConfig.DEBUG){
 				e.printStackTrace();
 			}
 		}
 		
 		return "";
 	}
}