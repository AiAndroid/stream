package com.xiaomi.mitv.store.video;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.tv.ui.metro.model.DisplayItem;
import com.tv.ui.metro.model.GameItem;
import com.tv.ui.metro.model.GenericSubjectItem;
import com.tv.ui.metro.model.VideoItem;
import com.xiaomi.mibox.gamecenter.*;
import com.xiaomi.mibox.gamecenter.ui.OnLoaderControl;
import com.xiaomi.mibox.gamecenter.ui.view.*;
import com.xiaomi.mibox.gamecenter.ui.view.VideoView;
import com.xiaomi.mitv.app.view.TitleBar;
import com.xiaomi.mitv.store.XiaomiUIHelper;
import com.xiaomi.mitv.store.network.GenericSubjectLoader;
import java.util.ArrayList;

/**
 * Created by tv metro on 9/1/14.
 */
public class VideoAlbumActivity extends XiaomiUIHelper implements LoaderManager.LoaderCallbacks<GenericSubjectItem<VideoItem>>, OnLoaderControl {
    TitleBar mTitleBar;
    SmoothGridView gridView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.video_album_detail);

        mTitleBar = (TitleBar) this.findViewById(R.id.video_title_bar);
        mTitleBar.setTitle(item.name);
        gridView = (SmoothGridView) findViewById(R.id.list_content);
        gridView.setLoaderControl(this);

        gridView.setOnItemSelectedListener(focusListener);

        mLoadingView = makeEmptyLoadingView(this, (RelativeLayout) findViewById(com.tv.ui.metro.R.id.tabs_content));
        mTitleBar.setBackPressListner(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VideoAlbumActivity.this.finish();
            }
        });

        getSupportLoaderManager().initLoader(GenericSubjectLoader.VIDEO_SUBJECT_LOADER_ID, savedInstanceState, this);
    }

    View firstView;
    View preView;
    AdapterView.OnItemSelectedListener focusListener = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            if(view != null){
                //view.requestFocus();
                if(preView != null) {
                    preView.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start();
                    preView.findViewById(R.id.video_item_cover).setVisibility(View.GONE);
                }


                //remove first view status
                int pos = adapterView.getSelectedItemPosition();
                if(pos != 0 && firstView != null && justNeedDoOneTime_DONE == false){
                    adapterView.getChildAt(0).animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start();
                    adapterView.getChildAt(0).findViewById(R.id.video_item_cover).setVisibility(View.GONE);
                    firstView = null;
                    justNeedDoOneTime_DONE = true;
                }

                view.findViewById(R.id.video_item_cover).setVisibility(View.VISIBLE);//.setBackgroundResource(R.drawable.item_highlight);
                view.animate().scaleX(1.1f).scaleY(1.1f).setDuration(200).alpha(1.0f).start();
                preView = view;
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
            adapterView.setSelection(0);
        }
    };

    @Override
    public Loader<GenericSubjectItem<VideoItem>> onCreateLoader(int id, Bundle bundle){
        if(id == GenericSubjectLoader.VIDEO_SUBJECT_LOADER_ID){
            mLoader = GenericSubjectLoader.generateVideoSubjectLoader(this, item);
            mLoader.setProgressNotifiable(mLoadingView);
            return mLoader;
        }
        return null;
    }

    GenericSubjectItem<VideoItem> mVidoeInfo ;
    RelativeAdapter adapter;
    @Override
    public void onLoadFinished(Loader<GenericSubjectItem<VideoItem>> albumLoader, GenericSubjectItem<VideoItem> result) {
        if(result == null ) {
            //showTestData();
            return;
        }
        if(mVidoeInfo!= null && mVidoeInfo.update_time == result.update_time && mLoader.getCurrentPage() == 1){
            return;
        }

        //first page
        if(mVidoeInfo == null) {
            mVidoeInfo = result;
            if(!TextUtils.isEmpty(result.data.get(0).name)){
                mTitleBar.setTitle(result.data.get(0).name);
            }
            adapter = new RelativeAdapter(result.data.get(0).items);
            //update UI
            gridView.setAdapter(adapter);
            gridView.setOnItemClickListener(itemClicker);
        }else {
            mVidoeInfo.data.get(0).items.addAll(result.data.get(0).items);
            adapter.notifyDataSetChanged();
        }
    }

    private void showTestData(){
        RelativeAdapter adapter = new RelativeAdapter(null);
        gridView.setAdapter(adapter);
        gridView.setOnItemClickListener(itemClicker);
        mLoadingView.stopLoading(true, false);
        gridView.setSelection(0);
        gridView.invalidate();
    }


    AdapterView.OnItemClickListener itemClicker = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
           try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("micontent://" + item.ns + "/item" /*+ item.type */+ "?rid=" + item.id));
                Object tag = view.getTag();
                if(tag != null && tag instanceof DisplayItem){
                    DisplayItem content = (DisplayItem)tag;

                    content.type = "item";
                    intent.putExtra("item", content);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    view.getContext().startActivity(intent);
                }else {
                    //just for test
                    item.type = "item";
                    intent.putExtra("item", item);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    view.getContext().startActivity(intent);
                }

            }catch (Exception ne){ne.printStackTrace();}
        }
    };
    @Override
    public void onLoaderReset(Loader<GenericSubjectItem<VideoItem>> albumLoader) {}

    boolean justNeedDoOneTime_DONE=false;

    @Override
    public boolean nextPage() {
        if(mLoader != null 	&& ((GenericSubjectLoader)mLoader).hasMoreData() && !((GenericSubjectLoader)mLoader).isLoading()){
            ((GenericSubjectLoader)mLoader).nextPage();
            mLoader.forceLoad();
            return true;
        }else{
            return false;
        }
    }

    @Override
    public void onClick(DisplayItem ItemInfo, int pos) {

    }

    public class RelativeAdapter extends BaseAdapter {
        public RelativeAdapter(ArrayList<VideoItem> content){
            super();
            items = content;
        }

        public void changeContent(ArrayList<VideoItem> content){
            if(content != null) {
                items = content;
                notifyDataSetChanged();
            }
        }
        private ArrayList<VideoItem> items;

        @Override
        public int getCount() {
            return items==null?40:items.size();
        }

        @Override
        public Object getItem(int i) {
            return items==null?new Object():items.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }


        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            VideoView root = null;
            if(items == null) {
                root = new VideoView(getBaseContext());
            }else {
                if(view == null) {
                    root = new VideoView(getBaseContext());
                }else{
                    root = (VideoView)view;
                }


                root.setTag(getItem(i));
                root.setContent((DisplayItem) getItem(i));
            }

            if(i == 0 && justNeedDoOneTime_DONE == false){
                firstView = root;
                root.findViewById(R.id.video_item_cover).setVisibility(View.VISIBLE);
                root.animate().scaleX(1.1f).scaleY(1.1f).setDuration(200).alpha(1.0f).start();
            }

            return root;
        }
    }
}