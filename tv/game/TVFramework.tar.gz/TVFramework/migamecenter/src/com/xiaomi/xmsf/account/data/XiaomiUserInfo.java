package com.xiaomi.xmsf.account.data;

import java.io.Serializable;

import android.graphics.Bitmap;

public class XiaomiUserInfo implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 3025510974243674266L;
	public static final String CFG_FILE_NAME = "c1ff0063fa8bd4575797a915df0d69a6";//xiaomitv

	/**
     * Miliao id
     */
    private String mUserId;

    /**
     * user's real name
     */
    private String mUserName;

    /**
     * avatar url
     */
    private String mAvatarAddress;

    /**
     * user's phone number
     */
    private String mPhone;

    /**
     * user's email address
     */
    private String mEmail;

    private String mNickName;

    private Bitmap mAvatar;

    public XiaomiUserInfo(String userId) {
        mUserId = userId;
    }

    public String getUserName() {
        return mUserName;
    }

    public void setUserName(String userName) {
        mUserName = userName;
    }

    public String getUserId() {
        return mUserId;
    }

    public String getAvatarAddress() {
        return mAvatarAddress;
    }

    public void setAvatarAddress(String avatarAddress) {
        mAvatarAddress = avatarAddress;
    }

    public String getPhone() {
        return mPhone;
    }

    public void setPhone(String phone) {
        mPhone = phone;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public String getNickName() {
        return mNickName;
    }

    public void setNickName(String nickName) {
        mNickName = nickName;
    }

    public Bitmap getAvatar() {
        return mAvatar;
    }

    public void setAvatar(Bitmap avatar) {
        mAvatar = avatar;
    }
    
    public static final String EMAIL = "email";
    public static final String XIAOMI_ID = "xiaomi_id";
    public static final String PHONE = "phone";
    public static final String AVTAR_URL = "avtar_url";
    public static final String USER_NAME = "user_name";
    public static final String NICK_NAME = "nick_name";
}