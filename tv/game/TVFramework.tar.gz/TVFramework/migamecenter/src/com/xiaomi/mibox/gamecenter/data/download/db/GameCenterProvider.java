package com.xiaomi.mibox.gamecenter.data.download.db;

import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.BaseColumns;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.Download;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.ReportQueue;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.text.TextUtils;

/**
 * 
 * @author mengshu
 *
 */
public class GameCenterProvider extends ContentProvider {
    private GameCenterDatabaseHelper mOpenHelper;

    private static final String[] ID_PROJECTION = { BaseColumns._ID };

    private static final int URI_DOWNLOAD = 1;
    private static final int URI_DOWNLOAD_APP = 2;
    private static final int URI_REPORT = 9;


    private static final UriMatcher URI_MATCHER = new UriMatcher(UriMatcher.NO_MATCH);
    static {
        URI_MATCHER.addURI(DataBaseColumns.AUTHORITY, Download.TABLE, URI_DOWNLOAD);
        URI_MATCHER.addURI(DataBaseColumns.AUTHORITY, Download.TABLE+"/*", URI_DOWNLOAD_APP);
        URI_MATCHER.addURI(DataBaseColumns.AUTHORITY, ReportQueue.TABLE, URI_REPORT);
    }

    @Override
    public String getType(Uri uri) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean onCreate() {
        mOpenHelper = GameCenterDatabaseHelper.getInstance(getContext());
//        mContext = getContext();
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
            String sortOrder) {
		SQLiteDatabase db = mOpenHelper.getReadableDatabase();
		Cursor cursor = null;
		final int uriMatch = URI_MATCHER.match(uri);

		switch (uriMatch) {
			case URI_DOWNLOAD: {
				/**
				 * SELECT [projection] FROM download ...; 这里不和app表进行join，在需要的时候单独查询
				 */
				cursor = db.query(Download.TABLE, projection, selection,
						selectionArgs, null, null, null);
				break;
			}
			case URI_REPORT: {
				cursor = db.query(ReportQueue.TABLE, projection, selection,
						selectionArgs, null, null, null);
				break;
			}
			default: {
				throw new IllegalArgumentException("Unknown URL " + uri);
			}
		}

        return cursor;
    }

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		int count = 0;
		final int uriMatch = URI_MATCHER.match(uri);

		switch (uriMatch) {
			case URI_DOWNLOAD:{
			    count = db.update(Download.TABLE, values, selection,
                        selectionArgs);
			    break;
			}
			case URI_DOWNLOAD_APP: {
				count = 1;
				String appId = uri.getLastPathSegment();
				if (TextUtils.isEmpty(appId)) {
					return 0;
				}
				db.update(Download.TABLE, values, Download.APP_ID + " = ? ",
						new String[] { String.valueOf(appId) });
				break;
			}
			case URI_REPORT: {
				count = db.update(ReportQueue.TABLE, values, selection,
						selectionArgs);
				break;
			}
			default: {
				throw new IllegalArgumentException("Unknown URL " + uri);
			}
		}

		return count;
	}

	@Override
    public Uri insert(Uri uri, ContentValues values) {
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		final int uriMatch = URI_MATCHER.match(uri);
		long rowId = -1;
		Uri retUri = null;
		switch (uriMatch) {
			case URI_DOWNLOAD: {
				rowId = db.insert(Download.TABLE, null, values);
				retUri = Uri.parse("content://" + Download.TABLE + "/" + rowId);
				break;
			}
			case URI_REPORT: {
				rowId = db.insert(ReportQueue.TABLE, null, values);
				retUri = Uri.parse("content://" + ReportQueue.TABLE + "/" + rowId);
				break;
			}
			default: {
				throw new IllegalArgumentException("Unknown URL " + uri);
			}
		}
		return retUri;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		final int uriMatch = URI_MATCHER.match(uri);
		int count = 0;
		switch (uriMatch) {
			case URI_DOWNLOAD_APP: {
				String appId = uri.getLastPathSegment();
				if (TextUtils.isEmpty(appId)) {
					return 0;
				}
				count = db.delete(Download.TABLE, Download.APP_ID + " = ? ",
						new String[] { String.valueOf(appId) });
				break;
			}
			case URI_REPORT: {
				count = db.delete(ReportQueue.TABLE, selection, selectionArgs);
				break;
			}
			case URI_DOWNLOAD:{
			    count = db.delete(Download.TABLE, selection, selectionArgs);
			    break;
			}
			default: {
				throw new IllegalArgumentException("Unknown URL " + uri);
			}
		}
		return count;
    }

}
