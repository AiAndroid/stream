package com.xiaomi.mibox.gamecenter.ui.view;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.VolleyHelper;
import com.tv.ui.metro.model.DisplayItem;
import com.xiaomi.mibox.gamecenter.R;

/**
 * Created by liuhuadong on 9/24/14.
 */
public class VideoView extends RelativeLayout {

    public VideoView(Context context) {
        this(context, null, 0);
    }
    public VideoView(Context context, AttributeSet as) {
        this(context, as, 0);
    }
    public VideoView(Context context, AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);
        initViews(context);
    }

    DisplayItem content;
    public void setContent(DisplayItem item){
        content = item;

        videoCover.setVisibility(GONE);

        title.setText(item.name);
        String logo = "";
        if(item.images != null) {
            if (item.images.get("small_poster") != null)
                logo = item.images.get("small_poster").url;
            if ((logo == null || logo.length() == 0) && item.images.get("big_poster") != null)
                logo = item.images.get("big_poster").url;

            if(logo != null && logo.length() > 0)
                VolleyHelper.getInstance(getContext()).getImageLoader().get(logo, ImageLoader.getImageListener(videoIcon, R.drawable.icon_v_default, R.drawable.icon_v_default));
            else
                videoIcon.setImageDrawable(getResources().getDrawable(R.drawable.icon_v_default));
        }
    }



    ImageView      videoIcon;
    View           videoCover;
    TextView       title;
    private void initViews(Context ctx){
        View viewRoot = LayoutInflater.from(ctx).inflate(R.layout.video_item, this);

        videoIcon  = (ImageView) viewRoot.findViewById(R.id.video_item_icon);
        videoCover = viewRoot.findViewById(R.id.video_item_cover);
        title      = (TextView) viewRoot.findViewById(R.id.video_item_name);

        videoCover.setVisibility(GONE);
        title.setText("什么名字哦");
        VolleyHelper.getInstance(getContext()).getImageLoader().get(images[((int) (Math.random() * 100)) % images.length], ImageLoader.getImageListener(videoIcon, R.drawable.icon_v_default, R.drawable.icon_v_default));

        //this.setFocusable(true);
        //this.setOnFocusChangeListener(focusChange);

        //this.setOnClickListener(clickListener);
    }

    OnClickListener clickListener = new OnClickListener(){
        @Override
        public void onClick(View view) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                if(content != null ){
                    content.type = "item";
                    intent.setData(Uri.parse("micontent://" +content.ns + "/" + content.type + "?rid=" + content.id));
                    intent.putExtra("item", content);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    view.getContext().startActivity(intent);
                }else {
                    //just for test
                    intent.setData(Uri.parse("micontent://video/item" /*+ item.type */ + "?rid=" + content.id));
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    view.getContext().startActivity(intent);
                }

            }catch (Exception ne){ne.printStackTrace();}
        }
    };

    OnFocusChangeListener focusChange = new OnFocusChangeListener() {
        @Override
        public void onFocusChange(View view, boolean b) {
            if(b == true){
                if(view != null){
                    view.findViewById(R.id.video_item_cover).setVisibility(View.VISIBLE);
                    view.animate().scaleX(1.1f).scaleY(1.1f).setDuration(200).alpha(1.0f).start();
                }
            }else {
                if(view != null) {
                    view.animate().scaleX(1.0f).scaleY(1.0f).setDuration(0).start();
                    view.findViewById(R.id.video_item_cover).setVisibility(View.GONE);
                }
            }
        }
    };

    String images[] = {
            "http://file.market.xiaomi.com/download/563/096e0664b3bdcfc6253b22a55a36393833a778e2/dk951926_20130407200411_b1080.jpg",
            "http://file.market.xiaomi.com/download/9e8/04d84bef48457ac2993d7d1d9c5c68c5dbdfbb0c/dk950876_20130327161443_b1080.jpg",
            "http://file.market.xiaomi.com/download/Duokan/c96e0aea-92a6-4515-80a2-ca0343b3569a/dk973988_20140129163805_b1080.jpg",
            "http://file.market.xiaomi.com/download/5fa/f6145cf0aa32b3ff8084052355243afa32a2a70e/dk855694_20130117174220_b1080.jp",
            "http://file.market.xiaomi.com/download/Duokan/a4529e4e-4c87-4987-b495-ea857a631008/dk973990_20140129163834_b1080.jpg",
            "http://file.market.xiaomi.com/download/306/3c81b503564eacbb05eab6e33b0f88209a0346e8/dk833318_20121208164915_b1080.jpg",
            "http://file.market.xiaomi.com/download/Duokan/a4576591-652b-4b25-8465-2cabc018ca5e/dk972601_20131231122950_b1080.jpg",
            "http://file.market.xiaomi.com/download/b64/f113906b6439a28b6444a153b8558e4d3a4dfbac/dk951143_20130402101436_b1080.jpg",
            "http://file.market.xiaomi.com/download/Duokan/fba8d34d-d67f-4e53-9ca7-870e96e0a4a8/dk969822_20131101104025_b1080.jp",
            "http://file.market.xiaomi.com/download/77b/43ea7e7e5b51a45ee1313ba97474e26ca68c3a53/dk946956_20130319130648_b1080.jpg",
            "http://file.market.xiaomi.com/download/477/e982137277ff93decfb471a94102af74d3077a40/dk950748_20130327100053_b1080.jpg",
            "http://file.market.xiaomi.com/download/Duokan/129c3492-a507-4b68-886e-f8f3af29836b/dk964334_20130828104932_b1080.jpg",
            "http://file.market.xiaomi.com/download/db5/360a10bd45b5ddd2d926a98fd0f4351dcc6b082a/dk951972_20130403192348_b1080.jpg",
            "http://file.market.xiaomi.com/download/8ef/8e31c2e0ef66d36a57a487c78cd61ee21c644b26/dk753750_20121219193646_b1080.jpg",
            "http://file.market.xiaomi.com/download/f74/54a09379549b6558329dc79df39eecfd83ef9a17/dk819440_20121207204255_b1080.jpg",
            "http://file.market.xiaomi.com/download/bd1/dcdf68dbf1ab9986e804e9ccb0be01722788e6e6/dk754824_20121219193939_b1080.jpg",
            "http://file.market.xiaomi.com/download/7c0/f9e0f0c1102f9f4661734ae77e3ac5fd38a2472b/dk956011_20130615134754_b1080.jpg",
            "http://file.market.xiaomi.com/download/656/c31c845636beffc6b3abe96d65deeb078c48a77d/dk950175_20130321145449_b1080.jpg",
            "http://file.market.xiaomi.com/download/194/dc1e1f9bb45609697013abbe1ff33fc86fe65c0c/dk951925_20130407200407_b1080.jpg",
            "http://file.market.xiaomi.com/download/508/afd85606883a378bbbeb4dbb5dc17deeeaa8f0d5/dk28830_20121217101433_b1080.jpg",
            "http://file.market.xiaomi.com/download/563/096e0664b3bdcfc6253b22a55a36393833a778e2/dk951926_20130407200411_b1080.jpg",
            "http://file.market.xiaomi.com/download/9e8/04d84bef48457ac2993d7d1d9c5c68c5dbdfbb0c/dk950876_20130327161443_b1080.jpg",
            "http://file.market.xiaomi.com/download/Duokan/c96e0aea-92a6-4515-80a2-ca0343b3569a/dk973988_20140129163805_b1080.jpg",
            "http://file.market.xiaomi.com/download/5fa/f6145cf0aa32b3ff8084052355243afa32a2a70e/dk855694_20130117174220_b1080.jp",
            "http://file.market.xiaomi.com/download/Duokan/a4529e4e-4c87-4987-b495-ea857a631008/dk973990_20140129163834_b1080.jpg",
            "http://file.market.xiaomi.com/download/306/3c81b503564eacbb05eab6e33b0f88209a0346e8/dk833318_20121208164915_b1080.jpg",
            "http://file.market.xiaomi.com/download/Duokan/a4576591-652b-4b25-8465-2cabc018ca5e/dk972601_20131231122950_b1080.jpg",
            "http://file.market.xiaomi.com/download/b64/f113906b6439a28b6444a153b8558e4d3a4dfbac/dk951143_20130402101436_b1080.jpg",
            "http://file.market.xiaomi.com/download/Duokan/fba8d34d-d67f-4e53-9ca7-870e96e0a4a8/dk969822_20131101104025_b1080.jp",
            "http://file.market.xiaomi.com/download/77b/43ea7e7e5b51a45ee1313ba97474e26ca68c3a53/dk946956_20130319130648_b1080.jpg",
            "http://file.market.xiaomi.com/download/477/e982137277ff93decfb471a94102af74d3077a40/dk950748_20130327100053_b1080.jpg",
            "http://file.market.xiaomi.com/download/Duokan/129c3492-a507-4b68-886e-f8f3af29836b/dk964334_20130828104932_b1080.jpg",
            "http://file.market.xiaomi.com/download/db5/360a10bd45b5ddd2d926a98fd0f4351dcc6b082a/dk951972_20130403192348_b1080.jpg",
            "http://file.market.xiaomi.com/download/8ef/8e31c2e0ef66d36a57a487c78cd61ee21c644b26/dk753750_20121219193646_b1080.jpg",
            "http://file.market.xiaomi.com/download/f74/54a09379549b6558329dc79df39eecfd83ef9a17/dk819440_20121207204255_b1080.jpg",
            "http://file.market.xiaomi.com/download/bd1/dcdf68dbf1ab9986e804e9ccb0be01722788e6e6/dk754824_20121219193939_b1080.jpg",
            "http://file.market.xiaomi.com/download/7c0/f9e0f0c1102f9f4661734ae77e3ac5fd38a2472b/dk956011_20130615134754_b1080.jpg",
            "http://file.market.xiaomi.com/download/656/c31c845636beffc6b3abe96d65deeb078c48a77d/dk950175_20130321145449_b1080.jpg",
            "http://file.market.xiaomi.com/download/194/dc1e1f9bb45609697013abbe1ff33fc86fe65c0c/dk951925_20130407200407_b1080.jpg",
            "http://file.market.xiaomi.com/download/508/afd85606883a378bbbeb4dbb5dc17deeeaa8f0d5/dk28830_20121217101433_b1080.jpg"
    };
}
