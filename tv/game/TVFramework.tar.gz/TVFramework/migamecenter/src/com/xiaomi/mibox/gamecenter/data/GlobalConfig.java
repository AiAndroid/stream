package com.xiaomi.mibox.gamecenter.data;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;

import android.content.Context;

/**
 * 全局设置
 * @author dream
 *
 */
public class GlobalConfig {
    private static final byte[] HEADER = {0x67,0x61,0x6D,0x65,0x63,0x65,0x6E,0x74,0x65,0x72};//gamecenter
    private static int VERSION = 1;
    private static final String CFG_FILE_NAME = "gamecenter";
    private static final String EN_KEY = "_&^%&*20130531#$%)%^@";
    private ConcurrentHashMap<String, String> values;
    private ConcurrentHashMap<String, String> trans;//事务
    private Context context;
    private static volatile GlobalConfig instance;//仅适用于 1.5以上的JDK版本
    
    public static GlobalConfig getInstance(){
        return instance;
    }
    
    public static void init(Context context){
    	instance = new GlobalConfig(context);
    }
    
    /**
     *构造函数
     */
    private GlobalConfig(Context context) {
        values = new ConcurrentHashMap<String, String>(256);
        this.context = context;
        loadConfig();
    }
    
    /**
     * 载入配置项，此处仅为文件方式保存
     * 不用显示的调用，对象创建就会自动载入。
     */
    public void loadConfig()
    {
        values.clear();
        FileInputStream fis = null;
        File f = new File(context.getFilesDir().getAbsoluteFile()+File.separator+CFG_FILE_NAME);
        if(!f.exists())
        {
            return ;
        }
        
        final int FILE_LEN = (int)f.length();
        if(0 == FILE_LEN) return;//保护下
        
        byte[] data = new byte[FILE_LEN];
        try {
            fis = new FileInputStream(f);
            fis.read(data);
            fis.close();
            fis = null;
        } catch (Exception e) {
            return ;
        }
        
        data = GamecenterUtils.encrypt(data, EN_KEY.getBytes());
        final int HEADER_LENGTH = HEADER.length;
        for(int i = 0; i < HEADER_LENGTH; i++){
        	if(data[i] != HEADER[i]){
        		return;
        	}
        }
        
        DataInputStream dis = new DataInputStream(new ByteArrayInputStream(data));
        try {
            String key,val;
            dis.skip(HEADER_LENGTH);
            boolean needClearData = false;
            int v = dis.readByte();
            if(v != VERSION){
            	//旧版本数据读取 
            	if(1 == v){
            		needClearData = true;
            	}          
            }
            int c = dis.readShort();
            for(int i = 0 ; i < c; i++)
            {
                key = readString(dis);
                val = readString(dis);
                if(key!=null & val!=null){
                    values.put(key, val);
                }
            }
            
            /**
             * 只清除了防火墙的数据
             */
            if(needClearData && values != null){

            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            try {
                dis.close();
                dis = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private synchronized void saveConfig()
    {
        File file = new File(context.getFilesDir().getAbsoluteFile()+File.separator+CFG_FILE_NAME);
        FileOutputStream fos = null;

        ByteArrayOutputStream bos = new ByteArrayOutputStream(2048);
        DataOutputStream dos = new DataOutputStream(bos);
        try {
            dos.write(HEADER);
            dos.writeByte(VERSION);
            dos.writeShort(values.size());
            Iterator<Entry<String,String>> it= values.entrySet().iterator();
            Entry<String,String> e;
            while(it.hasNext())
            {
                e = it.next();
                writeString(dos, e.getKey());
                writeString(dos, e.getValue());
            }
            byte[] data = GamecenterUtils.encrypt(
            		bos.toByteArray(),EN_KEY.getBytes());
            fos = new FileOutputStream(file,false);
            fos.write(data);
            fos.flush();
            bos.close();
            bos = null;
        } catch (Exception e) {
            e.printStackTrace();
        }finally
        {
            try {
                dos.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                fos.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public synchronized String Get(String key, String def)
    {
        String v = getFromTrans(key);
        if(v!=null){
            return v;
        }
        v = values.get(key);
        if(v == null){
            return def;
        }
        return v; 
    }

    public synchronized int getInt(String key, int def)
    {
        String v = getFromTrans(key);
        if(v == null)
            v = values.get(key);
        if(v == null){
            return def;
        }
        try
        {
            return Integer.parseInt(v);
        }catch (Exception e) {
            try{
                return (int)Double.parseDouble(key);
            }catch (Exception ee) {
            }
        }
        return def;
    }
    
    public synchronized long getLong(String key, long def)
    {
        String v = getFromTrans(key); 
        
        if(v == null)
            v = values.get(key);

        if(v == null)
            return def;
        try
        {
            return Long.parseLong(v);
        }catch (Exception e) {
            try
            {
                return (long)Double.parseDouble(key);
            }catch (Exception ee) {
            }
        }
        return def;
    }
    
    public synchronized double getDouble(String key, double def)
    {
        String v = getFromTrans(key); 
        
        if(v == null){
            v = values.get(key);
        }

        if(v == null){
        	return def;
        }
        try{
            return Double.parseDouble(key);
        }catch (Exception e) {
        	
        }
        return def;
    }
    
    public synchronized String Get(String key)
    {
        String v = getFromTrans(key);
        if(v == null)
            v = values.get(key);
        return v;
    }
    
    public synchronized void Set(String key, String value)
    {
        if(!setToTrans(key, value))
            values.put(key, value);
    }
    
    public synchronized void Set(String key, String value, boolean broadcast)
    {
        Set(key,value);
    }
    
    public synchronized void Delete(String key)
    {
        values.remove(key);
    }
    
    /**
     * 读取字符串
     * @param dis
     * @return
     * @throws IOException
     */
    private synchronized String readString(DataInputStream dis) throws IOException
    {
        int l = dis.readShort();
        byte[] a = new byte[l];
        dis.read(a);
        return new String(a);
    }
    /**
     * 写字符串
     * @param dos
     * @param str
     * @throws IOException
     */
    private synchronized void writeString(DataOutputStream dos, String str) throws IOException
    {
        byte[] a = str.getBytes();
        dos.writeShort(a.length);
        dos.write(a);
    }
    
    public void release()
    {
        values.clear();
    }

    public synchronized boolean getBoolean(String key, boolean def)
    {
        String v = getFromTrans(key); 
        if(null == v) v = values.get(key);
        
        if(v == null){
            return def;
        }
        try
        {
            return Boolean.parseBoolean(v);
        }catch (Exception e) {
        }
        return def;
    }

    public synchronized void SaveNow()
    {
        saveConfig();
    }

    public synchronized void Remove(String key) {
        this.Delete(key);
    }

    private boolean setToTrans(String key, String v)
    {
        if(trans == null)
            return false;
        trans.put(key, v);
        return true;
    }
    
    private String getFromTrans(String key)
    {
        if(trans == null)
        {
            return null;
        }
        return trans.get(key);
    }
    
    public synchronized void beginTrans()
    {
        if(trans != null) trans = null;
        trans = new ConcurrentHashMap<String, String>(values);
    }

    public synchronized void commitTrans()
    {
        if(trans == null)
            return ;
        values.clear();
        for(Entry<String,String> e : trans.entrySet())
        {
            values.put(e.getKey(), e.getValue());
        }
        this.SaveNow();
        trans = null;
    }

    public synchronized void rollBackTrans()
    {
        if(trans != null){
            trans.clear();
            trans = null;
        }
    }

    public synchronized void clear()
    {
        if(trans!=null)
        {
            trans.clear();
            trans = null;
        }
        values.clear();
        SaveNow();
    }
}
