package com.xiaomi.mitv.store.video;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.*;
import com.xiaomi.mibox.gamecenter.R;

/**
 * Created by liuhuadong on 9/19/14.
 */
public class PlayerActivity  extends Activity implements MediaPlayer.OnCompletionListener {
    public static final String TAG = "Videoplayer";

    private String path;
    private MediaPlayer mediaPlayer;
    private SurfaceView surfaceView;


    private int index = 0;
    private String url;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 全屏显示
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.video_player);

        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnCompletionListener(this);

        url = getIntent().getStringExtra("video_url");
        Log.i(TAG, url);

        surfaceView = (SurfaceView) this.findViewById(R.id.surfaceView);
        surfaceView.getHolder().setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        surfaceView.getHolder().setFixedSize(getResources().getDisplayMetrics().widthPixels, getResources().getDisplayMetrics().heightPixels);
        surfaceView.getHolder().setKeepScreenOn(true);
        surfaceView.getHolder().addCallback(new SurfaceCallback());
    }


    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if(event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_CENTER) {
        }else if(event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_DPAD_RIGHT){
            int pos = mediaPlayer.getCurrentPosition();
            int duration = mediaPlayer.getDuration();

            mediaPlayer.seekTo(pos + (duration-pos)/50);
        }

        return super.dispatchKeyEvent(event);
    }

    private final class SurfaceCallback implements android.view.SurfaceHolder.Callback {
        public void surfaceChanged(SurfaceHolder holder, int format, int width,
                                   int height) {
        }

        public void surfaceCreated(SurfaceHolder holder) {
            play();
        }

        public void surfaceDestroyed(SurfaceHolder holder) {
            onStop();
        }
    }

    @Override
    protected void onStop() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying())
                mediaPlayer.stop();
        }
        releaseMediaPlayer();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        releaseMediaPlayer();
        super.onDestroy();
    }

    private void releaseMediaPlayer() {
        if (mediaPlayer != null) {
            Log.i(TAG, "Release MediaPlayer");
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    // 封装播放方法
    private void play() {
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(url);
            mediaPlayer.setDisplay(surfaceView.getHolder());
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            // 缓冲
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        Log.i(TAG, "onCompletion");
        play();
    }
}
