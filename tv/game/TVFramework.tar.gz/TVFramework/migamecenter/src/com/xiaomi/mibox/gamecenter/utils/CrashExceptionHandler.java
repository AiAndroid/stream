package com.xiaomi.mibox.gamecenter.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.Thread.UncaughtExceptionHandler;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.Context;
import android.util.Log;

public class CrashExceptionHandler implements UncaughtExceptionHandler
{
	private static final String TAG = "MiTVGameCenter";
	
	private Context c;
	public CrashExceptionHandler(Context c)
	{
		this.c = c;
		Thread.setDefaultUncaughtExceptionHandler(this);
		
	}
	@Override
	public void uncaughtException(Thread thread, Throwable ex)
	{
		if(ex == null)
		{
			return ;
		}
		record_exception(c, ex);
	}
	
	public static String formatYearMonthDayHourMinute(){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return dateFormat.format(new Date());
	}
	
	public static void record_exception(Context c, Throwable ex)
	{
		try
		{
			File log = null;
			log = new File(c.getFilesDir(),"crash.log");
			FileOutputStream fout = null;
			try{
				fout = new FileOutputStream(log);
				fout.write((formatYearMonthDayHourMinute()+Log.getStackTraceString(ex)).getBytes());
			}catch (Exception e) {
				
			}finally{
				if(fout != null){
					fout.close();
					fout = null;
				}
			}
//			if(IConfig.DEBUG){
				Log.e(TAG, "", ex);
//			}
			android.os.Process.killProcess(android.os.Process.myPid());
			System.exit(1001);
		}catch (Exception e) {
		}
	}

}
