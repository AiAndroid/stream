package com.xiaomi.mibox.gamecenter.ui.view;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import com.xiaomi.mibox.gamecenter.R;

public class MineScaleFocusedView extends View {
	private MineView mFocusView;
	private int[] mFocusLocation = new int[2];
	private int[] mLocation = new int[2];
	private Drawable mDrawableWhite;
	private Drawable mDrawableShadow;
	private float mScale = 1.0f;
	private Paint mPaint = new Paint();
	private Rect mRect;
	private int mCurrPos;
	
	private int mMirrorWidth ;

    public final static int FOCUS_BG_COLOR = 0xFF404040;
	
	public MineScaleFocusedView(Context context, AttributeSet as) {
		this(context, as, 0);
	}

    public MineScaleFocusedView(Context context, AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);

        mMirrorWidth = getResources().getDimensionPixelSize(R.dimen.ITEM_V_WIDTH);
        mDrawableWhite = getResources().getDrawable(R.drawable.item_highlight);
        mDrawableShadow = getResources().getDrawable(R.drawable.item_shadow);
        mPaint.setColor(FOCUS_BG_COLOR);
        mRect = new Rect();

        mLocation = new int[2];
        mFocusLocation = new int[2];
    }

    public MineScaleFocusedView(Context context) {
        this(context, null, 0);
    }
	
	@Override
    protected void onDraw(Canvas canvas) {
    	if(mFocusView!=null){
	    	canvas.save();
			getLocationInWindow(mLocation);
			
	    	MirrorView mirrorView = mFocusView.mirrorView();
			if(mirrorView != null){
				canvas.save();
				mirrorView.getLocationInWindow(mFocusLocation);
		    	canvas.translate(mFocusLocation[0]-mLocation[0]-mMirrorWidth*(mScale-1)/2,
		    			mFocusLocation[1]-mLocation[1]);
		    	canvas.scale(mScale, mScale);
		    	mRect.set(0,0,mMirrorWidth, mirrorView.mirrorHeight());	    	
		    	canvas.drawRect(mRect, mPaint);
		    	mirrorView.draw(canvas);
		    	canvas.restore();
			}
			
			mFocusView.getLocationInWindow(mFocusLocation);
			
			int left = (int)(mFocusLocation[0]-mLocation[0]-mFocusView.getWidth()*(mScale-1)/2);
			int top = (int)(mFocusLocation[1]-mLocation[1]-mFocusView.getHeight()*(mScale-1)/2);
			canvas.translate(left, top);
	    	canvas.scale(mScale, mScale);
	    	mFocusView.getLocationInWindow(mLocation);
			left = mLocation[0] - mFocusLocation[0];
			top = mLocation[1] - mFocusLocation[1];
	    	
			if(0 == mCurrPos){
			    mDrawableShadow.setBounds(left-30, top-25, 
			            mFocusView.getWidth()+75, mFocusView.getHeight()+75);
			}else{
			    mDrawableShadow.setBounds(left-75, 
			            top-25, mFocusView.getWidth()+75, mFocusView.getHeight()+75);
			}
	    	
	    	mDrawableShadow.draw(canvas);    
	    	mDrawableWhite.setBounds(left-2, top-2, mFocusView.getWidth()+2, mFocusView.getHeight()+2);
	    	mDrawableWhite.draw(canvas);
	    	mFocusView.draw(canvas);    	
			canvas.restore();
    	}
    }
	
	public MineView focusedView(){
	    return mFocusView;
	}
	
    public void revert(){
    	if(mFocusView != null){
	    	ObjectAnimator anim = ObjectAnimator.ofFloat(this, "Scale", 
	    			new float[] { 1.1F, 1.0F }).setDuration(50);
	    	anim.start();
    	}
    }
    
    public void restart(){
    	if(mFocusView != null){
        	ObjectAnimator anim = ObjectAnimator.ofFloat(this, "Scale", 
        			new float[] { 1.0F, 1.1F }).setDuration(200);
        	anim.start();
    	}
    }
    
    
	/**
	 * 
	 * @param view
	 * @param pos
	 */
    public void setFocusView(MineView view, int pos){
        mCurrPos = pos;
    	mFocusView = view;
    	ObjectAnimator anim = ObjectAnimator.ofFloat(this, "Scale", 
    	        new float[] { 1.0F, 1.1F }).setDuration(200);
    	anim.start();
    }
    
    public void setScale(float scale){
    	mScale = scale;
    	invalidate();
    }
}
