package com.xiaomi.mibox.gamecenter.account;

import java.net.URLDecoder;

import miui.net.PaymentManager;
import miui.net.PaymentManager.PaymentListener;

import org.json.JSONException;
import org.json.JSONObject;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.data.io.Connection.NetworkError;
import com.xiaomi.mibox.gamecenter.data.io.protocol.ProtocolFactory;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerFuture;
import android.accounts.AuthenticatorDescription;
import android.accounts.OperationCanceledException;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;


/**
 * 小米账户帮助类 1.辅助登陆 2.辅助打开米币中心
 * 修改异步函数为同步函数
 * @author smokelee
 * 
 */
public final class AccountUtils {
	public static final String SERVICE_TYPE_APPMARKET = "appmarket";//stalling平台sid:sappmarket
	public static final String SERVICE_TYPE_GAMECENTER = "gamecenter";
	public static final String ACCOUNT_TYPE = "com.xiaomi";
	
	/**
	 * 注册一个小米帐号
	 * @param ctx
	 * @return 
	 */
	public static boolean MiAccountRegist(Context ctx) {
		AccountManager am = AccountManager.get(ctx);
		String sid = SERVICE_TYPE_GAMECENTER;
		String at = ACCOUNT_TYPE;
		// 1.先检查系统中是否有com.xiaomi的账户
		Account[] account = am.getAccountsByType(at);
		if (account.length == 0) {
		    if(IConfig.DEBUG) Log.e("ACCOUNT", "MiAccountRegist failed");
			// 1.1系统中不存在账户那么添加账户
			AccountManagerFuture<Bundle> info = am.addAccount(at, sid,
					null/* requiredFeatures */, null/* addAccountOptions */,
					(Activity) ctx/* activity */, null, null);
			 if(IConfig.DEBUG) Log.e("ACCOUNT", "call MiAccountRegist");
			try {
				Bundle bundle = info.getResult();
				if (null != bundle.getString("errorMessage")
						&& bundle.getInt("errorCode") == 8) {// 账户未激活
					return false;
				}
			} catch (Exception e) {// 注册失败
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	
	/**
	 * 使用米币账户登录
	 * 
	 * @param act
	 * @param cb
	 */
	public static void GameCenterAccountLogin(final Activity act,final ILoginCallback cb) {
		new Thread() {
			public void run() {
				try {
					AccountManager am = AccountManager.get(act);
					if (!AccountUtils.isSupportXiaoMiAccount(am)) {
					    if(IConfig.DEBUG) Log.e("ACCOUNT", "support xiaomi account");
						cb.onGameCenterFinishLogin(
								act,
								ILoginCallback.LOGIN_NOT_SUPPRORT_XIAOMI_ACCOUNT,
								null,
								null);
						return;
					}
					Account[] account = am.getAccountsByType(AccountUtils.ACCOUNT_TYPE);
					if (account.length == 0) {
					    if(IConfig.DEBUG) Log.e("ACCOUNT", "LOGIN:no xiaomi account");
						cb.onGameCenterFinishLogin(act,
								ILoginCallback.LOGIN_NO_XIAMI_ACCOUNT,
								null,
								null);
						return;
					}
					if(IConfig.DEBUG) Log.e("ACCOUNT", "1111");
					// 登录游戏中心服务
					Bundle options = new Bundle();
					options.putInt("client_action", 1);
					AccountManagerFuture<Bundle> info = am.getAuthToken(
							account[0], AccountUtils.SERVICE_TYPE_GAMECENTER, options, act, null, null);
					if(IConfig.DEBUG) Log.e("ACCOUNT", "2222");
					Bundle bundle = info.getResult();
					// 判断当前的账户是否激活
					if (null != bundle.getString("errorMessage")
							&& bundle.getInt("errorCode") == 8) {
					    if(IConfig.DEBUG) Log.e("ACCOUNT", "errrorMessage:" + bundle.getString("errorMessage")
					            + ", errCode:" + bundle.getInt("errorCode"));
						cb.onGameCenterFinishLogin(act,
								ILoginCallback.LOGIN_ACCOUNT_NOT_ACITVE,
								null,
								null);
						return;
					}
					if(IConfig.DEBUG) Log.e("ACCOUNT", "3333");
					// 登录未完成，直接退出
					if (!info.isDone()) {
					    if(IConfig.DEBUG) Log.e("ACCOUNT","fail");
						cb.onGameCenterFinishLogin(act,
								ILoginCallback.LOGIN_GAMECERTER_FAIL, 
								null,
								null);
						return;
					}
					// 读取ServicToken
					String authToken = null;
					try {
						authToken = bundle
								.getString(AccountManager.KEY_AUTHTOKEN);
					} catch (Exception e) {
						e.printStackTrace();
					}
					if(IConfig.DEBUG) Log.e("ACCOUNT", "authtoken:" + authToken);
					if (TextUtils.isEmpty(authToken)) {
						cb.onGameCenterFinishLogin(act,
								ILoginCallback.LOGIN_GAMECERTER_FAIL, 
								null,
								null);
						return;
					}
						String serviceToken = URLDecoder.decode(authToken, "UTF-8");
						serviceToken = AccountUtils.parserServiceToken(serviceToken);
						if (TextUtils.isEmpty(serviceToken)) {
							cb.onGameCenterFinishLogin(act,
									ILoginCallback.LOGIN_GAMECERTER_FAIL, 
									null,
									null);
							return;
						}
						if (ServiceToken.parse(serviceToken) != null) {
							cb.onGameCenterFinishLogin(act,
									ILoginCallback.LOGIN_GAMECENTER_SUCCESS,
									ServiceToken.getServiceToken().mid,
									ServiceToken.getServiceToken().uid);
							return;
						}
				}catch(OperationCanceledException e){
				    
					//用户点击了异常 需要记录下行为
					if(act instanceof Activity){//只在首页记录行为
						LoginManager.getLoginManager().setUserCancelStatus(true);
					}
				}  catch (Exception e) {
				    e.printStackTrace();
					cb.onGameCenterFinishLogin(act, ILoginCallback.LOGIN_GAMECERTER_FAIL,
							null,
							null);
					return;
				}
			}
		}.start();
	}
	
	private static String parserServiceToken(String ordin) {
		String ret = null;
		int index = ordin.lastIndexOf(',');
		String json = ordin.substring(0, index);
		try {
			JSONObject root = new JSONObject(json);
			JSONObject st = root.getJSONObject("serviceToken");
			ret = st.toString();
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return ret;
	}

	/**
	 * 系统是否支持小米账户
	 * 
	 * @param am
	 * @return
	 */
	public static boolean isSupportXiaoMiAccount(AccountManager am) {

		for (AuthenticatorDescription account : am.getAuthenticatorTypes()) {
			if (TextUtils.equals(account.type, ACCOUNT_TYPE)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 获取小米账户，如果系统不支持小米账户返回null
	 * 
	 * @param act
	 * @return
	 */
	public static Account[] getXiaomiAccount(Context act) {
		AccountManager am = AccountManager.get(act);
		if (!isSupportXiaoMiAccount(am)) {
			return null;
		}
		return am.getAccountsByType(ACCOUNT_TYPE);
	}

	public static boolean HasXiaomiAccountInternal(Context act) {
		Account[] ac = getXiaomiAccount(act);
		return ac != null && ac.length > 0;
	}
	
	/**
	 * 打开小米账户页面
	 * @param ctx
	 */
	public static void openXiaomiAccountSetting(Context ctx) {
        Intent intent = new Intent("android.settings.XIAOMI_ACCOUNT_SYNC_SETTINGS");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(intent);
    }
	
	/**
	 * 查询余额
	 * 
	 * @param act
	 */
	public static void query_balance(final Activity act, final IQueryBalance cb) {
		new Thread(){
			public void run(){
				String paramString = getverify(act);
				if(TextUtils.isEmpty(paramString)){
					if(cb != null){
						cb.onFinish(IQueryBalance.QUERY_CODE_FAIL, -1);
					}
					return;
				}
				try {
					PaymentManager.get(act).getMiliBalance(act, "", "100",
							paramString, new PaymentListener() {
								@Override
								public void onSuccess(String paymentId,
										Bundle result) {
									long balance = result.getLong(PaymentManager.PAYMENT_KEY_TRADE_BALANCE);
									cb.onFinish(IQueryBalance.QUERY_CODE_SUCCESS,
											balance);
								}

								@Override
								public void onFailed(String paymentId,
										int code, String message, Bundle result) {
									cb.onFinish(IQueryBalance.QUERY_CODE_FAIL,
											0);
								}
							});
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}.start();
	}

	/**
	 * 打开米币中心
	 * 
	 * @param act
	 */
	public static final String SERVICE_ID_BOX_APP = "108";
	public static final String SERVICE_ID_BOX_THIRD = "116";
	public static final String SERVICE_ID_BOX_VIDEO = "107";//这个没有问题
	public static final String SERVICE_ID_GAMECENTER = "100";//XXX 据刘爽说已经实现了 否则调用系统的页面会显示查询失败
	public static void open_mibi(Activity act, Account account) {
		Intent intent = new Intent("xiaomibox.intent.action.SHOWMIBICENTER");
		intent.putExtra("intent_key_account", account);
		intent.putExtra("intent_key_service_id", SERVICE_ID_BOX_VIDEO);
		try {
			act.startActivity(intent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String VERIFY_GAMECENTER = null;
	private static String getverify(Activity act){
		if(VERIFY_GAMECENTER == null)
		{
			Pair<String, NetworkError> ret = ProtocolFactory.protocol_load_sign(act, "{market:100}");
			if(TextUtils.isEmpty(ret.first)){
				return null;
			}
			VERIFY_GAMECENTER = ret.first;
		}
		StringBuilder sb = new StringBuilder();
		sb.append("{verify: \"{market:100}\", sign : \"");
		sb.append(VERIFY_GAMECENTER);
		sb.append("\"}");
		String paramString = sb.toString();
		sb = null;
		return paramString;
	}
}
