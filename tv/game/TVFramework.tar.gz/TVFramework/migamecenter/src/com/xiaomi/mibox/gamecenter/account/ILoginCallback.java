package com.xiaomi.mibox.gamecenter.account;

import android.app.Activity;

/**
 * 登录回调
 * 
 * @author smokelee
 * 
 */
public interface ILoginCallback {
	/** 系统中没有小米账户存在 */
	public static final int LOGIN_NO_XIAMI_ACCOUNT = 1;

	/** 系统不支持小米账户 */
	public static final int LOGIN_NOT_SUPPRORT_XIAOMI_ACCOUNT = 2;

	/** 系统的小米账户没有激活 */
	public static final int LOGIN_ACCOUNT_NOT_ACITVE = 3;

	/** 登录失败 */
	public static final int LOGIN_GAMECERTER_FAIL = 4;

	/** 登录成功 */
	public static final int LOGIN_GAMECENTER_SUCCESS = 5;

	public void onGameCenterFinishLogin(Activity act, int code, String mid, String fuid);
	
//	public void onAppMarketFinishLogin(int code, String mid, String serviceToken, String securityKey);
}
