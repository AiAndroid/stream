package com.xiaomi.mibox.gamecenter.ui.gamedetail;

public interface OnSeekBarListener {
	/**
	 * 报告总数
	 * @param total
	 */
	public void seerBarTotal(int total);
	
	/**
	 * 通知位置已经切换了
	 * @param newPos
	 */
	public void seekBarPositionChanged(int newPos);
}
