package com.xiaomi.mibox.gamecenter.utils;

import android.content.Context;

public class Constants
{
	public static final String SPLIT_PATTERN = ",";
	public static final String SPLIT_LONG_PATTERN = ",  ";
	public static final String SPLIT_PATTERN_TEXT = ", "; // 用于文本的分隔
	public static final String SPLIT_PATTERN_SEMICOLON = ";";

	public static final String SYSTEM_APP_ID_PREFIX = "sys-";
	
	public static final String AES_KEY = "cn.wali.YF.Oss.c";

	/* Intent Extras */
	public static final String EXTRA_TAB = "extra_tab";

	//返回键 是返回MainTab还是返回上一级
	public static final String EXTRA_HOME = "extra_home";
	public static final String EXTRA_URL = "extra_url";
	
	public static final String APK_MIME_TYPE = "application/vnd.android.package-archive";
	
    // column file path in 2.3 DownloadManager
    public static final String COLUMN_FILE_PATH = "file_path";
    
    public static final String EXTRA_MAIN_TAB_EXTRA = "com.xiaomi.mibox.gamecenter.tab_extra";
  
    /* Constants for gingerbread*/
    public static final String ACTION_APPLICATION_MESSAGE_UPDATE = "android.intent.action.APPLICATION_MESSAGE_UPDATE";

    public static final String EXTRA_UPDATE_APPLICATION_MESSAGE_TEXT = "android.intent.extra.update_application_message";

    public static final String EXTRA_UPDATE_APPLICATION_COMPONENT_NAME = "android.intent.extra.update_application_flatten_name";

	/* Base URLs */
	public static final String HOST_URL_BASE = "http://";
	
	public static final String MITV_VIDEO_INTENT_ACTION = "mitv.intent.action.VIDEO_PLAY";

//	public static final String EN_UPGRADE = "http://oss.wali.com/osscontrol/enupgrade.htm";
	public static final String LOAD_SIGN = "http://app.migc.xiaomi.com/cms/interface/v5/sign.php";

	/**
	 * 瓦力自己的
	 */
	public static String WALI_BASE;
	public static String RECOMMEND_URL;
	public static String RANK_URL;//排行
	public static String GAME_DETAIL_URL;//详情
	public static String SUBJECT_INFO_URL;
	public static String UPDATE_GAME_DOWNLOAD;
	public static String QUERY_GAMES;//解析本地游戏数据的
	public static String GOT_GAME_UPDATE2;//获取游戏中心新加以及更新的游戏信息 lihao
	public static String FORECAST_INFO;//预告
	public static String GUESS;//猜您喜欢
	public static String CATEGORY_URL; //分类

	public static void configURLs( Context context )
	{
		switchToProduct();
	}
	
	public static void switchToProduct(){
//		WALI_BASE = "http://mis.migc.wali.com/cms/interface/v5/tv/";//测试环境
		WALI_BASE = "http://app.migc.xiaomi.com/cms/interface/v5/tv/";//正式地址
		internalConfigURLs();
	}

	private static void internalConfigURLs()
	{        
		RANK_URL = WALI_BASE + "rankgamelist.php";
		GAME_DETAIL_URL = WALI_BASE + "gameinfo.php";
		SUBJECT_INFO_URL = WALI_BASE + "subjectgamelist.php";

		RECOMMEND_URL = WALI_BASE + "featured.php";
		
		UPDATE_GAME_DOWNLOAD = "http://app.migc.xiaomi.com/cms/interface/v5/updatedown.php";
		QUERY_GAMES = WALI_BASE + "mygameupdate.php";
		//供桌面Luncher调用的接口 客户端获取数据然后post给Luncher
		//旧接口 GOT_GAME_UPDATE2 = "http://atv.migc.xiaomi.com/mitvcms/interface/v2/portal.php";
		GOT_GAME_UPDATE2 = WALI_BASE + "portal.php";
				
		FORECAST_INFO = WALI_BASE + "gamenoticeinfo.php";
		
		GUESS = WALI_BASE + "guess.php";
		
		CATEGORY_URL = WALI_BASE + "classgamelist.php";
	}

	/* 参数 */
	public static final String CLIENT_ID = "clientId";
	public static final String SDK_VERSION = "sdk";
	public static final String STAMP = "stamp";
	public static final String VERSION = "os";
	public static final String LANGUAGE = "la";
	public static final String COUNTRY = "co";
	public static final String DEVICE = "device";
	
	public static final String ID = "id";
	public static final String UID = "uid";//用户ID
	public static final String BID = "bid";
	public static final String CID = "cid";
	public static final String VN = "vn";
	public static final String PLATFORM = "platform";
	public static final String MAC_WIFI = "macWifi";
	public static final String MID = "mid";
	
	public static final String FUID = "fuid";//小米伪ID
	public static final String APP_ID = "appId";
	public static final String GAME_ID = "gameId";
	public static final String CATEGORY_ID = "categoryId";
	public static final String APPS = "apps";
	public static final String PACKAGE_NAME = "packageName";
	public static final String RELEASE_KEY = "key";
	public static final String PAGE = "page";
	public static final String NAME = "name";
	public static final String CLASS_ID = "classId";// 分类ID
	public static final String CLASS_TYPE = "classType";// 热门排行（hot）新品上线（new）所有游戏（all），如缺省默认hot
	public static final String PAGE_SIZE = "pageSize"; // 客户端每页显示大小
	public static final String STAMP_TIME = "stampTime";// 上传参数 XXX
	public static final String SUBJECT_ID = "subjectId";
	public static final String CHANGE_LOG = "changeLog";
	public static final String CLIENT_VERSION_CODE = "versionCode";
	public static final String UA = "ua";
	public static final String FROM = "from";
	public static final String POSITION = "position";
	public static final String TEMPLET = "tpl";
	
    /*服务器下发的key */
	public static final String JSON_ERROR_CODE = "errCode";//0 为成功 非0为错误
	public static final String JSON_GAME_LIST = "gameList";//
	public static final String JSON_GAME_UPDATE_LIST = "gameUpList";//游戏更新列表
	public static final String JSON_LAST_TIME = "lastTime";// 服务器下发的字段
	public static final String JSON_UPDATE_TIME = "updateTime";// 服务器下发的字段 游戏内容中
	public static final String JSON_CDN_DOMAIN = "cdnDomain";
	public static final String JSON_MODULE = "module";
	public static final String JSON_MOD_NAME = "modName";
	public static final String JSON_MOD_ACTION_URL = "modActionUrl";
	public static final String JSON_PIC_TYPE = "picType";
	public static final String JSON_MOD_PIC = "modPic";

	/* 最顶层 JSON key */
	public static final String JSON_PIC_URL = "picUrl";
	public static final String JSON_ANIMATION = "animation";
	public static final String JSON_STYLE = "style";
	public static final String JSON_BACKGROUND = "background";
	public static final String JSON_POSTER = "poster";
	public static final String JSON_TYPE = "type";
	public static final String JSON_DESCRIPTION = "description";
	public static final String JSON_NOTICE_INFO = "noticeInfo";
	public static final String JSON_BACKGROUND_IMG = "backgroundImg";
	
	public static final String STYLE_STATIC = "static_pic";
	public static final String STYLE_ANIM = "animation";
	public static final String JSON_STATIC_PIC_CDN = "staticPicCdn";

	/* app info */
	public static final String JSON_APP_ID = "id";
	public static final String JSON_XIAOMI_APP_ID = "appId";
	public static final String JSON_GAME_ID = "gameId";
	public static final String JSON_PACKAGE_NAME = "packageName";
	public static final String JSON_DISPLAY_NAME = "displayName";
	public static final String JSON_VERSION_CODE = "versionCode";
	public static final String JSON_VERSION_NAME = "versionName";
	public static final String JSON_PUBLISHER_NAME = "publisherName";
	public static final String JSON_PUBLISHER_ID = "publisherId";
	public static final String JSON_ICON = "icon";
	public static final String JSON_RATING = "ratingScore";
	public static final String JSON_PRICE = "price";
	public static final String JSON_SIZE = "apkSize";
	public static final String JSON_SUMMARY = "summary";//游戏简介
	public static final String JSON_SCREEN_SHOTS = "screenShot";//游戏截图
	public static final String JSON_GAME_APK_URL = "gameApk";// 游戏APK安装文件下载地址
	public static final String JSON_DOWNLOAD_COUNT = "downloadCount";// 游戏下载次数
	public static final String JSON_USER_COUNT = "userCount";// 玩家人数
	public static final String JSON_CATEGORY_ID = "categoryId";
	public static final String JSON_CATEGORY_NAME = "categoryName";
	public static final String JSON_PIC = "pic";
	public static final String JSON_INTRODUCTION = "introduction";
	public static final String JSON_OPERATE_DEVICE  = "operateDevice";//操作设备ID
	public static final String JSON_CHANGE_LOG = "changeLog";
	public static final String JSON_ASSERT_LIST = "assetList";

	/* download app json */
	public static final String JSON_APP_HASH = "apkHash";
	
	// common 
	public static final String JSON_ITEM_TITLE = "title";
	public static final String JSON_TEMPLATE = "template";

	/* suggest json */
	public static final String JSON_SUGGESTION = "suggestion";
	public static final String JSON_CLASS_LIST = "classList";
	
	public static final String JSON_ANIMATION_ALGORITHM_ID = "algorithmId";
	public static final String JSON_ANIMATION_PICTURELAYERS = "picList";
	public static final String JSON_ANIMATION_ZORDER = "zIndex";
	public static final String JSON_ANIMATION_CDN = "picUrl";
	
	
	/**subject */
	public static final String JSON_BIG_PIC_URL ="bigPicUrl";
	public static final String JSON_FUZZY_PIC_URL = "fuzzyPicUrl";
	public static final String JSON_BG_PIC_URL = "bgPicUrl";
	
	/*
	 * 综合运维平台字段
	 */
	public static final String CLIENT_UPDATE_TIME = "client_update_time";
	public static final String RESPONSE_RETURN = "Return";
	public static final String STATUS = "Status";
	public static final String TASK_TYPE = "TaskType";
	public static final String TASK_ID = "TaskId";
	public static final String TITLE = "Title";
	public static final String INTRO = "Intro";
	public static final String DISPLAY = "Display";//显示方式
	public static final String URL = "Url";
	public static final String CLIENT_UPDATE_MESSAGE_KEY = "client_update_message_key";
//	public static final String CLIENT_REQUEST_UUID_KEY = "client_request_uuid_key";
	public static final String JSON_UPDATE_CLIENT_VERSION = "ClientVersion";
	public static final String JSON_UPDATE_DOWNLOAD_FILE = "DownloadFile";
	public static final String JSON_UPDATE_DOWNLOAD_PATH = "DownloadPath";
	public static final String JSON_UPDATE_VERSION_NUMBER = "VersionNumber";
	public static final String JSON_UPDATE_MESSAGE = "Message";
	public static final String JSON_UPDATE_MESSAGE_PAGE= "MessagePage";
	public static final String JSON_UPDATE_DOWNLOAD_URL = "downloadurl";
	public static final String JSON_UUID_STRING = "UID";

	public static final String JSON_INTEGRAL_Integral = "Integral"; //积分系统报文 账户积分字段
	public static final String JSON_INTEGRAL_AddIntegral = "AddIntegral"; //积分系统报文  本次新增积分(可以为负数) 
	
//	public static final String GAMECENTER_REQUEST_PLATFROM = "http://42.62.12.27:8085/micossapi/coss.htm";
	public static final String GAMECENTER_REQUEST_PLATFROM = "http://app.migc.wali.com/migcoss/coss.htm";
	public static String MIBOX_GAMECENTER_BID = "703";
	public static String MITV_GAMECENTER_BID = "704";
	public static String WL_GAMECENTER_VERSION = "1.0.0.0";
	
	private Constants(){
		
	}
	
	public static final String OPEN_DATE ="date"; // 每天打开时间
	public static final String OPEN_COUNT = "cnt"; // 每天打开次数
	
	public static final String INTENT_ACTION_GAMECENTER_LOGIN = "intent_action_game_center_login";
	public static final String INTENT_ACTION_GAMECENTER_LOGIN_FAIL = "intent_action_game_center_login_fail";
	public static final String INTENT_ACTION_XIAOMI_ACCOUNT_LOGOUT = "intent_action_xiaomi_account_logout";
	public static final String INTENT_ACTION_XIAOMI_ACCOUNT_ADDED = "intent_action_xiaomi_account_added";
	public static final String INTENT_EXTRA_KEY_COMMENT_LIST_INFO = "intent_extra_key_comment_list_info";
	public static final String INTENT_EXTRA_KEY_GAMEINFO = "intent_extra_key_xiaomi_gamecenter_gameinfo";
	public static final String INTENT_EXTRA_KEY_XIAOMI_GAMECENTER_COMMENT_INFO = "intent_extra_key_xiaomi_gamecenter_commentinfo";
	public static final String INTENT_EXTRA_UPDATE_TYPE = "extra_update_type";
	public static final String INTENT_EXTRA_ACCOUNT = "extra_account";
	
	//ACTION_LOGIN_ACCOUNTS_PRE_CHANGED通知 系统帐号发生变化时，1是删除账户，2是增加账户
    public static final int ACCOUNT_CHANGE_TYPE_REMOVE = 1;
    public static final int ACCOUNT_CHANGE_TYPE_ADD = 2;
}
