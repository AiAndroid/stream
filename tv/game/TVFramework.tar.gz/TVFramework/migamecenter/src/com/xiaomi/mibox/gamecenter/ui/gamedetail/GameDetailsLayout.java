package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Scroller;

public class GameDetailsLayout extends LinearLayout {

    private Scroller mScroller;
    private int mLastScrollerY = 0;
    private int mInitalY = 0;
    
    private int mCurrScrollPos = 0;


    public GameDetailsLayout(Context context) {
        this(context, null, 0);
    }

    public GameDetailsLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public GameDetailsLayout(Context context, AttributeSet attrs, int UIStyle) {
        super(context, attrs, UIStyle);
        init(context);
    }


    public interface ExcuteKeyProcess {
        public boolean excuteKey(KeyEvent event);
    }
    
    private ExcuteKeyProcess mExcuteKeyProcess;

    
    public void setExcuteKeyProcess(ExcuteKeyProcess p){
        mExcuteKeyProcess = p;
    }
    
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if(mExcuteKeyProcess != null){
            return super.dispatchKeyEvent(event) || mExcuteKeyProcess.excuteKey(event);
        }else{
            return super.dispatchKeyEvent(event);
        }
    }

    @Override
    public void computeScroll() {
        if (mScroller.computeScrollOffset()) {
            final float deltaY = mScroller.getCurrY() - mLastScrollerY;
            if (Math.abs(deltaY) >= 1) {
                mLastScrollerY = mScroller.getCurrY();
                mInitalY += deltaY;
                relocateAppDetailsLayout();
            }
            invalidate();
        }else{
            mLastScrollerY = 0;
        }
    }
    
    public boolean needScrollDown(){
        return (0 == mCurrScrollPos 
        		&& 0 == mScroller.getCurrX()
        		&& mScroller.isFinished());
    }
    
    public boolean needScrollUp(){
        return (mCurrScrollPos < 0
        		&& mScroller.isFinished());
    }
    
    public void smoothScrollBy(int deltaY, int duration){
        mCurrScrollPos += deltaY;
        mScroller.forceFinished(true);
        mScroller.startScroll(0, 0, 0, deltaY, duration);
        invalidate();
    }
    
    private void relocateAppDetailsLayout(){
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, 
                RelativeLayout.LayoutParams.MATCH_PARENT);
        params.topMargin = mInitalY;
        setLayoutParams(params);
    }

    private void init(Context context){
        mScroller = new Scroller(context);
    }
}
