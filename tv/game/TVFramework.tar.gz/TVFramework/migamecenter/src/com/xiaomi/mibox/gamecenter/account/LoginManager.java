package com.xiaomi.mibox.gamecenter.account;

import java.util.concurrent.CopyOnWriteArrayList;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.data.GlobalConfig;
import com.xiaomi.mibox.gamecenter.data.IUserData;
import com.xiaomi.mibox.gamecenter.data.io.ClientRegister;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.xmsf.account.data.XiaomiUserInfo;
import com.xiaomi.xmsf.account.utils.CloudHelper;

import android.accounts.Account;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;

public class LoginManager implements ILoginCallback, IQueryUserInfo {
//	public static final String LOCAL_BROADCAST_ACCOUNT_CHANGE = "com.xiaomi.gamecenter.account.change";
	private static final String ACCOUNT_PRE_CHANGED = "android.accounts.LOGIN_ACCOUNTS_PRE_CHANGED";
	//账户变动 到底是哪个？
	private static final String ACCOUNT_CHANGED = "android.accounts.LOGIN_ACCOUNTS_CHANGED";
	private Context mContext;
	private static LoginManager loginManager = null;
	private boolean mUserCancel;
	private Object mSyncObj = new Object();
	
	public static LoginManager getLoginManager() {
		return loginManager;
	}
	
	public static void init(Context ctx) 
	{
		if(null == loginManager) {
			loginManager = new LoginManager(ctx);
		}
	}
	
	public void setUserCancelStatus(boolean cancel){
		synchronized (mSyncObj) {
			mUserCancel = cancel;
		}
	}
	
	public boolean userCancelStatus(){
		synchronized (mSyncObj) {
			return mUserCancel;
		}
	}
	
	public void loginIfNeed(Activity act){
		if(isGameCenterLogin()){
			return;
		}
		if(AccountUtils.HasXiaomiAccountInternal(act)) {
		    if(IConfig.DEBUG) Log.e("ACCOUNT", "has xiaomi account");
			loginStatus = LOGIN_STATUS_LOGOUT;
			AccountUtils.GameCenterAccountLogin(act, this);
		}else {
		    if(IConfig.DEBUG) Log.e("ACCOUNT", "not xiaomi account");
			loginStatus = LOGIN_STATUS_NOXIAOMIACCOUNT;
			xiaomiAccountLogout();
		}
	}
	
    public void xiaomiAccountLogout() {
    	loginStatus = LOGIN_STATUS_NOXIAOMIACCOUNT;
    }
    
    public void registXiaoMiAccount(final Activity act) {
		new AsyncTask<Void,Void,Boolean>(){
			@Override
			protected Boolean doInBackground(Void... params) {
				boolean success = AccountUtils.MiAccountRegist(act);
				return Boolean.valueOf(success);
			}

			@Override
			protected void onPostExecute(Boolean result) {
				super.onPostExecute(result);
				if(result.booleanValue()) {
					AccountUtils.GameCenterAccountLogin(act, LoginManager.this);
				}
			}
		}.execute();
    }
 
	private LoginManager(Context ctx){
		mContext = ctx;
		IntentFilter  filter = new IntentFilter();
		filter.addAction(ACCOUNT_CHANGED);
		filter.addAction(ACCOUNT_PRE_CHANGED);
		mContext.registerReceiver(mReceiver, filter);
	}
	
	private BroadcastReceiver mReceiver = new BroadcastReceiver(){
		@Override
		public void onReceive(Context context, Intent intent) {
			if(null == intent){
				return;
			}
			final String action = intent.getAction();
			if (ACCOUNT_CHANGED.equals(action)){
				if(loginStatus >= LOGIN_STATUS_LOGIN_GAMECENTER){//已经登录的验证下
					Account[] accounts = AccountUtils.getXiaomiAccount(mContext);//没有监听到退出的事件
					if(null == accounts|| 0 == accounts.length){
						xiaomiAccountLogout();

						LocalBroadcastManager lbm = LocalBroadcastManager
								.getInstance(mContext.getApplicationContext());
						Intent i = new Intent(Constants.INTENT_ACTION_XIAOMI_ACCOUNT_LOGOUT);
						lbm.sendBroadcast(i);
					}
				}else{//没有的登录的验证下时候已经登录了
					LocalBroadcastManager lbm = LocalBroadcastManager
							.getInstance(mContext.getApplicationContext());
					Intent i = new Intent(
							Constants.INTENT_ACTION_XIAOMI_ACCOUNT_ADDED);
					lbm.sendBroadcast(i);
				}
			}else if(ACCOUNT_PRE_CHANGED.equals(action)) {
				int type = intent.getIntExtra(
						Constants.INTENT_EXTRA_UPDATE_TYPE, -1);
				if(-1 == type){
					return;
				}
				Account account = intent.getParcelableExtra(
						Constants.INTENT_EXTRA_ACCOUNT);
				if(null == account){
					return;
				}
				if (!TextUtils.equals(account.type, AccountUtils.ACCOUNT_TYPE)) {
					return;
				}
				if (type == Constants.ACCOUNT_CHANGE_TYPE_ADD) {
					if (!AccountUtils.HasXiaomiAccountInternal(mContext
							.getApplicationContext())) {
						return;
					}
					LocalBroadcastManager lbm = LocalBroadcastManager
							.getInstance(mContext.getApplicationContext());
					Intent i = new Intent(
							Constants.INTENT_ACTION_XIAOMI_ACCOUNT_ADDED);
					lbm.sendBroadcast(i);
				} else if (type == Constants.ACCOUNT_CHANGE_TYPE_REMOVE) {
					xiaomiAccountLogout();

					LocalBroadcastManager lbm = LocalBroadcastManager
							.getInstance(mContext.getApplicationContext());
					Intent i = new Intent(Constants.INTENT_ACTION_XIAOMI_ACCOUNT_LOGOUT);
					lbm.sendBroadcast(i);
				}
			}
		}
	};
	
	private int loginStatus;
	
	public int getLoginStatus() {
		return loginStatus;
	}
	
	/** 系统中没有小米账户存在 */
	public static final int LOGIN_STATUS_NOXIAOMIACCOUNT = 0;
	public static final int LOGIN_STATUS_LOGOUT = 1;
	public static final int LOGIN_STATUS_UNACTIVIED = 2;
	public static final int LOGIN_STATUS_LOGIN_GAMECENTER = 3;
//	public static final int LOGIN_STATUS_LOGIN_APPMARKET = 4; //因为不需要评论 所以不需要应用超市的TOKEN
	
	public boolean isGameCenterLogin() {
		Account[] accounts = AccountUtils.getXiaomiAccount(mContext);//没有监听到退出的事件
		if(accounts != null && accounts.length > 0){
			return loginStatus >= LOGIN_STATUS_LOGIN_GAMECENTER;
		}else{
			return false;
		}
	}
    
    public void gotoAccountSetting(Activity act) {
    	AccountUtils.openXiaomiAccountSetting(act);
    }
    
    private void local_broadcast(String action){
		LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(mContext);
		Intent intent = new Intent(action);
		lbm.sendBroadcast(intent);
	}

	@Override
	public void onGameCenterFinishLogin(Activity act, int code, String mid,
			String fuid) {
	    if(IConfig.DEBUG) Log.e("ACCOUNT", "code=" + code + ";mid=" + mid + ";fuid" + fuid);
		if(ILoginCallback.LOGIN_ACCOUNT_NOT_ACITVE == code) {
			loginStatus = LOGIN_STATUS_UNACTIVIED;
		}
		if (ILoginCallback.LOGIN_GAMECENTER_SUCCESS != code) {
			local_broadcast(Constants.INTENT_ACTION_GAMECENTER_LOGIN_FAIL);
			return;
		}
		if (TextUtils.isEmpty(mid)) {
			local_broadcast(Constants.INTENT_ACTION_GAMECENTER_LOGIN_FAIL);
			return;
		}
		
		loginStatus = LOGIN_STATUS_LOGIN_GAMECENTER;
    	
		XiaomiUserInfo userInfo = UserInfoUtils.getXiaomiUserInfo(act);
		String localMidString = "";
		if(userInfo != null){
			localMidString = userInfo.getUserId();
		}
		if(!TextUtils.equals(localMidString, mid)) {
			//删除本地的数据
			UserInfoUtils.reset(act);
//			reset_account();
	    	
			GlobalConfig config = GlobalConfig.getInstance();
			config.Set(IUserData.XIAOMI_ID, mid);
			config.Set(IUserData.WALI_ID, fuid);
			config.SaveNow();
            //重新绑定下UID
			new ClientRegister().execute();
		}
//		local_broadcast(LOCAL_BROADCAST_ACCOUNT_CHANGE);
		local_broadcast(Constants.INTENT_ACTION_GAMECENTER_LOGIN);
	}
	
	private volatile boolean mQueringInfo;//正在查询
	private volatile boolean mQuerynfoSuccess;//查询成功
	private CopyOnWriteArrayList<IQueryUserInfo> mQueryInfoListeners 
		= new CopyOnWriteArrayList<IQueryUserInfo>();
	
	public void addQueryInfoListeners(Activity act, IQueryUserInfo listener){
		mQueryInfoListeners.add(listener);
		//不在查，并且是查询失败的
		synchronized (LoginManager.class) {
			if(!mQueringInfo && !mQuerynfoSuccess){
				mQueringInfo = true;
				CloudHelper.handleQueryUserInfo2(act, this);
			}
		}
	}
	
	public void removeQueryInfoListeners(IQueryUserInfo listener){
		mQueryInfoListeners.remove(listener);
	}
	
	/**
	 * 退出主界面就重置
	 */
	public void resetQuery(){
		mQueringInfo = false;
		mQuerynfoSuccess = false;
		mQueryInfoListeners.clear();
	}
	
	private void notifyUserInfo(int code, XiaomiUserInfo userInfo){
		for(IQueryUserInfo listener : mQueryInfoListeners){
			if(listener != null){
				listener.onFinish(code, userInfo);
			}
		}
	}

	@Override
	public void onFinish(int code, XiaomiUserInfo userInfo) {
		synchronized (LoginManager.class) {
			mQueringInfo = false;
			if(code == IQueryUserInfo.QUERY_USER_INFO_SUCCESS){
				mQuerynfoSuccess = true;
			}
		}
		notifyUserInfo(code, userInfo);
	}
}
