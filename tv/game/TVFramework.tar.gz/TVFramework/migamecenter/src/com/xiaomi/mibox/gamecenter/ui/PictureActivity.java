package com.xiaomi.mibox.gamecenter.ui;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.R;
import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * 只显示一张图的页面
 * @author mengshu
 *
 */
public class PictureActivity extends Activity{

	public static final String INFO = "com.xiaomi.mibox.gamecenter.PictureActivity.info";
	
	//显示手柄如何购买的页面
	public static final int PURCHASE_HANDLER_URL = 0;
//	public static final int DISPLAY_CONTROL_URL = 1;
//	public static final int DISPLAY_MOURSE = 2;
//	public static final int DISPLAY_HANDLER = 3;//已经连接上手柄的页面
	
	private int mInfo;
	private RelativeLayout mRootLayout;
	
	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		
		if(IConfig.DEBUG) Log.e("PictureActivity", "onCreate");
		mInfo = getIntent().getIntExtra(INFO, PURCHASE_HANDLER_URL);
		
		mRootLayout = new RelativeLayout(this);
		mRootLayout.setBackgroundResource(R.drawable.guide_bg);
		
		RelativeLayout.LayoutParams rlp;
		Resources res = getResources();
		
		ImageView imageView = new ImageView(this);
        int ICON_VIEW_ID = 0x34;
		imageView.setId(ICON_VIEW_ID);
		LinearLayout layout;
		LinearLayout.LayoutParams llp;
		
		TextView textView = new TextView(this);
		textView.setTextColor(res.getColor(R.color.common_text_color));
//		Paint p = textView.getPaint();
//		p.setShadowLayer(1, 1, 1, 
//				res.getColor(R.color.common_text_shadow_color));
		if(PURCHASE_HANDLER_URL == mInfo){
			layout = new LinearLayout(this);
			layout.setOrientation(LinearLayout.VERTICAL);
			rlp = new RelativeLayout.LayoutParams(
					RelativeLayout.LayoutParams.WRAP_CONTENT,
					RelativeLayout.LayoutParams.WRAP_CONTENT);
			rlp.addRule(RelativeLayout.CENTER_HORIZONTAL);
			rlp.topMargin = 245;
			mRootLayout.addView(layout, rlp);
			
			imageView.setBackgroundResource(R.drawable.handler_url);
			llp = new LinearLayout.LayoutParams(
					LinearLayout.LayoutParams.WRAP_CONTENT,
					LinearLayout.LayoutParams.WRAP_CONTENT);
			llp.gravity = Gravity.CENTER_HORIZONTAL;
			layout.addView(imageView, llp);
			
			textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 
					res.getInteger(R.integer.operator_guide_secondary_text_size));
			textView.setText(R.string.hint_purcharge_handler);
			textView.setGravity(Gravity.CENTER_HORIZONTAL);
			textView.setLineSpacing(10, 1.0f);
			llp = new LinearLayout.LayoutParams(
					LinearLayout.LayoutParams.WRAP_CONTENT,
					LinearLayout.LayoutParams.WRAP_CONTENT);
			llp.topMargin = 74;
			llp.gravity = Gravity.CENTER_HORIZONTAL;
			layout.addView(textView, llp);
		}
		
//		if(IConfig.DEBUG){
//			TextView tv = new TextView(this);
//			tv.setTextColor(Color.WHITE);
//			tv.setTextSize(TypedValue.COMPLEX_UNIT_SP,
//					UIMargin.HANDLE_HINT_SMALL_TEXT_SIZE);
//			tv.setText(Client.GAMECENTER_VERSION_NAME + '|' + Client.GAMECENTER_VERSION);
//			rlp = new RelativeLayout.LayoutParams(
//					RelativeLayout.LayoutParams.WRAP_CONTENT,
//					RelativeLayout.LayoutParams.WRAP_CONTENT);
//			rlp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
//			mRootLayout.addView(tv, rlp);
//		}
		setContentView(mRootLayout);
	}
}
