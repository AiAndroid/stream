package com.xiaomi.mibox.gamecenter.data.download.db;

import android.net.Uri;

public final class DataBaseColumns {
	/* 数据库 */
	public static final String AUTHORITY = "com.xiaomi.mibox.gamecenter.dbcache";
	
	public interface BaseColumns{
		public static final String _ID = "_id";
	}

	public static final class Download implements BaseColumns {
		
		public static final String TABLE = "download";
		public static final Uri URI_DOWNLOAD = 
				Uri.parse( "content://" + AUTHORITY + "/"+TABLE );
		/**
		 * String
		 */
		public static final String APP_ID = "app_id";

		/**
		 * long
		 */
		public static final String DOWNLOAD_ID = "download_id";

		/**
		 * String
		 */
		public static final String APK_HASH = "hash";
		
		public static final String STATUS = "status";
		
		public static final String TOTAL_SIZE_BYTES = "totalsizebytes";
		
		public static final String DOWNLOADED_BYTES = "downloadbytes";
		
		public static final String ERRCODE = "errcode";
		
		public static final String TIMESTAMP = "timestamp";
		//2013-7-16,加入要下载的包名/版本号，用于对比本地是否安装更新
		public static final String VERSIONCODE = "versioncode";
		public static final String PACKAGE = "package";
		//安装失败后的重试动作，0无动作 1删除后重新安装 2备份数据删除重新安装
		public static final String RETRY = "retry";
		//zwb s
		public static final String DATA_DOWNLOAD_ID = "data_download_id";
		//data_has_data:0表示无数据包，1表示有数据包
		public static final String DATA_HAS_DATA = "data_has_data";
		//zwb e
		//标志是否为增量升级包 0不是 1 是
		public static final String PATCHER = "patcher";
	}
	
	public static final class ReportQueue implements BaseColumns {
		public static final String TABLE = "report";
		
		public static final Uri URI_REPORT_QUEUE = 
				Uri.parse( "content://" + AUTHORITY + "/" + TABLE );
		
		public static final String PARAM = "param";//0已经安装 1可升级
		
	}
}
