package com.xiaomi.mibox.gamecenter.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.widget.GridView;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.ui.OnLoaderControl;

/**
 * Created by liuhuadong on 9/23/14.
 */
public class SmoothGridView extends GridView {
    public SmoothGridView(Context context) {
        this(context, null, 0);
        this.setFastScrollEnabled(true);
    }
    public SmoothGridView(Context context, AttributeSet attr) {
        this(context, attr, 0);
        this.setFastScrollEnabled(true);
    }
    public SmoothGridView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.setFastScrollEnabled(true);
    }

    private OnLoaderControl loaderControl;
    public void setLoaderControl(OnLoaderControl _loadControl){
        loaderControl = _loadControl;
    }
    int position = -1;
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_DPAD_DOWN){
            int currentPos = getSelectedItemPosition();
            if(currentPos+getNumColumns() < getAdapter().getCount()){
                currentPos += getNumColumns();
                smoothScrollToPosition(currentPos);
                position = currentPos;
                postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setSelection(position);
                    }
                }, 200);

                if(getAdapter().getCount() - currentPos <= 2*getNumColumns() && loaderControl != null){
                    loaderControl.nextPage();
                }
                return true;
            }
        }else if(keyCode == KeyEvent.KEYCODE_DPAD_UP){
            int currentPos = getSelectedItemPosition();
            if((currentPos - getNumColumns()) >= 0){
                currentPos -= getNumColumns();

                smoothScrollToPosition(currentPos);
                position = currentPos;
                postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setSelection(position);
                    }
                }, 200);

                return true;
            }
        }else if(keyCode == KeyEvent.KEYCODE_DPAD_RIGHT){
            int currentPos = getSelectedItemPosition();
            if((currentPos+1) % getNumColumns() ==0 && (currentPos + 1) < getAdapter().getCount()){
                currentPos++;

                smoothScrollToPosition(currentPos);
                position = currentPos;
                postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setSelection(position);
                    }
                }, 200);

                if(getAdapter().getCount() - currentPos <= 2*getNumColumns() && loaderControl != null){
                    loaderControl.nextPage();
                }
                return true;
            }
        }else if(keyCode == KeyEvent.KEYCODE_DPAD_LEFT){
            int currentPos = getSelectedItemPosition();
            if(currentPos % getNumColumns() ==0 && (currentPos - 1) >= 0){
                currentPos--;

                smoothScrollToPosition(currentPos);
                position = currentPos;
                postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setSelection(position);
                    }
                }, 200);


                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}
