package com.xiaomi.mibox.gamecenter.data.download;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class DownloadService extends Service {

	public DownloadService() {
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

}
