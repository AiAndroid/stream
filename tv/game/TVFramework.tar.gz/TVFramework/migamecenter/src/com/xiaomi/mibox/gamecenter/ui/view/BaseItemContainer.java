package com.xiaomi.mibox.gamecenter.ui.view;

import java.util.ArrayList;

import android.view.ViewGroup;
import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.R;
import android.content.Context;
import android.util.SparseArray;
import android.view.View;
import android.widget.LinearLayout;
/**
 * 基本控件容器 一行4个 
 * 是否有占位符
 * @author zhaotao
 */
public class BaseItemContainer extends LinearLayout{

	public static final int MAX_ROW_COUNT = 4;
	
	private SparseArray<BaseGridItem> mViewLists = new SparseArray<BaseGridItem>();
	
	private boolean hasPlaceHolder; //是否有占位符
	
	private View mPlaceHolder;
	private View mBottomPlaceholder;

    private static int item_default_width  = -1;
    private static int item_default_height = -1;
    private static int item_horizontal_space = -1;
	
	public BaseItemContainer(Context context, boolean placeHolder) {
		super(context);
		this.hasPlaceHolder = placeHolder;
		setOrientation(LinearLayout.VERTICAL);

        if(item_default_height == -1) {
            item_default_width  = getResources().getDimensionPixelSize(R.dimen.base_grid_item_width);
            item_default_height = getResources().getDimensionPixelSize(R.dimen.item_default_height);
            item_horizontal_space = getResources().getDimensionPixelSize(R.dimen.item_horizontal_space);
        }
	}
	
	public int update(ArrayList<GameItem> infos, int type){
		if(infos == null) return 0;
		if(infos.size() <= 0) return 0;
		
		LinearLayout.LayoutParams llp;
		
		//有些页面需要有顶部占位符 占位符默认高度统一为一个item高度
		if(hasPlaceHolder && null == mPlaceHolder){
			mPlaceHolder = new View(getContext());
			llp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, this.getResources().getDimensionPixelSize(R.dimen.container_place_holder_height));
			addView(mPlaceHolder, llp);
		}
		
		final int oldRowCount = mViewLists.size() / MAX_ROW_COUNT;//这个肯定整行添加的
		final int size = infos.size();
		int rowCount = (size % MAX_ROW_COUNT > 0) ? (size / MAX_ROW_COUNT + 1) : (size / MAX_ROW_COUNT);
		
		final int diffRowCount = rowCount - oldRowCount;
		if(diffRowCount > 0){//需要添加
			if(mBottomPlaceholder != null){
				this.removeView(mBottomPlaceholder);
			}
			LinearLayout[] row_layout = new LinearLayout[rowCount];
			llp = new LinearLayout.LayoutParams(-1,-2);
			for(int i = 0; i < diffRowCount; i++){
				row_layout[i] = new LinearLayout(getContext()); 
				addView(row_layout[i], llp);
			}
			addBottomPlaceHolder();
		}
		
		BaseGridItem item = null;
		final int totalCount = Math.max(size, mViewLists.size());
		for(int i = 0; i < totalCount; i++){
			item = mViewLists.get(i);
			if(null == item){
				item = new BaseGridItem(getContext());
				llp = new LinearLayout.LayoutParams(item_default_width,
						item_default_height);
				if(i % MAX_ROW_COUNT != 0){
					llp.setMargins(item_horizontal_space, 0, 0, 0);
				}else {
					llp.setMargins(0, 0, 0, 0);
				}
				if(hasPlaceHolder){
					((LinearLayout)this.getChildAt(1 + i / MAX_ROW_COUNT)).addView(item, llp);
				}else{
					((LinearLayout)this.getChildAt(i / MAX_ROW_COUNT)).addView(item, llp);
				}
				mViewLists.put(i, item);
			}
			if(i < size){
				item.setVisibility(View.VISIBLE);
				item.bind(infos.get(i), type);
			}else{
				item.setVisibility(View.INVISIBLE);
			}
			if(i == 0){
				item.setSelected(true);
			}else {
				item.setSelected(false);
			}
		}
		return totalCount;
	}
	
	public SparseArray<BaseGridItem> getViewList(){
		return mViewLists;
	}
	
	public void hidePlaceHolder(){
		mPlaceHolder.setVisibility(View.GONE);
	}
	
	public boolean placeHolderShow(){
		return mPlaceHolder.getVisibility() == View.VISIBLE;
	}
	
	private void addBottomPlaceHolder(){
		if(null == mBottomPlaceholder){
			mBottomPlaceholder = new View(getContext());
		}
		LinearLayout.LayoutParams llp;
		llp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, item_default_height);
		addView(mBottomPlaceholder, llp);
	}
}