package com.xiaomi.mibox.gamecenter.data.download;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import android.util.Log;
import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.Download;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationStatus;
import com.xiaomi.mibox.gamecenter.data.download.XMDownloadManager.Filter;
import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;
import com.xiaomi.mibox.gamecenter.utils.WLReflect;

import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.app.DownloadManager.Request;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import com.xiaomi.mitv.store.utils.Utils;

/**
 * 下载控制器
 * 
 * @author lihao
 * 
 */
final class DownloadController {

	private static final int EVENT_INIT_DOWNLOAD = 90000;
	private static final int EVENT_APPEND_DOWNLOAD = 90001;
	private static final int EVENT_RELOAD_DOWNLOAD = 90002;
	private static final int EVENT_DELETE_DOWNLOAD = 90003;
	private static final int EVENT_PAUSE_DOWNLOAD = 90004;
	private static final int EVENT_CONTINUE_DOWNLOAD = 90005;
	private static final int MAX_DOWNLOAD_COUNT = 2;

	// 操作管理器，用于不同Controller信息传递
	private XMDownloadManager mgr;

	// 系统的下载管理器
	private DownloadManager dm;
	private Context ctx;

	// 用于异步操作的环境
	private DownloadHandler handler = null;

	// 系统下载表的游标
	private Cursor downloadCursor = null;

	private long saveRev = 0;

	/**
	 * 下载管理器发生数据变化
	 */
	private ContentObserver mDownloadObserver = new ContentObserver(null) {
		@Override
		public void onChange(boolean selfChange) {
			if (handler.hasMessages(EVENT_RELOAD_DOWNLOAD)) {
				handler.removeMessages(EVENT_RELOAD_DOWNLOAD);
			}
			handler.sendEmptyMessage(EVENT_RELOAD_DOWNLOAD);
		}
	};

	public DownloadController(Context ctx, XMDownloadManager om) {
		mgr = om;
		this.ctx = ctx;
		HandlerThread thread = new HandlerThread("");
		thread.start();
		handler = new DownloadHandler(thread.getLooper());
		dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
		handler.sendEmptyMessage(EVENT_INIT_DOWNLOAD);
	}

	public OperationSession append_download(String gameId) {
		OperationSession session = mgr.getOperationSession(gameId);
        //for download fail, we need re-down again

		if (session != null) {
            if(session.getStatus() == OperationStatus.DownloadFail) {
                //remove from system download
                mgr.cancelDownloadTask(gameId);

                //replace the old one
                session = new OperationSession(mgr, ctx, gameId);
                mgr.putOperationSession(session);
                handler.sendMessage(handler.obtainMessage(EVENT_APPEND_DOWNLOAD, session));
            }
			return session;
		} else {
			session = new OperationSession(mgr, ctx, gameId);
			mgr.putOperationSession(session);
			handler.sendMessage(handler.obtainMessage(EVENT_APPEND_DOWNLOAD, session));
		}
		return session;
	}

	/**
	 * 暂停
	 * 
	 * @param gameId
	 */
	public void pause_download(String gameId) {
		OperationSession ops = mgr.getOperationSession(gameId);
		long[] downloadIds = new long[2];
		downloadIds[0] = ops.getDownloadId();
		if (ops.getDataDownloadId() > 0) {
			downloadIds[1] = ops.getDataDownloadId();
		}
		handler.sendMessage(handler.obtainMessage(EVENT_PAUSE_DOWNLOAD,
				downloadIds));
	}

	/**
	 * 继续
	 * 
	 * @param gameId
	 */
	public void continue_download(String gameId) {
		OperationSession ops = mgr.getOperationSession(gameId);
		long[] downloadIds = new long[2];
		downloadIds[0] = ops.getDownloadId();
		if (ops.getDataDownloadId() > 0) {
			downloadIds[1] = ops.getDataDownloadId();
		}
		handler.sendMessage(handler.obtainMessage(EVENT_CONTINUE_DOWNLOAD,
				downloadIds));
	}

	public void remove_download(String gameId) {
		handler.sendMessage(handler
				.obtainMessage(EVENT_DELETE_DOWNLOAD, gameId));

	}

	/**
	 * 从数据库中载入状态，并且同步DownloadManager和Download表的数据
	 */
	private void handle_init_from_db() {
		// 1.读出系统表所有数据
		Query query = new Query();
		query.setFilterByStatus(DownloadManager.STATUS_RUNNING
				| DownloadManager.STATUS_PENDING
				| DownloadManager.STATUS_PAUSED | DownloadManager.STATUS_FAILED
				| DownloadManager.STATUS_SUCCESSFUL);
		downloadCursor = dm.query(query);
		final List<DownloadTablePojo> sys_data = load_from_system(downloadCursor);
		HashMap<String, DownloadTablePojo> sys_cache = new HashMap<String, DownloadTablePojo>();
		for (DownloadTablePojo dp : sys_data) {
			sys_cache.put(dp.downloadId, dp);
		}

		// 2.读出本地数据，根据系统数据状态更新本地状态
		final OperationSession[] local_data = mgr
				.getOperationSessionByStatus(null);
		DownloadTablePojo pojo = null;
		DownloadTablePojo pojo_data = null;
		for (OperationSession ops : local_data) {
			if (ops.getStatus().ordinal() > OperationStatus.DownloadFail.ordinal()
					|| ops.getStatus().ordinal() <= OperationStatus.DownloadQueue.ordinal()) {
				// 处于等待下载队列的数据略过
				continue;
			}
			// 处于下载状态的数据 Downloading, DownloadPause, DownloadSuccess
			pojo = sys_cache.get(String.valueOf(ops.getDownloadId()));
			// zwb s
			pojo_data = null;
			if (ops.isHasData()) {// true表示有数据包
				if (ops.getDataDownloadId() == -1) {
					continue;
				}
				pojo_data = sys_cache.get(String.valueOf(ops
						.getDataDownloadId()));
			}
			// zwb e
			if (pojo == null
					|| (pojo != null && pojo_data == null && ops.isHasData()))// zwb
			{
				// 本地有的数据没有在系统表中发现，从数据表中删除
				// mgr.removeOperationSession(ops.getGameId());
				// ctx.getContentResolver().delete(Download.URI_DOWNLOAD,
				// "download_id=?", new
				// String[]{String.valueOf(ops.getDownloadId())});
				handle_remove_download(ops.getGameId());
				continue;
			}
			// 更新数据状态
			// zwb
			if (null != pojo) {// 无数据包的情况
				// zwb s 在handle_init_from_db里也需要修改
				if (null != pojo_data) {// 有数据包的情况

					if (pojo_data.status.ordinal() == OperationStatus.DownloadFail.ordinal()
							|| pojo.status.ordinal() == OperationStatus.DownloadFail.ordinal()) {
						pojo.status = OperationStatus.DownloadFail;
					} else if (pojo_data.status.ordinal() == OperationStatus.Downloading.ordinal()
							|| pojo.status.ordinal() == OperationStatus.Downloading.ordinal()) {
						pojo.status = OperationStatus.Downloading;
					} else if (pojo_data.status.ordinal() == OperationStatus.DownloadPause.ordinal()
							|| pojo.status.ordinal() == OperationStatus.DownloadPause.ordinal()) {
						pojo.status = OperationStatus.DownloadPause;
					} else if (pojo_data.status.ordinal() == OperationStatus.DownloadSuccess.ordinal()
							|| pojo.status.ordinal() == OperationStatus.DownloadSuccess.ordinal()) {
						pojo.status = OperationStatus.DownloadSuccess;
					}

					// 计算下载多少
					if (pojo.recv >= 0 && pojo_data.recv >= 0 && pojo.total > 0
							&& pojo_data.total > 0) {

						pojo.recv = pojo.recv + pojo_data.recv;
						pojo.total = pojo.total + pojo_data.total;
					}

				}
				ops.update_download_status(ctx, pojo.reason, pojo.recv,
						pojo.total, pojo.status, pojo.downloadId);
			}
			// zwb e
			if (pojo.status == OperationStatus.DownloadSuccess) {
				mgr.DownloadFinish(ops);
				continue;
			}
		}
		sys_data.clear();
		sys_cache.clear();
		sys_cache = null;
		// 3.初始化完毕，注册变化监听器
		downloadCursor.registerContentObserver(mDownloadObserver);
		// 4.检查有是否可以放入DownloadManager中的下载
		handle_next_download();
	}

	/**
	 * 处理变化
	 */
	private void handle_reload_system() {
		// 1.读取系统记录并缓存
		final List<DownloadTablePojo> ret = load_from_system(downloadCursor);
		// if(ret.size() == 0) ///这里逻辑有问题 去掉return
		// {
		// return ;
		// }
		HashMap<String, DownloadTablePojo> sys_cache = new HashMap<String, DownloadTablePojo>();
		for (DownloadTablePojo pojo : ret) {
			sys_cache.put(pojo.downloadId, pojo);
		}
		// 2.读取本地的记录
		final OperationSession[] local = mgr
				.getOperationSessionByFilter(new Filter() {
					@Override
					public boolean onFilter(OperationSession ops) {
						// 在安装队列且没进行安装过程的条目
						return ops.getStatus().ordinal() > OperationStatus.DownloadQueue
								.ordinal()
								&& ops.getStatus().ordinal() <= OperationStatus.InstallQueue
										.ordinal();
					}
				});

		// 3.读取并更新记录
		DownloadTablePojo pojo = null;
		// zwb s
		DownloadTablePojo pojo_data = null;
		// zwb e
		for (OperationSession ops : local) {
			if (ops.getDownloadId() == -1) {
				continue;
			}
			// Apk
			pojo = sys_cache.get(String.valueOf(ops.getDownloadId()));
			pojo_data = null;
			// Zip
			if (ops.isHasData()) {// true表示有数据包
				if (ops.getDataDownloadId() == -1) {
					continue;
				}
				pojo_data = sys_cache.get(String.valueOf(ops
						.getDataDownloadId()));
			}

			if (pojo == null
					|| (pojo != null && pojo_data == null && ops.isHasData())) {
				// 系统中删除了某个正在运行的下载任务
				handle_remove_download(ops.getGameId());
				continue;
			}

			long recv = pojo.recv;
			long total = pojo.total;

			if (null != pojo) {// 无数据包的情况
				// zwb s 在handle_init_from_db里也需要修改
				if (null != pojo_data) {// 有数据包的情况

					if (pojo_data.status.ordinal() == OperationStatus.DownloadFail
							.ordinal()
							|| pojo.status.ordinal() == OperationStatus.DownloadFail
									.ordinal()) {
						pojo.status = OperationStatus.DownloadFail;
					} else if (pojo_data.status.ordinal() == OperationStatus.Downloading
							.ordinal()
							|| pojo.status.ordinal() == OperationStatus.Downloading
									.ordinal()) {
						pojo.status = OperationStatus.Downloading;
					} else if (pojo_data.status.ordinal() == OperationStatus.DownloadPause
							.ordinal()
							|| pojo.status.ordinal() == OperationStatus.DownloadPause
									.ordinal()) {
						pojo.status = OperationStatus.DownloadPause;
					} else if (pojo_data.status.ordinal() == OperationStatus.DownloadSuccess
							.ordinal()
							|| pojo.status.ordinal() == OperationStatus.DownloadSuccess
									.ordinal()) {
						if (ops.getStatus().ordinal() == OperationStatus.InstallQueue
								.ordinal()) {
							pojo.status = OperationStatus.InstallQueue;
						} else {
							pojo.status = OperationStatus.DownloadSuccess;
						}
					}

					// 计算下载多少

					if (pojo.recv >= 0 && pojo_data.recv >= 0 && pojo.total > 0
							&& pojo_data.total > 0) {
						// pojo.recv有时会发出为零的错误数据，造成下载进度错误。

						if (pojo.recv <= 0) {
							pojo.recv = saveRev + pojo_data.recv;
						} else {
							saveRev = pojo.recv;
							pojo.recv = pojo.recv + pojo_data.recv;
						}

						pojo.total = pojo.total + pojo_data.total;
					}
				}
				// zwb e
				ops.update_download_status(ctx, pojo.reason, pojo.recv,
						pojo.total, pojo.status, pojo.downloadId);

				if (null != pojo_data) {
					if (recv > 0 && (recv == total)) {
						ops.update_download_status(ctx, pojo_data.reason,
								pojo.recv, pojo.total, pojo_data.status,
								pojo.downloadId);
					}
				}

			}

			if (ops.getStatus() == OperationStatus.DownloadSuccess) {
				mgr.DownloadFinish(ops);
			}
		}
		ret.clear();
		sys_cache.clear();
		handle_next_download();
	}

	/**
	 * 检查当前队列是否可以加入新的下载到系统下载列表
	 */
	private void handle_next_download() {
		int dc = 0;
		OperationSession[] cl = mgr
				.getOperationSessionByStatus(new OperationStatus[] {
						OperationStatus.Downloading,
						OperationStatus.DownloadPause });
		dc = cl.length;
		if (dc >= MAX_DOWNLOAD_COUNT) {
			return;
		}
		cl = mgr.getOperationSessionByStatus(new OperationStatus[] { OperationStatus.DownloadQueue });
		// 排序
		ArrayList<OperationSession> ary = new ArrayList<OperationSession>(
				cl.length);
		for (OperationSession ops : cl) {
			if (-1 != ops.getOrderId()) {
				ary.add(ops);
			}

		}
		Collections.sort(ary, new Comparator<OperationSession>() {

			@Override
			public int compare(OperationSession lhs, OperationSession rhs) {
				return lhs.getOrderId() - rhs.getOrderId();
			}

		});
		cl = null;

		for (OperationSession ops : ary) {
			// zwb s
			GameItem gi = Utils.getGameItem(ctx, ops.getGameId());
			if (gi == null) {
				continue;
			}
			String displayName = gi.name;
			// 1. Apk url:
			// 51900之后版本需要拼接cdn 和 apkurl zt 1009
			//String cdn = gi.cdn;
			String apkPath = gi.apk.url;
			// 有增量升级包时使用增量升级包地址
			if (!TextUtils.isEmpty(gi.patch_url)) {
				apkPath = gi.patch_url;
			}

			String uriString = apkPath;//CdnDomainUrl.getCdnDomainUrl(cdn, resType, null,	null, apkPath);

			long did = -1;// -1表示下载过或下载到一半，删除重新下载
			if (uriString != null) {
				uriString = uriString.trim();
			}
			did = downloadInternal(ops.getGameId(), uriString, displayName);
			if (did == -1) {
				// TODO 添加失败了怎么办？
				break;
			}

			// 2. Zip url:

            long data_did = -1;
            if(gi.assets != null && gi.assets.size() > 0) {
                String uriDataString = gi.assets.get(0).url;//CdnDomainUrl.getCdnDomainUrl(cdn, resType,	null, null, gi.getDataUrl());

                if (uriDataString != null && !"".equals(uriDataString)) {
                    ops.setHasData(true);
                    uriDataString = uriDataString.trim();
                    // 名字后添加"_数据包"
                    data_did = downloadInternal(ops.getGameId(), uriDataString,
                            displayName + ctx.getString(R.string.data_package));
                    if (data_did == -1) {
                        // TODO 添加失败了怎么办？
                        break;
                    }
                }
            }
			// zwb e

			// 设置新属性
			ops.setDownloadId(did);
			// zwb s
			ops.setDataDownloadId(data_did);
			// zwb e
			ops.setStatus(OperationStatus.Downloading);
			// 更新到数据库
			ops.update(ctx);
			dc++;
			if (dc >= MAX_DOWNLOAD_COUNT) {
				break;
			}
		}
		ary.clear();
		ary = null;
	}

	private void handle_pause_download(long[] ids) {
		if (ids != null && ids.length > 0) {
			OperationSession[] cl = mgr
					.getOperationSessionByStatus(new OperationStatus[] { OperationStatus.Downloading });
			for (OperationSession ops : cl) {
				if (ops.getDownloadId() == ids[0]) {
					ops.update(ctx);
				}
			}
			WLReflect.pauseDownload(dm, ids);
		}
	}

	private void handle_resume_download(long[] ids) {
		long currentDownloadId = 0;
		if (ids != null && ids.length > 0) {
			OperationSession[] cl = mgr
					.getOperationSessionByStatus(new OperationStatus[] { OperationStatus.DownloadPause });
			for (OperationSession ops : cl) {
				if (ops.getDownloadId() == ids[0]) {
					ops.update(ctx);
					currentDownloadId = ops.getDownloadId();

				}

				if (ops.getDataDownloadId() > 0) {
					// 1.读取系统记录并缓存
					final List<DownloadTablePojo> ret = load_from_system(downloadCursor);
					HashMap<String, DownloadTablePojo> sys_cache = new HashMap<String, DownloadTablePojo>();
					for (DownloadTablePojo pojo : ret) {
						sys_cache.put(pojo.downloadId, pojo);
					}
					

					DownloadTablePojo pojo = null;
					DownloadTablePojo pojo_data = null;
					
					pojo = sys_cache.get(String.valueOf(ops.getDownloadId()));
					pojo_data = sys_cache.get(String.valueOf(ops
								.getDataDownloadId()));
					
					long recv = pojo.recv;
					long total = pojo.total;
					
					if (null != pojo_data) {
						if (recv > 0 && (recv == total)) {
							currentDownloadId = ops.getDataDownloadId();
						}
					}
				
				}


//				if (ops.getReason() == XMDownloadManager.REASON_DOWNLOAD_PAUSED_QUEUED_FOR_WIFI) {
//					try {
//						Intent intent = new Intent(Intent.ACTION_VIEW);
//
//						intent.setData(ContentUris.withAppendedId(
//								Downloads.Impl.ALL_DOWNLOADS_CONTENT_URI,
//								currentDownloadId));
//
//						intent.setClassName("com.android.providers.downloads",
//								"com.android.providers.downloads.SizeLimitActivity");
//						intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//						ctx.startActivity(intent);
//					}
//
//					catch (Exception e) {
//						e.printStackTrace();
//					}
//
//				}

			}
			WLReflect.resumeDownload(dm, ids);
		}
	}

	/**
	 * 添加任务
	 * 
	 * @param ops
	 */
	private void handle_append_download(OperationSession ops) {
		ops.insert(ctx);
		handle_next_download();
	}

	/**
	 * 移除任务
	 * 
	 * @param gameId
	 */
	private void handle_remove_download(String gameId) {
		OperationSession ret = mgr.getOperationSession(gameId);
		if (null == ret) {
			return;
		}
		if (ret.getStatus() == OperationStatus.Downloading) {
			ret.setReason(XMDownloadManager.REASON_DOWNLOAD_PAUSED_MANUAL_WHEN_DOWNLOADING);
		} else if (ret.getStatus().ordinal() < OperationStatus.DownloadSuccess
				.ordinal()) {
			ret.setReason(XMDownloadManager.REASON_DOWNLOAD_PAUSED_MANUAL_WHEN_WAITING);
		}

		mgr.removeOperationSession(gameId);
		ctx.getContentResolver().delete(Download.URI_DOWNLOAD, "app_id=?",
				new String[] { String.valueOf(ret.getGameId()) });
		if (ret.getDownloadId() > -1) {
			dm.remove(ret.getDownloadId());
		}
		// zwb s
		if (ret.getDataDownloadId() > -1) {
			dm.remove(ret.getDataDownloadId());
		}
		// zwb e
	}

	private long downloadInternal(String gameId, String uriString,
			String displayName) {
		Uri uri = Uri.parse(uriString);

		Request request = null;
		long downloadId = -1;
		StringBuilder sb = null;
		try {
			request = new Request(uri);
			sb = new StringBuilder(128);
			sb.append(GamecenterUtils.getMD5(uriString));
			sb.append(GamecenterUtils.MD5_SPILT_GAME_ID);// _ 这个字符不在 hexDigits 中
			sb.append(gameId);
			// 如果SD卡可写，直接放到SD卡上 这样就不用删除了
			if (Environment.getExternalStorageDirectory().canWrite()) {
				GamecenterUtils.makesureDownloadsDirExist();
				request.setDestinationInExternalPublicDir(
						Environment.DIRECTORY_DOWNLOADS, sb.toString());
			}
			request.setMimeType(GamecenterUtils.GAME_MIME_TYPE);
			// zwb request.setTitle(gi.getDisplayName());
			request.setTitle(displayName);
			request.setDescription(ctx.getResources().getString(
					R.string.from_gamecenter_download));
			downloadId = dm.enqueue(request);
		} catch (Exception e) {
			Log.e("", "", e);
		}

		if (-1 == downloadId) {// 失败的时候尝试删除下载的文件
			if (GamecenterUtils.deleteExistDownloadPartialFiles(sb.toString())) {
				try {
					downloadId = dm.enqueue(request);
				} catch (Exception e) {
					Log.e("", "", e);
				}
			}
		}
		sb = null;
		return downloadId;
	}

	// zwb s
	/**
	 * 从数据库读取下载路径 method name: private String getZipName(OperationSession ops)
	 * 
	 * @return
	 */
	/**
	 * 从系统表中载入下载数据
	 * 
	 * @return
	 */
	private List<DownloadTablePojo> load_from_system(Cursor sor) {
		ArrayList<DownloadTablePojo> ret = new ArrayList<DownloadTablePojo>();
		if (null == sor) {
			return ret;
		}
		sor.requery();
		if (!sor.moveToFirst()) {
			return ret;
		}

		do {
			DownloadTablePojo dp = new DownloadTablePojo(sor);
			ret.add(dp);
		} while (sor.moveToNext());
		return ret;
	}

	class DownloadHandler extends Handler {
		public DownloadHandler(Looper looper) {
			super(looper);
		}

		@Override
		public void handleMessage(Message msg) {
			if (EVENT_INIT_DOWNLOAD == msg.what) {
				handle_init_from_db();
			} else if (EVENT_APPEND_DOWNLOAD == msg.what) {
				handle_append_download((OperationSession) msg.obj);
			} else if (EVENT_RELOAD_DOWNLOAD == msg.what) {
				handle_reload_system();
			} else if (EVENT_DELETE_DOWNLOAD == msg.what) {
				handle_remove_download((String) msg.obj);
			} else if (EVENT_PAUSE_DOWNLOAD == msg.what) {
				handle_pause_download((long[]) msg.obj);
			} else if (EVENT_CONTINUE_DOWNLOAD == msg.what) {
				handle_resume_download((long[]) msg.obj);
			}
		}
	}

}
