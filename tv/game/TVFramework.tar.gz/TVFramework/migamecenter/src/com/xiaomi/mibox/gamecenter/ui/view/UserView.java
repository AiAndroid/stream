package com.xiaomi.mibox.gamecenter.ui.view;

import android.accounts.Account;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.View;
import com.xiaomi.mibox.gamecenter.data.MainHandler;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.account.*;
import com.xiaomi.mibox.gamecenter.data.ConfigTools;
import com.xiaomi.mibox.gamecenter.data.statics.Report;
import com.xiaomi.mibox.gamecenter.data.statics.ReportManager;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.xmsf.account.data.XiaomiUserInfo;

/**
 * Created by liuhuadong on 7/31/14.
 *
 */
public class UserView extends MineView implements IQueryUserInfo, IQueryBalance{

    final String MIBI_BALANCE = "mibi_balance";
    public UserView(Context context) {
        super(context);

        _activity = (Activity)(context);

        initUI();
    }

    private String         mXiaomiId;
    private XiaomiUserInfo mUserInfo;
    private Activity       _activity;

    public Activity getActivity(){
        return _activity;
    }       
    
    @Override
    protected void onFinishInflate() {        
        super.onFinishInflate();

        initUI();
    }

    private void initUI(){
        setBackgroundResource(R.drawable.mine_account);
        setAccountPhoto(R.drawable.account_photo_normal);
        setFocusable(true);
        this.onCreateView(_activity);

        requestLayout();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        
        if(visibility == View.VISIBLE){
            this.onResume();
        }       
    }
    
    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        
        this.onStop();
        this.onDestroy();
    }
    
    @Override
    public void onCreateView(Activity activity){
        _activity = activity;
        registReceiver();
        refreshLoginStatus();

        this.setOnClickListener(click);
    }

    OnClickListener click = new OnClickListener(){
        @Override
        public void onClick(View view) {
            if(mUserInfo != null){
                Account[] accounts = AccountUtils.getXiaomiAccount(getContext());
                if(accounts != null && accounts.length > 0){
                    AccountUtils.open_mibi(_activity,
                            accounts[0]);

                    ReportManager.getInstance().send(
                            Report.createReport(Report.ReportType.STATISTICS, null, null),
                            Report.MAIN_ACTION, "account");
                }else{
                    //fail
                }
            }else{
                LoginManager.getLoginManager().registXiaoMiAccount(getActivity());

                ReportManager.getInstance().send(
                        Report.createReport(Report.ReportType.STATISTICS, null, null),
                        Report.MAIN_ACTION, "account_login");
            }
        }
    };

    private void refreshLoginStatus(){
        LoginManager manager = LoginManager.getLoginManager();
        if (null != manager) {
            if (manager.isGameCenterLogin()) {
                Account[] account = AccountUtils
                        .getXiaomiAccount(this.getContext());
                if (account != null && account.length > 0) {
                    mXiaomiId = account[0].name;
                }
                if (!TextUtils.isEmpty(mXiaomiId)) {
                    XiaomiUserInfo userInfo = UserInfoUtils
                            .getXiaomiUserInfo(getContext());
                    // 与缓存一致才读取，否则作废
                    if (null == userInfo
                            || !(mXiaomiId.equals(userInfo.getUserId()))) {
                        UserInfoUtils.reset(getContext());
                        mUserInfo = new XiaomiUserInfo(mXiaomiId);
                    } else {
                        mUserInfo = userInfo;
                    }
                }
            }
            updateLoginStatus(manager.isGameCenterLogin());
        }
    }
    private LocalBroadcastManager bm;

    private void updateLoginStatus(boolean hasLogin) {
        if (hasLogin) {
            bindUserInfo();
            bindMibi(ConfigTools.getInstance().getLong(MIBI_BALANCE, 0L));
            AccountUtils.query_balance(getActivity(), this);
            LoginManager.getLoginManager().addQueryInfoListeners(getActivity(),
                    this);
        }else{//未登录状态的显示
            setAccountPhoto(R.drawable.account_photo_normal);
            setItemTitle(R.string.mine_info_account_title);
            setItemSummary(R.string.mine_info_account_summary_none);
        }
    }

    private void bindUserInfo(){
        if(null == getActivity()){
            return;
        }
        if(mUserInfo != null){
            if(!TextUtils.isEmpty(mUserInfo.getNickName())){
                setItemTitle(mUserInfo.getNickName());
            }else{
                setItemTitle(mUserInfo.getUserId());
            }
            bindAccountPhoto(
                    mUserInfo.getAvatarAddress());
        }else{
            setItemTitle(mXiaomiId);
        }
    }

    @Override
    public void onResume(){
        LoginManager loginManager = LoginManager.getLoginManager();
        if(loginManager.isGameCenterLogin()){
            AccountUtils.query_balance(getActivity(), this);
        }
    }
    private void registReceiver() {
        IntentFilter iif = new IntentFilter();
        iif.addAction(Constants.INTENT_ACTION_GAMECENTER_LOGIN);
        iif.addAction(Constants.INTENT_ACTION_XIAOMI_ACCOUNT_LOGOUT);
        if (null == bm) {
            bm = LocalBroadcastManager.getInstance(this.getContext());
        }
        bm.registerReceiver(broadcastReceiver, iif);
    }

    @Override
    public void onStop(){
        unRegistReceiver();
    }

    private void unRegistReceiver() {
        if (null == bm) {
            return;
        }
        bm.unregisterReceiver(broadcastReceiver);
    }

    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (null == intent) {
                return;
            }
            if (null == getContext()) {
                return;
            }          

            String action = intent.getAction();
            if (TextUtils.equals(Constants.INTENT_ACTION_GAMECENTER_LOGIN,
                    action)) {
                // 登录小米帐号
                updateLoginStatus(true);
            } else if (TextUtils.equals(
                    Constants.INTENT_ACTION_XIAOMI_ACCOUNT_LOGOUT, action)) {
                // 删除系统里的小米帐号
                mUserInfo = null;
                UserInfoUtils.reset(getContext());
                updateLoginStatus(false);
            }
        }
    };

    @Override
    public void onFinish(int code, XiaomiUserInfo userInfo) {
        if(IQueryUserInfo.QUERY_USER_INFO_SUCCESS == code){
            mUserInfo = userInfo;
            UserInfoUtils.saveXiaomiUserInfo(this.getContext(), mUserInfo);
            MainHandler.getInstance().post(new Runnable() {
                @Override
                public void run() {
                    bindUserInfo();
                }
            });
        }else{

        }
    }

    @Override
    public void onFinish(int code, long balance) {
        final long miBalance;
        if(IQueryBalance.QUERY_CODE_SUCCESS == code){
            miBalance = balance;
        }else{
            miBalance = ConfigTools.getInstance().getLong(MIBI_BALANCE, 0L);
        }
        MainHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                bindMibi(miBalance);
            }
        });
    }

    private void bindMibi(long balance){
        String txt = this.getResources().getString(R.string.mine_info_account_summary_format,
                balance * 1.0f / 100);
        setItemSummary(txt);
    }
}
