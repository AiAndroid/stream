package com.xiaomi.mibox.gamecenter.ui.view;

import java.lang.ref.WeakReference;

import android.util.AttributeSet;
import com.tv.ui.metro.view.ImageChangedListener;
import com.xiaomi.mibox.gamecenter.data.MainHandler;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.utils.ImageUtils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Bitmap.Config;
import android.graphics.PorterDuff.Mode;
import android.graphics.Shader.TileMode;
import android.view.View;
import android.widget.ImageView;


/**
 * 投影，
 * @author zhaotao
 *
 */
public class MirrorView extends ImageView implements ImageChangedListener {

	private Bitmap mOriginalImage;
	
	private int mShadowHeight;
	String mTag;
	private Object mSyncObject = new Object();
	private boolean mNeedRelease = true;
	
	//要求原图的大小
	private int mRequestWidth;
	private int mRequestHeight;
	
	private WeakReference<View> mReflectMirrorView;
	private int mRetry = 0;
	
	public MirrorView(Context context) {
		this(context, null, 0);
	}

    public MirrorView(Context context, AttributeSet as) {
        this(context, as, 0);
    }

	public MirrorView(Context context, AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);
        mShadowHeight = getResources().getDimensionPixelSize(R.dimen.MIRROR_HEIGHTER);
    }

    public void setmShadowHeight(int height){
        mShadowHeight = height;
    }
	
	public int mirrorHeight(){
		return mShadowHeight;
	}
	
	/**
	 * 设定要求原图大小的宽度与高度,一般用于图片需要放缩的地方
	 * @param requestWidth
	 * @param requestHeight
	 */
	public void setRequestSize(int requestWidth, int requestHeight){
		mRequestWidth = requestWidth;
		mRequestHeight = requestHeight;
	}
	
	public void setMirrorTag(String tag){
		mTag = tag;
	}
	
	public void setBitmapView(View v){
		synchronized (mSyncObject) {
			mReflectMirrorView = new WeakReference<View>(v);
			if(mNeedRelease
					&& mOriginalImage != null 
					&& !mOriginalImage.isRecycled()){
				mOriginalImage.recycle();
			}
			mNeedRelease = true;
			mOriginalImage = ImageUtils.getViewBitmap(v);
			if(mOriginalImage != null){
				invalidate();
			}
		}
	}
	
	/**
	 * 更新倒影
	 */
	public void updateBitmapView(){
		if(mReflectMirrorView != null 
				&& mReflectMirrorView.get() != null){
			synchronized (mSyncObject) {
				if(mNeedRelease
						&& mOriginalImage != null 
						&& !mOriginalImage.isRecycled()){
					mOriginalImage.recycle();
				}
				mNeedRelease = true;
				mOriginalImage = ImageUtils.getViewBitmap(
						mReflectMirrorView.get());
//				if(IConfig.DEBUG) Log.e("", "retry draw");
				if(mOriginalImage != null){
//					if(IConfig.DEBUG) Log.e("", "draw");
					invalidate();
				}else{
					mRetry++;
					if(mRetry < 2){
						MainHandler.getInstance().postDelayed(new Runnable() {
							@Override
							public void run() {
								updateBitmapView();
							}
						}, 2000+mRetry*1000);
					}
				}
			}
		}
	}
	
	public void setBitmapImageView(ImageView v){
		synchronized (mSyncObject) {
			if(mNeedRelease
					&& mOriginalImage != null 
					&& !mOriginalImage.isRecycled()){
				mOriginalImage.recycle();
			}
			
			mNeedRelease = false;
			if(mRequestWidth != 0 && mRequestHeight != 0){
				mOriginalImage = ImageUtils.getViewBitmap(v, mRequestWidth, mRequestHeight);
			}else{
				mOriginalImage = ImageUtils.getViewBitmap(v);
			}
			invalidate();
		}
	}
	
	public void setBitmapImageView(View v){
		synchronized (mSyncObject) {
			if(mNeedRelease
					&& mOriginalImage != null 
					&& !mOriginalImage.isRecycled()){
				mOriginalImage.recycle();
			}
			
			mNeedRelease = false;
			if(mRequestWidth != 0 && mRequestHeight != 0){
				mOriginalImage = ImageUtils.getDrawableBitmap(v.getBackground(), 
						mRequestWidth, mRequestHeight);
			}else{
				mOriginalImage = ImageUtils.getBitmap(v.getBackground());
			}
			invalidate();
		}
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		int nX = 0;
		int nY = 0;
		canvas.save(Canvas.MATRIX_SAVE_FLAG);
		canvas.translate(nX, nY);
		if(mOriginalImage != null && !mOriginalImage.isRecycled()){
			try{
				canvas.drawBitmap(createReflectedImage(
						mOriginalImage), nX, nY, null);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		canvas.restore();
	}

	public void release(){
		if(mNeedRelease)
		if(mOriginalImage != null && !mOriginalImage.isRecycled()){
			mOriginalImage.recycle();
		}
	}
	
	/**
	 * 
	 * @param originalImage
	 * @return
	 */
	private Bitmap createReflectedImage(Bitmap originalImage) {  
  
        int width = originalImage.getWidth();
        int height = originalImage.getHeight();
        
        if(width <= 0 || height <= 0)return null;
  
        Matrix matrix = new Matrix();
        matrix.preScale(1, -1);
  
//        Bitmap blurBitmap = ImageUtils.fastblur(originalImage, 15);
        Bitmap reflectionImage = Bitmap.createBitmap(originalImage, 0, 
                height - mShadowHeight, width, mShadowHeight, matrix, false); 
  
        Bitmap bitmapWithReflection = Bitmap.createBitmap(width,
        		mShadowHeight, Config.ARGB_8888);
  
        Canvas canvas = new Canvas(bitmapWithReflection);
        Paint defaultPaint = new Paint();
        defaultPaint.setColor(0x00000000);//透明背景
//        canvas.drawRect(0, 0, width,  mShadowHeight, defaultPaint);
        final float roundRadius = 15;
        final RectF rectF = new RectF(0, 0, width,  mShadowHeight);
        canvas.drawRoundRect(rectF, roundRadius, roundRadius, defaultPaint);
        canvas.drawBitmap(reflectionImage, 0, 0, null);
        reflectionImage.recycle();
  
        Paint paint = new Paint();
        LinearGradient shader = new LinearGradient(0,
                0, 0, bitmapWithReflection.getHeight() -20 ,
                new int[]{0x80358ce5, 0x00010101}, null,TileMode.CLAMP);
        // 0x70358ce5 偏蓝色
        paint.setShader(shader);
        paint.setXfermode(new PorterDuffXfermode(Mode.DST_IN));
        canvas.drawRect(0, 0, width, bitmapWithReflection.getHeight(), paint);
        return bitmapWithReflection;
    }

	@Override
	public void onImageChanged(ImageView view) {
//		if(IConfig.DEBUG) Log.e("", "image changed");
		MainHandler.getInstance().postDelayed(new Runnable() {
			@Override
			public void run() {
				updateBitmapView();
			}
		}, 3000);
	}  
}
