package com.xiaomi.mibox.gamecenter.data.io;

import java.io.IOException;
import java.io.OutputStream;

abstract class ResetableOutputStream extends OutputStream {
    protected OutputStream mOutputStream;

    public ResetableOutputStream(OutputStream outputStream) {
        if (outputStream == null) {
            throw new IllegalArgumentException("outputstream is null");
        }
        mOutputStream = outputStream;
    }

    @Override
    public void close() throws IOException {
        mOutputStream.close();
    }

    @Override
    public void flush() throws IOException {
        mOutputStream.flush();
    }

    @Override
    public void write(byte[] buffer) throws IOException {
        mOutputStream.write(buffer);
    }

    @Override
    public void write(byte[] buffer, int offset, int count) throws IOException {
        mOutputStream.write(buffer, offset, count);
    }

    @Override
    public void write(int oneByte) throws IOException {
        mOutputStream.write(oneByte);
    }

    public abstract void reset();
}
