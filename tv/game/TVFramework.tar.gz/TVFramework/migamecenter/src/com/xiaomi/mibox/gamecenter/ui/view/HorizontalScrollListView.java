package com.xiaomi.mibox.gamecenter.ui.view;

import android.util.AttributeSet;
import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.Animator.AnimatorListener;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnKeyListener;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * 
 * @author liubiqiang
 *
 */
public abstract class HorizontalScrollListView extends HorizontalScrollView 
    implements OnFocusChangeListener, OnKeyListener {

    protected LinearLayout mContainer;
    private ImageView mFocusedView;
    
    protected SparseArray<View> mViewLists = new SparseArray<View>(4);
    private View mCurrentSelectedView;
    
    protected int mCurrPos = 0;
    private boolean mScaleAnimationFinish = true;
    private int[] mLocation = new int[2];
    private int[] mParentLayoutLocation = new int[2];
    private int mScrollRange = -1;//最大可滚动的距离
    private int mCurrScrollPos;//当前滚动的位置
    
    private View mRightSpaceView;
    
    protected int mItemCount = DEFAULT_SCREEN_SHOT_NUM;
    
    private Rect mVisibleRect = new Rect();
    private int mAdjustY = 0;
    public static final int DEFAULT_SCREEN_SHOT_NUM = 4;
    
    public interface OnHorizontalScrollClickListener {
        public void onClick(Object data, int pos);
    }
    protected OnHorizontalScrollClickListener mOnClickListener;
    
    public HorizontalScrollListView(Context context, AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);
        init(context);
    }

    public HorizontalScrollListView(Context context) {
        this(context, null, 0);
    }

    public HorizontalScrollListView(Context context, AttributeSet as) {
        this(context, as, 0);
    }
    
    public void setOnHorizontalScrollClickListener(OnHorizontalScrollClickListener l){
        mOnClickListener = l;
    }
    
    protected abstract void onClick();
    
    public void setFocusedView(ImageView focusedView){
        mFocusedView = focusedView;
    }
    
    /**
     * 

     * @param distance
     */
    private void setCurrentView(View currentSelectedView, int distance){
        if(null == currentSelectedView
                || null == mFocusedView){
            return;
        }
        
        mScaleAnimationFinish = false;
        int moveDistance = 0;
        if(mScrollRange < 0){
            moveDistance = 0;
            if(mCurrScrollPos > 0){
                moveDistance = -mCurrScrollPos;
                mCurrScrollPos = 0;
            }
        }else{
            moveDistance = distance;
            if (distance != 0) {
                if (mCurrScrollPos + distance < 0) {
                    moveDistance = -mCurrScrollPos;
                } else if (mCurrScrollPos + distance > mScrollRange) {
                    moveDistance = mScrollRange - mCurrScrollPos;
                }
            }
            mCurrScrollPos += moveDistance;
            if (IConfig.DEBUG) {
                Log.e(TAG(), "after mMoveDistance=" + moveDistance);
                Log.e(TAG(), "after mCurrScrollPos=" + mCurrScrollPos);
            }
        }
        
        if (null == mLocation) {
            mLocation = new int[2];
        }
        currentSelectedView.getLocationInWindow(mLocation);

        if (null == mParentLayoutLocation) {
            mParentLayoutLocation = new int[2];
        }
        this.getLocationInWindow(mParentLayoutLocation);
        
        int x = mLocation[0] - mParentLayoutLocation[0] + diffX();
        int y = mLocation[1] + diffY() + mAdjustY;
        
        if(IConfig.DEBUG){
            Log.e(TAG(), "x=" + x);
            Log.e(TAG(), "y=" + y);
        }
        
        if (null == mCurrentSelectedView) {// 首次不执行动画效果
            if(mFocusedView != null){
                mFocusedView.setX(x - moveDistance - itemFocusXDiff());
                mFocusedView.setY(y - itemFocusYDiff());
            }
            if (moveDistance != 0) {
                this.smoothScrollBy(moveDistance, 0);
            }
            
            if(mFocusedView != null){
                mFocusedView.setVisibility(View.VISIBLE);
            }
            mScaleAnimationFinish = true;
        } else {
            if (moveDistance != 0) {
                this.smoothScrollBy(moveDistance, 0);
            }
            ObjectAnimator ox = ObjectAnimator.ofFloat(mFocusedView, "x", x - itemFocusXDiff() - moveDistance);
            ObjectAnimator oy = ObjectAnimator.ofFloat(mFocusedView, "y", y - itemFocusYDiff());
            AnimatorSet lineAnimator = new AnimatorSet();
            lineAnimator.playTogether(ox, oy);
            lineAnimator.setDuration(100);
            lineAnimator.addListener(new AnimatorListener() {
                @Override public void onAnimationStart(Animator animation) {}
                @Override public void onAnimationRepeat(Animator animation) {}
                @Override public void onAnimationEnd(Animator animation) {mScaleAnimationFinish = true; }
                @Override public void onAnimationCancel(Animator animation) {mScaleAnimationFinish = true;
                }
            });
            lineAnimator.start();
        }
        mCurrentSelectedView = currentSelectedView;
    }

    private int thumb_width   = -1;
    private int thumb_height  = -1;
    private int item_margin_h = -1;
    private int FOCUS_DIFF_X  = -1;
    private int FOCUS_DIFF_Y  = -1;
    private int SCREEN_WIDTH  = -1;
    private void init(Context context){
        this.setHorizontalScrollBarEnabled(false);
        this.setVerticalScrollBarEnabled(false);

        thumb_width   = getResources().getDimensionPixelSize(R.dimen.screen_shot_thumb_width);
        thumb_height  = getResources().getDimensionPixelSize(R.dimen.screen_shot_thumb_height);
        item_margin_h = getResources().getDimensionPixelSize(R.dimen.item_margin_h);
        FOCUS_DIFF_X  = getResources().getDimensionPixelSize(R.dimen.FOCUS_DIFF_X);
        FOCUS_DIFF_Y  = getResources().getDimensionPixelSize(R.dimen.FOCUS_DIFF_Y);
        SCREEN_WIDTH  = getResources().getDisplayMetrics().widthPixels;//1920

        mContainer = new LinearLayout(context);
        mContainer.setOrientation(LinearLayout.HORIZONTAL);
        mContainer.setFocusable(true);
        mContainer.setFocusableInTouchMode(true);
        mContainer.setOnFocusChangeListener(this);
        mContainer.setOnKeyListener(this);
        LinearLayout.LayoutParams llp;
        llp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        this.addView(mContainer, llp);
        
        View leftSpaceView = new View(context);
        llp = new LinearLayout.LayoutParams(leftSpaceWidth(),getResources().getDimensionPixelSize(R.dimen.game_thumb_height));
        mContainer.addView(leftSpaceView, llp);
        
        addItemViews(0, DEFAULT_SCREEN_SHOT_NUM);
        
        addRightSpaceView();
        computeScrollRange();
    }
    
    public boolean hasFocus(){
        return mContainer.hasFocus();
    }
    
    protected abstract void addItemViews(int startIndex, int endIndex);
    
    protected void computeScrollRange(){
        mScrollRange = leftSpaceWidth() + rightSpaceWidth()
                + mItemCount*thumb_width
                + (mItemCount-1)*item_margin_h
                - SCREEN_WIDTH;
    }
    
    protected void removeSpaceView(){
        if(mRightSpaceView != null){
            mContainer.removeView(mRightSpaceView);
        }
    }
    
    protected void addRightSpaceView(){
        if(rightSpaceWidth() > 0){
            LinearLayout.LayoutParams llp;
            if(null == mRightSpaceView){
                mRightSpaceView = new View(getContext());
            }
            llp = new LinearLayout.LayoutParams(rightSpaceWidth(), thumb_height);
            mContainer.addView(mRightSpaceView, llp);
        }
    }
    
    //有时候算不来及
    public void setLayoutAdjustY(int adjustY){
        mAdjustY = adjustY;
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        if(hasFocus){
            if(mFocusedView != null){
                mFocusedView.setVisibility(View.VISIBLE);
            }
            setCurrentView(mViewLists.get(mCurrPos), 0);
            mAdjustY = 0;//只使用一次
        }else{
            if(mFocusedView != null){
                mFocusedView.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {
        if(!mScaleAnimationFinish){
            return true;
        }
        
        if(KeyEvent.ACTION_DOWN == event.getAction()){
            View shotView = null;
            if(KeyEvent.KEYCODE_DPAD_RIGHT == keyCode){
                if(mCurrPos < mItemCount - 1){
                    mCurrPos++;
                    
                    shotView = mViewLists.get(mCurrPos);
                    int distance = 0;
                    this.getGlobalVisibleRect(mVisibleRect);
                    int rightMost = mVisibleRect.right - mVisibleRect.left - rightSpaceWidth();
                    shotView.getLocationInWindow(mLocation);
                    this.getLocationInWindow(mParentLayoutLocation);
                    int xPos = mLocation[0] - mParentLayoutLocation[0];
                    int itemViewWidth = itemViewWidth();
                    if(xPos + itemViewWidth > rightMost){
                        //向右滑动 正值
                        distance = itemViewWidth + item_margin_h;
                    }
                    setCurrentView(shotView, distance);
                    WLUIUtils.playSoundEffect(shotView, keyCode);
                }else{
                    WLUIUtils.playSoundEffect(v, WLUIUtils.KEYCODE_ERROR);
                }
                return true;
            }
            
            if(KeyEvent.KEYCODE_DPAD_LEFT == keyCode){
                if(mCurrPos > 0){
                    mCurrPos--;
                    
                    shotView = mViewLists.get(mCurrPos);
                    int distance = 0;
                    this.getGlobalVisibleRect(mVisibleRect);
                    int leftMost = mVisibleRect.left + item_margin_h - itemFocusXDiff();
                    shotView.getLocationInWindow(mLocation);
                    this.getLocationInWindow(mParentLayoutLocation);
                    int xPos = mLocation[0] - mParentLayoutLocation[0];
                    if(xPos < leftMost){
                        //向左滑动 负值
                        distance = itemViewWidth() + item_margin_h;
                    }
                    setCurrentView(shotView,-distance);
                }else{
                    WLUIUtils.playSoundEffect(v, WLUIUtils.KEYCODE_ERROR);
                }
                return true;
            }
            
            if(KeyEvent.KEYCODE_ENTER == keyCode
                    || KeyEvent.KEYCODE_DPAD_CENTER == keyCode
                    || KeyEvent.KEYCODE_BUTTON_A == keyCode){//A键=遥控器的确定
                onClick();
                return true;
            }
        }
        return false;
    }
    
    protected abstract int leftSpaceWidth();
    
    protected abstract int rightSpaceWidth();
    
    protected int itemViewWidth(){
        return thumb_width;
    }
    
    protected int itemHorizontalMargin(){
        return item_margin_h;
    }
    
    protected abstract String TAG();
    
    protected int itemFocusXDiff(){
        return FOCUS_DIFF_X;
    }
    
    protected int itemFocusYDiff(){
        return FOCUS_DIFF_Y;
    }
    
    protected abstract int diffY();
    
    protected abstract int diffX();
}
