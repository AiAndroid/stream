package com.xiaomi.mibox.gamecenter.data.statics;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpException;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.HttpResponse;
import org.apache.http.HttpResponseInterceptor;
import org.apache.http.HttpVersion;
import org.apache.http.NoHttpResponseException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.conn.ClientConnectionRequest;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.conn.params.ConnPerRouteBean;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.HttpEntityWrapper;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.ExecutionContext;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;

import android.util.Log;

import com.xiaomi.mibox.gamecenter.data.IConfig;

/**
 *
 * 
 * @author smokelee
 * 
 */
public final class HttpConnectionManager {

	private static HttpParams httpParams;

	/** 保持连接时长. */
	private static final int KEEP_ALIVE_DURATION_SECS = 15;

	/** 自动关闭空闲连接时长 */
	private static final int KEEP_ALIVE_INTERVAL_SECS = 30;

	/** 超时连接 */
//	private final static int DEFAULT_TIMEOUT_MILLIS = 30000; // 30 seconds
	

	/**
	 * 最大连接数
	 */
	public final static int MAX_TOTAL_CONNECTIONS = 1024;
	/**
	 * 获取连接的最大等待时间
	 */
	public static int WAIT_TIMEOUT = 30000;
	public final static int WIFI_WAIT_TIMEOUT = 15000;
	public final static int GPRS_WAIT_TIMEOUT = 30000;
	
	/**
	 * 每个路由最大连接数
	 */
	public final static int MAX_ROUTE_CONNECTIONS = 256;

	private static class ClientConnectionManager extends
			ThreadSafeClientConnManager {
		public ClientConnectionManager(HttpParams params, SchemeRegistry schreg) {
			super(params, schreg);
		}

		@Override
		public ClientConnectionRequest requestConnection(HttpRoute route,
				Object state) {
			IdleConnectionMonitorThread.ensureRunning(this,
					KEEP_ALIVE_DURATION_SECS, KEEP_ALIVE_INTERVAL_SECS);
			if(IConfig.DEBUG){
				int i = this.getConnectionsInPool(/*new HttpRoute(new HttpHost("file.market.xiaomi.com"))*/);
				Log.d("HttpConnectionManager", "the number of ConnectionsInPool is: " + i);
			}
			return super.requestConnection(route, state);
		}
	}

	/**
	 * The thread will close the Expired&Unused connections every 300 seconds
	 */
	private static class IdleConnectionMonitorThread extends Thread {
		/**
		 * @uml.property name="manager"
		 * @uml.associationEnd
		 */
		private final ClientConnectionManager manager;
		private final int idleTimeoutSeconds;

		// currently is defined as 300 seconds
		private final int checkIntervalSeconds;
		/**
		 * @uml.property name="thread"
		 * @uml.associationEnd
		 */
		private static IdleConnectionMonitorThread thread = null;

		public IdleConnectionMonitorThread(ClientConnectionManager manager,
				int idleTimeoutSeconds, int checkIntervalSeconds) {
			super();
			this.manager = manager;
			this.idleTimeoutSeconds = idleTimeoutSeconds;
			// TODO: how often should we check and close the
			// connections,currenlty 60s
			this.checkIntervalSeconds = checkIntervalSeconds;
		}

		public static synchronized void ensureRunning(
				ClientConnectionManager manager, int idleTimeoutSeconds,
				int checkIntervalSeconds) {
			if (thread == null) {
				thread = new IdleConnectionMonitorThread(manager,
						idleTimeoutSeconds, checkIntervalSeconds);
				thread.start();
			}
		}

		@Override
		public void run() {
			try {
				while (true) {
					synchronized (this) {
						wait(checkIntervalSeconds * 1000);
					}
					manager.closeExpiredConnections();
					manager.closeIdleConnections(idleTimeoutSeconds,
							TimeUnit.SECONDS);
					synchronized (IdleConnectionMonitorThread.class) {
						if (manager.getConnectionsInPool() == 0) {
							thread = null;
							return;
						}
					}
				}
			} catch (InterruptedException e) {
				thread = null;
			}
		}
	}

	
	/**
	 * 初始化系统连接池
	 * 
	 * @param certInputStream
	 *            证书流,可以为null.当证书流为null时不初始化https 证书的获取流程:证书导出公钥,存为cer即可
	 */
	static ClientConnectionManager Init() {
		WAIT_TIMEOUT = GPRS_WAIT_TIMEOUT;
//		if(SystemConfig.isWifiNetwork(GamecenterApp.getGameCenterContext()))
//		{
//			WAIT_TIMEOUT = WIFI_WAIT_TIMEOUT;
//		}
		
		
		httpParams = new BasicHttpParams();

		HttpProtocolParams.setVersion(httpParams, HttpVersion.HTTP_1_1);
		HttpProtocolParams.setContentCharset(httpParams, HTTP.UTF_8);

		// 设置最大连接数
		ConnManagerParams.setMaxTotalConnections(httpParams, MAX_TOTAL_CONNECTIONS);
		// 设置获取连接的最大等待时间
		ConnManagerParams.setTimeout(httpParams, WAIT_TIMEOUT);
		
		// 设置每个路由最大连接数
		ConnPerRouteBean connPerRoute = new ConnPerRouteBean(MAX_ROUTE_CONNECTIONS);
		ConnManagerParams.setMaxConnectionsPerRoute(httpParams, connPerRoute);
		
		// 设置连接超时时间
		HttpConnectionParams.setConnectionTimeout(httpParams, WAIT_TIMEOUT);
		// 设置读取超时时间
		HttpConnectionParams.setSoTimeout(httpParams, WAIT_TIMEOUT);
		// 设置自动跳转
		HttpClientParams.setRedirecting(httpParams, true);
		// 设置Socket缓冲大小
		HttpConnectionParams.setSocketBufferSize(httpParams, 8192);
		
		SchemeRegistry registry = new SchemeRegistry();
		registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));

		 {
			KeyStore trustStore;
			try {
				trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
				trustStore.load(null, null);
				SSLSocketFactory sf = new WaliSSLSocketFactory(
						trustStore);
				sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
				registry.register(new Scheme("https", sf, 443));
			} catch (Exception e) {
				if(IConfig.DEBUG) e.printStackTrace();
			}
		}
		return new ClientConnectionManager(httpParams, registry);
	}
	
	public static Object _lock_ = new Object();
	
	public static void reset()
	{
		synchronized (_lock_) {
			client = null;
		}
	}

	private static DefaultHttpClient client; 
	
	public static DefaultHttpClient getHttpClient() {
		synchronized (_lock_) {
			if(client == null)
			{
				client = new DefaultHttpClient(Init(), httpParams);
				client.setHttpRequestRetryHandler(new HttpRequestRetryHandler() {
					@Override
					public boolean retryRequest(IOException exception, 	int executionCount, HttpContext context) {
						if (executionCount > 2) {
							// 超过最大次数则不需要重试
							return false;
						}
						if (exception instanceof NoHttpResponseException) {
							// 服务停掉则重新尝试连接
							return true;
						}
						HttpRequest request = (HttpRequest) context.getAttribute(ExecutionContext.HTTP_REQUEST);
						boolean idempotent = (request instanceof HttpEntityEnclosingRequest);
						if (!idempotent) {
							// 请求内容相同则重试
							return true;
						}
						return false;
					}
				});
				// 请求请假gzip支持
				client.addRequestInterceptor(new HttpRequestInterceptor() {

					@Override
					public void process(final HttpRequest request,
							final HttpContext context) throws HttpException,
							IOException {
						if (!request.containsHeader("Accept-Encoding")) {
							request.addHeader("Accept-Encoding", "gzip");
						}
					}
				});

				// 处理GZIP
				client.addResponseInterceptor(new HttpResponseInterceptor() {
					@Override
					public void process(HttpResponse response, HttpContext context)
							throws HttpException, IOException {
						HttpEntity entity = response.getEntity();
						Header ceheader = entity.getContentEncoding();
						if (ceheader != null) {
							HeaderElement[] codecs = ceheader.getElements();
							for (int i = 0; i < codecs.length; i++) {
								if (codecs[i].getName().equalsIgnoreCase("gzip")) {
									response.setEntity(new GzipDecompressingEntity(
											response.getEntity()));
									return;
								}
							}
						}
					}
				});
			}
			return client;
		}
	}
	
	static class GzipDecompressingEntity extends HttpEntityWrapper {

		public GzipDecompressingEntity(final HttpEntity entity) {
			super(entity);
		}

		@Override
		public InputStream getContent() throws IOException,
				IllegalStateException {
			InputStream wrappedin = wrappedEntity.getContent();
			return new GZIPInputStream(wrappedin);
		}

		@Override
		public long getContentLength() {
			return -1;
		}
	}

	private static class WaliSSLSocketFactory extends SSLSocketFactory {
		SSLContext sslContext = SSLContext.getInstance("TLS");

		public WaliSSLSocketFactory(KeyStore truststore)
				throws NoSuchAlgorithmException, KeyManagementException,
				KeyStoreException, UnrecoverableKeyException {
			super(truststore);

			TrustManager tm = new X509TrustManager() {

				@Override
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkServerTrusted(X509Certificate[] chain,
						String authType) throws CertificateException {

				}

				@Override
				public void checkClientTrusted(X509Certificate[] chain,
						String authType) throws CertificateException {

				}
			};

			this.sslContext.init(null, new TrustManager[] { tm }, null);
		}

		@Override
		public Socket createSocket(Socket socket, String host, int port,
				boolean autoClose) throws IOException, UnknownHostException {
			return this.sslContext.getSocketFactory().createSocket(socket,
					host, port, autoClose);
		}

		@Override
		public Socket createSocket() throws IOException {
			return this.sslContext.getSocketFactory().createSocket();
		}
	}

}