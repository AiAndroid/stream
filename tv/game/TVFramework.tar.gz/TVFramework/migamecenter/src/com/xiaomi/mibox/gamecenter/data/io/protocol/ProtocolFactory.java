package com.xiaomi.mibox.gamecenter.data.io.protocol;

import com.xiaomi.mibox.gamecenter.data.io.Connection.NetworkError;

import android.content.Context;
import android.util.Pair;

/**
 * 系统中非CMS类的协议
 * @author smokelee
 *
 */
public class ProtocolFactory 
{
	public static Pair<String , NetworkError> protocol_load_sign(Context ctx, String verify)
	{
		Protocol_LoadMibiKey a = new Protocol_LoadMibiKey(ctx, verify);
		NetworkError err = a.execute();
		return new Pair<String, NetworkError>(a.getResponse(),err);
	}
}
