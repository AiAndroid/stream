package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import java.text.DecimalFormat;

import android.util.AttributeSet;
import android.view.*;
import android.widget.*;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.VolleyHelper;
import com.tv.ui.metro.model.GameItem;
import com.tv.ui.metro.view.CenterIconImage;
import com.tv.ui.metro.view.ImageChangedListener;
import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.data.MainHandler;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.bluetooth.BluetoothUtils;
import com.xiaomi.mibox.gamecenter.bluetooth.HandlerCheck;
import com.xiaomi.mibox.gamecenter.bluetooth.OnHandlerCheckResult;
import com.xiaomi.mibox.gamecenter.data.LocalAppManager;
import com.xiaomi.mibox.gamecenter.data.download.DownloadObserver;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationStatus;
import com.xiaomi.mibox.gamecenter.data.download.XMDownloadManager;
import com.xiaomi.mibox.gamecenter.data.OperateDevice;
import com.xiaomi.mibox.gamecenter.data.statics.Report;
import com.xiaomi.mibox.gamecenter.data.statics.ReportManager;
import com.xiaomi.mibox.gamecenter.data.statics.StaticsType;
import com.xiaomi.mibox.gamecenter.data.statics.Report.ReportType;
import com.xiaomi.mibox.gamecenter.ui.operator.OpenHandlerGameGuidePage;
import com.xiaomi.mibox.gamecenter.utils.Client;
import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Paint;
import android.text.Html;
import android.text.TextUtils.TruncateAt;
import android.util.Log;
import android.util.TypedValue;
import com.xiaomi.mitv.store.utils.Utils;

/**
 * 游戏基本信息控件
 * @author liubiqiang
 *
 */
public class GameInfoView extends RelativeLayout implements OnHandlerCheckResult{
	private static final String TAG = "GameInfoView";    
	//图片
    private CenterIconImage mIconView;
    private TextView mIconNameView;
    //
    private TextView mGameNameView;
    
    private TextView mDownloadView;
    private TextView mSizeView;
    private TextView mSysSpaceView;
    
    private TextView mCategoryView;//分类信息
    private ImageView mOperatorImageView;//操控图片视图
    private TextView mOperatorView;//操控类型视图
    
    private Button mActionButton;
    private RelativeLayout mInstallingLayout;
    private ProgressBar mInstallingBar;
    private TextView mInstallingTextView;
    
    private GameItem mGameInfo;
    private boolean isSpaceEnough = true;
    
    //多看系统会保留系统空间
    //
    private static final long SYSTEM_SPACE = 100*1024*1024L;
    private static final long SYSTEM_SPACE_TV2 = 492*1024*1024L;
    private static final int PROGRESS_BAR_WIDTH = 205;
    private static final int PROGRESS_BAR_HEIGHT = 16;
    
    protected LocalAppManager mAppMgr;
    private DownloadObserverImpl mObserver;
    
    private String mFrom;
    private String mFromId;
    private String mFromPosition;
    
    public GameInfoView(Context context, AttributeSet as) {
        this(context, as, 0);
    }

    public GameInfoView(Context context, AttributeSet as, int uiStyle) {
        super(context, as, uiStyle);

    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        init(getContext());
    }

    public GameInfoView(Context context) {
        this(context, null, 0);
    }
    
    public void setOnImageChangedListener(ImageChangedListener listener){
        if(mIconView != null){
            mIconView.setOnImageChangedListener(listener);
        }
    }
    
    public boolean focus(){
        return mActionButton.hasFocus();
    }
   
    public void catchFocus(){
        mActionButton.requestFocus();
    }
    
    /**
     * 
     * @param gameInfo
     */
    public void bindGameInfo(GameItem gameInfo, String from,
    		String fromId, String fromLabel){
        mGameInfo = gameInfo;
        if (mGameInfo == null) {
            if (mObserver != null) {
                mObserver.release();
            }
            return;
        }
        if (mObserver == null) {
            mObserver = new DownloadObserverImpl(getContext(), mGameInfo);
        }
        update_Status();
        mObserver.setGameId(mGameInfo);

        VolleyHelper.getInstance(getContext()).getImageLoader().get(gameInfo.images.icon().url,  ImageLoader.getImageListener(mIconView, R.drawable.icon_default_app, R.drawable.icon_default_app));
        mIconNameView.setText(gameInfo.name);
        mGameNameView.setText(gameInfo.name);
        
        mDownloadView.setText(String.format(getResources().getString(R.string.format_download_count),gameInfo.counts.download));
        
        long size = Integer.valueOf(gameInfo.sizes.packaged);

        if(gameInfo.assets != null){
            for(GameItem.Assets item: gameInfo.assets){
                size += item.size;
            }
        }

        String parten = "#.##";
        DecimalFormat decimal = new DecimalFormat(parten);
//        String formatStr = decimal.format(size/WLUIUtils.MB_D);
//        mSizeView.setText(formatStr + "MB");
        mSizeView.setText(GamecenterUtils.getByteString(size, "%.2f", getContext()));
        
        //系统可用空间
        long availableSpace = AppStoreUtils.readSystemAvailableSize();
        long space = availableSpace - Integer.valueOf(gameInfo.sizes.packaged);
        if(Client.isTV2()){
            space -= SYSTEM_SPACE_TV2;
        }else{
            space -= SYSTEM_SPACE;
        }
        if(space <= size){
            isSpaceEnough = false;
            mSysSpaceView.setText(Html.fromHtml(getResources().getString(R.string.after_installed_no_space)));

            //clear my own cache image
            try {
                Utils.deleteFile(getContext().getCacheDir().getAbsolutePath() + "/image/");
            }catch (Exception e){}
        }else{
            isSpaceEnough = true;
            parten = "#";
            decimal = new DecimalFormat(parten);
            mSysSpaceView.setText(Html.fromHtml(getResources().getString(R.string.after_installed_space_available,decimal.format(availableSpace/WLUIUtils.MB_D))));
        }

        if(gameInfo.category.size() > 0)
            mCategoryView.setText(gameInfo.category.get(0).name);
        
        // 游戏的操控类型
        if((OperateDevice.OperateDeviceHandler & gameInfo.flags.operate_device) > 0){
            mOperatorImageView.setImageResource(R.drawable.operator_handler);
            mOperatorView.setText(R.string.txt_operator_handler);
        }else if((OperateDevice.OperateDeviceMouse & gameInfo.flags.operate_device) > 0){
            mOperatorImageView.setImageResource(R.drawable.operator_mouse);
            mOperatorView.setText(R.string.txt_operator_mouse);
        }else{
            mOperatorImageView.setImageResource(R.drawable.operator_controller);
            mOperatorView.setText(R.string.txt_operator_controller);
        }
    }
    
    private void init(Context context){
        mAppMgr = LocalAppManager.getManager();

        View viewRoot = LayoutInflater.from(context).inflate(R.layout.game_info_layout, null);

        //icon
        mIconView = (CenterIconImage) viewRoot.findViewById(R.id.game_icon_imageview);
        //iconName
        mIconNameView = (TextView) viewRoot.findViewById(R.id.game_info_name);

        //信息部分
        LinearLayout infoLayout = new LinearLayout(context);
        //游戏名字
        mGameNameView = (TextView) viewRoot.findViewById(R.id.game_name);

        //下载量/大小/系统可用空间部分
        //下载量
        mDownloadView = (TextView) viewRoot.findViewById(R.id.game_download_count);
        mSizeView = (TextView) viewRoot.findViewById(R.id.game_size_view);
        //系统可用空间
        mSysSpaceView = (TextView) viewRoot.findViewById(R.id.game_sys_avail_space);

        //分类信息与操控类型
        mCategoryView = (TextView) viewRoot.findViewById(R.id.game_category_name);
        mOperatorImageView = (ImageView) viewRoot.findViewById(R.id.game_operator_image);

        //名字
        mOperatorView = (TextView) viewRoot.findViewById(R.id.game_operator_name);
        
        //右边部分
        mActionButton = (Button) viewRoot.findViewById(R.id.button_action);
        mActionButton.setOnKeyListener(mActionKeyListener);

        Paint p = mActionButton.getPaint();
        p.setFakeBoldText(true);

        mInstallingLayout = (RelativeLayout) viewRoot.findViewById(R.id.game_installing_relative);
        mInstallingBar = (ProgressBar) viewRoot.findViewById(R.id.game_info_item_downloading_progressbar);
//        mInstallingBar = (ProgressBar) inflate(getContext(), R.layout.game_installing, null);
//        RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(getResources().getDimensionPixelSize(R.dimen.progress_game_item_width), getResources().getDimensionPixelSize(R.dimen.progress_game_item_height));
//        rlp.addRule(RelativeLayout.CENTER_HORIZONTAL);
//        rlp.topMargin = getResources().getDimensionPixelSize(R.dimen.progress_top_mafgin);
//        mInstallingLayout.addView(mInstallingBar, rlp);
        
        mInstallingTextView = (TextView) viewRoot.findViewById(R.id.installing_text);

        addView(viewRoot, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }
    
    private View.OnKeyListener mActionKeyListener = new View.OnKeyListener() {
        
        @Override
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if(KeyEvent.ACTION_DOWN == event.getAction()){
                //屏蔽系统默认的处理方式
                if(KeyEvent.KEYCODE_DPAD_LEFT == keyCode
                        || KeyEvent.KEYCODE_DPAD_RIGHT == keyCode
                        || KeyEvent.KEYCODE_DPAD_UP == keyCode){
                    WLUIUtils.playSoundEffect(v, WLUIUtils.KEYCODE_ERROR);
                    return true;
                }
            }
            return false;
        }
    };
    
    protected String calc_progress(OperationSession session) 
    {
        double r = session.getRecv();
        double t = session.getTotal();
        if(IConfig.DEBUG) Log.e(TAG, "total=" + (long)t);
        long percentage;
        if (r < 0 || t <= 0){
            percentage = 0;
        }else{
            percentage = Math.round(100* r / t);
        }
        if(IConfig.DEBUG) Log.e(TAG, "progress=" + percentage);
        return String.valueOf(percentage);
    }

    private void update_Status(){
        if (mAppMgr.isInstalled(mGameInfo.packagename)){
            if (mAppMgr.isUpdateable(mGameInfo)){
                bindUpdate(mGameInfo);
            } else {
                bindInstalled(mGameInfo);
            }
        } else{
            bindNormal(mGameInfo);
        }
    }
    
    /**
     * 启动点击
     */
    protected OnClickListener mStartClickListener = new OnClickListener() {
        @Override
        public void onClick(android.view.View v) {
			if (null != mGameInfo) {
				if(OperateDevice.OperateDeviceHandler == mGameInfo.flags.operate_device){
					new HandlerCheck(getContext(), GameInfoView.this);
				}else{
					openGame();
				}
			}
        }
    };
    
    private void openGame(){
    	if (null != mGameInfo 	&& getContext() instanceof Activity) {
    		WLUIUtils.openGame((Activity)getContext(),	mGameInfo.packagename, TAG);
    	}
    }
    
    //安装
    private View.OnClickListener mInstallClickListener = new View.OnClickListener() {
        
		@Override
		public void onClick(View v) {
			downloadGame(false);
		}
    };
    
    //更新
    private View.OnClickListener mUpgradeClickListener = new View.OnClickListener() {
        
		@Override
		public void onClick(View v) {
			downloadGame(true);
		}
    };
    
    private void downloadGame(boolean update){
		if (null == mGameInfo) {
			return;
		}
		
		ReportManager.getInstance().send(Report.createReport(ReportType.DOWNLOAD,mFrom, mFromId, null,StaticsType.PAGE_DETAIL,mGameInfo.id,mFromPosition, update ? "2" : "1"));
		
		if (!isSpaceEnough) {
			Intent intent = new Intent(getContext(),SpaceShortageActivity.class);
			getContext().startActivity(intent);
			return;
		}
		if (GamecenterUtils.isConnected(getContext())) {
			XMDownloadManager.getInstance().appendDownloadTask(mGameInfo.id);
		} else {
			Toast.makeText(getContext(), R.string.txt_no_network, Toast.LENGTH_SHORT).show();
		}
    }
    
    private void bindUpdate(GameItem gameInfo){
        mActionButton.setBackgroundResource(R.drawable.new_common_button);
        mActionButton.setText(R.string.button_text_update);
        mActionButton.setOnClickListener(mUpgradeClickListener);
        mInstallingLayout.setVisibility(View.GONE);
        if(mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(false);
        }
    }
    
    private void bindNormal(GameItem gameInfo){
        mActionButton.setBackgroundResource(R.drawable.new_common_button);
        mActionButton.setText(R.string.button_text_install);
        mActionButton.setOnClickListener(mInstallClickListener);
        mInstallingLayout.setVisibility(View.GONE);
        if(mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(false);
        }
    }
    
    private void bindInstalled(GameItem gameInfo){
        mActionButton.setBackgroundResource(R.drawable.new_common_button);
        mActionButton.setText(R.string.button_text_open);
        mActionButton.setOnClickListener(mStartClickListener);
        mInstallingLayout.setVisibility(View.GONE);
        if(mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(false);
        }
    }
    
    protected void bindInstalling(GameItem gameInfo) {
        mActionButton.setBackgroundResource(R.drawable.button_normal);
        mActionButton.setText("");
        setOnClickListener(null);
        mInstallingTextView.setText(R.string.txt_installing);
        mInstallingLayout.setVisibility(View.VISIBLE);
        if(!mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(true);
        }
    }

    protected void bindUnzipping(GameItem gameInfo) {
        mActionButton.setBackgroundResource(R.drawable.button_normal);
        mActionButton.setText("");
        setOnClickListener(null);
        mInstallingTextView.setText(R.string.txt_unzipping);
        mInstallingLayout.setVisibility(View.VISIBLE);
        if(!mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(true);
        }
    }

    protected void updateProgressPending(GameItem gameInfo) {
        mActionButton.setBackgroundResource(R.drawable.button_normal);
        mActionButton.setText("");
        setOnClickListener(null);
        mInstallingTextView.setText(R.string.txt_pending);
        mInstallingLayout.setVisibility(View.VISIBLE);
        if(!mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(true);
        }
    }

    protected void updateProgressConnecting(GameItem gameInfo) {
        mActionButton.setBackgroundResource(R.drawable.button_normal);
        mActionButton.setText("");
        setOnClickListener(null);
        mInstallingTextView.setText(R.string.txt_connecting);
        mInstallingLayout.setVisibility(View.VISIBLE);
        if(!mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(true);
        }
    }

    protected void updateProgressVerifying(GameItem gameInfo) {
        mActionButton.setBackgroundResource(R.drawable.button_normal);
        mActionButton.setText("");
        setOnClickListener(null);
        mInstallingTextView.setText(R.string.txt_verifying);
        mInstallingLayout.setVisibility(View.VISIBLE);
        if(!mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(true);
        }
    }

    protected void updateProgressInstalling(GameItem gameInfo) {
        mActionButton.setBackgroundResource(R.drawable.button_normal);
        mActionButton.setText("");
        setOnClickListener(null);
        mInstallingTextView.setText(R.string.txt_installing);
        mInstallingLayout.setVisibility(View.VISIBLE);
        if(!mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(true);
        }
    }
    
    protected void updateProgressPaused(OperationSession session) {
        mActionButton.setBackgroundResource(R.drawable.button_normal);
        mActionButton.setText("");
        setOnClickListener(null);
        mInstallingTextView.setText(R.string.txt_paused);
        mInstallingLayout.setVisibility(View.VISIBLE);
        if(!mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(true);
        }
    }

    protected void updateProgressDownloading(String progress) {
        mActionButton.setBackgroundResource(R.drawable.button_normal);
        mActionButton.setText("");
        setOnClickListener(null);
        mInstallingTextView.setText(R.string.txt_downloading);
        mInstallingLayout.setVisibility(View.VISIBLE);
        if(mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(false);
        }
        if(progress != null){
            int pro = 0;
            try{
                pro = Integer.parseInt(progress);
                mInstallingBar.setProgress(pro);
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    protected void updateProgressUnzipping(String progress) {
        mActionButton.setBackgroundResource(R.drawable.button_normal);
        mActionButton.setText("");
        setOnClickListener(null);
        mInstallingTextView.setText(R.string.txt_unzipping);
        mInstallingLayout.setVisibility(View.VISIBLE);
        if(!mInstallingBar.isIndeterminate()){
            mInstallingBar.setIndeterminate(true);
        }
    }

    protected void updateProgressReinstall(OperationSession session) {
        
    }
    
    private class DownloadObserverImpl extends DownloadObserver {

        public DownloadObserverImpl(Context ctx, GameItem game) {
            super(ctx, game);
        }

        @Override
        protected void onDownloadStatusChange(int gameId,
                OperationSession session) {
            if (null == mGameInfo) {
                return;
            }
            if (session == null) {
                return;
            }
            if (session.getStatus() == OperationStatus.DownloadQueue) {
                updateProgressPending(mGameInfo);
            } else if (session.getStatus() == OperationStatus.Downloading) {
                updateProgressDownloading(calc_progress(session));
            } else if (session.getStatus() == OperationStatus.DownloadPause) {
                updateProgressPaused(session);
            } else if (session.getStatus() == OperationStatus.DownloadFail) {
                //下载失败 Google原生的系统是有个超时机制，这样网络不好的情况下就会下载失败，此时可以进入下载管理器点击重新下载
                //看不到下载管理器的话。。。用户只能另点一个游戏下载，然后在通知栏进入下载管理器
//                updateProgressPaused(session);
            	update_Status();
            	MainHandler.getInstance().post(new Runnable() {
					@Override
					public void run() {
						if(null == getContext() || null == mGameInfo){
							return;
						}
						Toast.makeText(getContext(), 
								getResources().getString(R.string.download_fail, mGameInfo.name),
								Toast.LENGTH_LONG).show();
					}
				});
            } else if (session.getStatus() == OperationStatus.DownloadSuccess) {
                // TODO 下载完成

            } else if (session.getStatus() == OperationStatus.InstallQueue) {
                updateProgressInstalling(mGameInfo);
            }
            // zwb s
            else if (session.getStatus() == OperationStatus.Unzipping) {
                updateProgressUnzipping(session.getRadio() + "");
            }
            // zwb e
            else if (session.getStatus() == OperationStatus.Installing) {
                updateProgressInstalling(mGameInfo);
            } else if (session.getStatus() == OperationStatus.InstallPause) {
//                updateProgressPaused(session);
            	update_Status();
            } else if (session.getStatus() == OperationStatus.InstallNext) {
                updateProgressInstalling(mGameInfo);
            } else if (session.getStatus() == OperationStatus.Uninstall) {
                updateProgressReinstall(session);
            } else if (session.getStatus() == OperationStatus.Success) {
                bindInstalled(mGameInfo);
            } else if (session.getStatus() == OperationStatus.Remove) {
                update_Status();
            }
        }

        @Override
        protected void onPackageStatusChange() {
            update_Status();
        }
    }
    
    /**
     * 下载量部分的View
     * @return
     */
    public static TextView createDssTextView(Context context){
        Resources res = context.getResources();
        TextView tv = new TextView(context);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 
                res.getInteger(R.integer.text_font_size_30));
        tv.setSingleLine(true);
        tv.setEllipsize(TruncateAt.END);
        tv.setTextColor(res.getColor(
                R.color.text_color_white_70));
        return tv;
    }

	@Override
	public void onCheckFinish(boolean hasConnectedDevice) {
		if(hasConnectedDevice){
			openGame();
		}else{
			Intent intent = new Intent(getContext(), OpenHandlerGameGuidePage.class);
			boolean bonded = false;
			if(BluetoothUtils.isMatchXiaomiBluetooth()){
				bonded = true;
			}
			intent.putExtra(OpenHandlerGameGuidePage.BOND, bonded);
			intent.putExtra(OpenHandlerGameGuidePage.PACKAGE_NAME, 
					mGameInfo.packagename);
			getContext().startActivity(intent);
		}
	}
}
