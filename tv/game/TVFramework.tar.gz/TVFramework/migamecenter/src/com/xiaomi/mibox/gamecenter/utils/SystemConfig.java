package com.xiaomi.mibox.gamecenter.utils;

import java.lang.reflect.Method;

import com.xiaomi.mibox.gamecenter.data.IConfig;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.Log;

/**
 * 获取系统的设置
 * @author smokelee
 *
 */
public class SystemConfig {
	/**
     * 
     */
    private static Integer mSdkVersion;

	private static String UserAgent;
	
	private static ConnectivityManager cmgr;
	
	private static TelephonyManager telMgr;
	private static String model;//手机型号
	private static String SDK_VERSION;//SDK版本号
	private static String PRODUCT;//设备
	
	public static void getTelephonyManager(Context context) {
		if (telMgr == null) {
			telMgr = (TelephonyManager) context
					.getSystemService(Context.TELEPHONY_SERVICE);
		}
	}

	/**
	 * 获取手机UA
	 * @return
	 */
	public static String get_phone_ua() {
		if (UserAgent == null) {
			StringBuffer sb = new StringBuffer();
			sb.append(getSystemProperties("ro.product.manufacturer"));//制造商
			sb.append("|");
			sb.append(model());//手机型号
			sb.append("|");
			sb.append(getSystemProperties("ro.build.version.release"));
			sb.append("|");
			sb.append(getSystemProperties("ro.build.display.id"));
			sb.append("|");
			sb.append(getSystemProperties("ro.build.version.sdk"));
			sb.append("|");
			sb.append(getSystemProperties("ro.product.device"));
			UserAgent = sb.toString();
		}
		if(IConfig.DEBUG){
			Log.e("UA", UserAgent);
		}
		return UserAgent;
	}
	
	/**
	 * 手机型号
	 * @return
	 */
    public static String model(){
        if(null == model){//保证如果用户从Conversation进如客户端的话也能判断该值
        	model = SystemConfig.getSystemProperties("ro.product.model");
        }
        return model;
    }
    
    public static String sdkVersion(){
    	if(null == SDK_VERSION){
    		SDK_VERSION = getSystemProperties("ro.build.version.sdk");
    	}
    	return SDK_VERSION;
    }
    
    public static String product(){
    	if(null == PRODUCT){
    		PRODUCT = Build.PRODUCT;
    	}
    	return PRODUCT;
    }
	
	private static void get_connectivitymanager(Context ctx) {
		if (cmgr == null) {
			cmgr = (ConnectivityManager) ctx.getSystemService(
					Context.CONNECTIVITY_SERVICE);
		}
	}
	
	public static NetworkInfo getActiveNetworkInfo(Context ctx) {
		get_connectivitymanager(ctx);
		return cmgr.getActiveNetworkInfo();
	}
	
	public static boolean isNetworkAvailable(Context ctx) {
		get_connectivitymanager(ctx);
		return cmgr.getActiveNetworkInfo() != null;
	}
	
	public static boolean isWifiNetwork(Context ctx) {
		get_connectivitymanager(ctx);
		NetworkInfo ni = cmgr.getActiveNetworkInfo();
		if (ni == null) {
			return false;
		}
		return ni.getType() == ConnectivityManager.TYPE_WIFI
				|| ni.getType() == ConnectivityManager.TYPE_WIMAX;
	}
	
	public static boolean isMobileNetwork(Context ctx) {
		get_connectivitymanager(ctx);
		NetworkInfo ni = cmgr.getActiveNetworkInfo();
		if (ni == null) {
			return false;
		}
		return !(ni.getType() == ConnectivityManager.TYPE_WIFI || 
				ni.getType() == ConnectivityManager.TYPE_WIMAX) ;
	}
    
    /**
     * 获取SDK版本号，
     * @param context
     * @return
     */
    public static int getPlatFormSDK(){
        if(null == mSdkVersion){
            String sdk = getSystemProperties("ro.build.version.sdk");
            int SDK = 3;
            if(sdk!=null){
                try{
                    SDK = Integer.parseInt(sdk);
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }
            mSdkVersion = SDK;
        }
        return mSdkVersion;
    }

    /**
     * 从android.os.SystemProperties中获取一个属性
     * @param prop
     * @return
     */
    public static String getSystemProperties(String prop) {
        String output = "";
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            Method get = sp.getMethod("get", String.class);
            output = (String)get.invoke(null, prop);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return output;
    }
    
    /**
     * 避免被实例化
     */
    private SystemConfig(){
        
    }
}
