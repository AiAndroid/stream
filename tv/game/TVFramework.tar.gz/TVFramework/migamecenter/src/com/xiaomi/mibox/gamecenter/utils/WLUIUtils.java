package com.xiaomi.mibox.gamecenter.utils;


import com.tv.ui.metro.view.EmptyLoadingView;
import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.R;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.SoundEffectConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ViewAnimator;
import android.widget.ViewFlipper;

/**
 * 
 * @author mengshu
 *
 */
public class WLUIUtils {
	
	public static final long MB = 1048576L;
	public static final double MB_D = 1048576.00d;
	public static final long KB = 1024;
	
	
	public static final int SHAKE_1_START = 10;
	public static final int SHAKE_2_START = 6;
	public static final int SHAKE_3_START = 2;
	public static final int SHAKE_OFFSET = 10;
	
	/**
	 * 判断配对的蓝牙设置是否是已经配对的蓝牙
	 * 通过名字来判断
	 * @param device
	 * @return
	 */
	private static final String XIAOMI_HANDLER = new String("\u5C0F\u7C73\u624B\u67C4");//小米手柄
	private static final String XIAOMI_BLUETOOTH_HANDLER = new String("\u5C0F\u7C73\u84DD\u7259\u624B\u67C4");//小米蓝牙手柄
	private static final String XIAOMI_BLUETOOTH_GAME_HANDLER = new String("\u5C0F\u7C73\u84DD\u7259\u6E38\u620F\u624B\u67C4");//小米蓝牙游戏手柄
	public static boolean isXiaomiBluetoothHandle(BluetoothDevice device){
		if(null == device){
			return false;
		}
		String name = device.getName();
		if(XIAOMI_BLUETOOTH_HANDLER.equals(name) 
				|| XIAOMI_BLUETOOTH_GAME_HANDLER.equals(name)
				|| XIAOMI_HANDLER.equals(name)){
			return true;
		}
		
		return false;
	}

	/**
	 * 
	 * @param hidPid
	 * @return
	 */
	private static final int XIAOMI_BT_PID = 10007;
//	private static final int XIAOMI_RC_VID_HIGH_ADDRESS = 2;//遥控器
	private static final int XIAOMI_HANDLE_VID_HIGH_ADDRESS = 1;//遥控器

	public static boolean isXiaomiBluetoothHandleByHidPid(int vid, int pid) {
		if(vid == XIAOMI_BT_PID){
			if((((pid >> 8) & 0x0F)) == XIAOMI_HANDLE_VID_HIGH_ADDRESS){
				return true;
			}
		}
		return false;
//		if (hidPid >= 0x3100 && hidPid < 0x3200) {
//			return true;
//		} else {
//			return false;
//		}
	}
	
	/**
	 * 
	 * @param context
	 * @param packageName
	 * @param gameId
	 * @param TAG
	 */
	public static void openGame(Activity context, String packageName,
			String TAG){
		if (null == context || TextUtils.isEmpty(packageName)
				|| !(context instanceof Activity)) {
			if (IConfig.DEBUG) Log.d(TAG, "can't open game:" + packageName);
			return;
		}
		Intent launchIntent = context.getPackageManager()
				.getLaunchIntentForPackage(packageName);
		if (launchIntent == null) {
			if (IConfig.DEBUG) Log.d(TAG, "can't open game:" + packageName);
		} else {
			try {
				context.startActivity(launchIntent);
			} catch (ActivityNotFoundException e) {
				if (IConfig.DEBUG) Log.d(TAG, "can't open game:" + packageName);
			}
		}
	}
	
	/**
	 * 
	 * @param view
	 * @param rightShakeDelta
	 * @param leftShakeDelta
	 * @return
	 */
	public static AnimatorSet getShakeAnimator(View view, 
			int rightShakeDelta, int leftShakeDelta) {
		if (view == null) {
			return null;
		}
		float y = view.getY();
		
		AnimatorSet as = new AnimatorSet();
		as.setDuration(150);
		ObjectAnimator oa1 = ObjectAnimator.ofFloat(view, "y", y + rightShakeDelta);
		ObjectAnimator oa2 = ObjectAnimator.ofFloat(view, "y", y - leftShakeDelta);
		ObjectAnimator oa3 = ObjectAnimator.ofFloat(view, "y", y);
		as.playSequentially(oa1, oa2, oa3);
		return as;
	}
	
	/**
	 * 
	 * @param view
	 * @param rightShakeDelta
	 * @param leftShakeDelta
	 * @return
	 */
	public static AnimatorSet getXShakeAnimator(View view, 
			int rightShakeDelta, int leftShakeDelta) {
		if (view == null) {
			return null;
		}
		float x = view.getX();
		
		AnimatorSet as = new AnimatorSet();
		as.setDuration(150);
		ObjectAnimator oa1 = ObjectAnimator.ofFloat(view, "x", x + rightShakeDelta);
		ObjectAnimator oa2 = ObjectAnimator.ofFloat(view, "x", x - leftShakeDelta);
		ObjectAnimator oa3 = ObjectAnimator.ofFloat(view, "x", x);
		as.playSequentially(oa1, oa2, oa3);
		return as;
	}
	
	/**
	 * 
	 * @param context
	 * @return
	 */
	public static Animation createBounceAnimation(Context context, boolean left){
		Animation a;
		if(left){
			a = new TranslateAnimation(0.0f,-30.0f, 0.0f, 0.0f);
		}else{
			a = new TranslateAnimation(0.0f,30.0f, 0.0f, 0.0f);
		}
	    a.setDuration(1000);
	    a.setStartOffset(300);
	    a.setRepeatMode(Animation.RESTART);
	    a.setInterpolator(AnimationUtils.loadInterpolator(context,
	            android.R.anim.bounce_interpolator));
	    return a;
	}
	
	/**
	 * 播放点击时候的音响效果
	 * @param currentSelectedView
	 * @param keyCode
	 */
	public static final int KEYCODE_NORMAL = 0;
	public static final int KEYCODE_ERROR = -1;
	public static void playSoundEffect(View currentSelectedView, int keyCode) {
		if(null == currentSelectedView){
			return;
		}
		int soundEffect = SoundEffectConstants.CLICK;
		switch (keyCode) {
			case KeyEvent.KEYCODE_DPAD_LEFT:
				soundEffect = SoundEffectConstants.NAVIGATION_LEFT;
				break;
			case KeyEvent.KEYCODE_DPAD_RIGHT:
				soundEffect = SoundEffectConstants.NAVIGATION_RIGHT;
				break;
			case KeyEvent.KEYCODE_DPAD_UP:
				soundEffect = SoundEffectConstants.NAVIGATION_UP;
				break;
			case KeyEvent.KEYCODE_DPAD_DOWN:
				soundEffect = SoundEffectConstants.NAVIGATION_DOWN;
				break;
			case KEYCODE_ERROR:{//ERROR
				soundEffect = 5;
				break;
			}
			default:
				break;
		}
		currentSelectedView.playSoundEffect(soundEffect);
	}

	/**
	 * 
	 * @param context
	 * @return
	 */
	public static ImageView createImageView(Context context){
		ImageView imageView = new ImageView(context);
		imageView.setFocusable(true);
		imageView.setFocusableInTouchMode(true);
		return imageView;
	}
	
	/**
	 * 
	 * @param context
	 * @return
	 */
	public static ViewFlipper createViewFlipper(Context context){
		ViewFlipper viewFlipper = new ViewFlipper(context);
		viewFlipper.setFlipInterval(2000);
		viewFlipper.setInAnimation(context, R.anim.push_up_in);
		viewFlipper.setOutAnimation(context, R.anim.push_up_out);
		viewFlipper.setPersistentDrawingCache(ViewGroup.PERSISTENT_ANIMATION_CACHE);
		return viewFlipper;
	}
	
	/**
	 * 切换是左进右出
	 * @param context
	 * @return
	 */
	public static ViewAnimator createViewAnimleftInRightOut(Context context){
		ViewAnimator va = new ViewAnimator(context);
		va.setInAnimation(context, 
				android.R.anim.slide_in_left);
		va.setOutAnimation(context, 
				android.R.anim.slide_out_right);
		va.setAnimateFirstView(true);
		return va;
	}
	
	/**
	 * 创建加载 进程的图片
	 * @param context
	 * @param parentView : 父节点
	 * @return
	 */
	public static EmptyLoadingView makeEmptyLoadingView(Context context, 
			RelativeLayout parentView){
		return makeEmptyLoadingView(context, parentView, 
				RelativeLayout.CENTER_IN_PARENT);
	}
	
	/**
	 * 
	 * @param context
	 * @param parentView
	 * @param rule 加载图片的位置
	 * @return
	 */
	public static EmptyLoadingView makeEmptyLoadingView(Context context,
			RelativeLayout parentView, int rule){
		EmptyLoadingView loadingView = new EmptyLoadingView(context);
        loadingView.setGravity(Gravity.CENTER);
        RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(
        		RelativeLayout.LayoutParams.MATCH_PARENT,
        		RelativeLayout.LayoutParams.MATCH_PARENT);
        rlp.addRule(rule);
        parentView.addView(loadingView, rlp);
        return loadingView;
	}
	
	/**
	 * 创建普通的文字视图
	 * @param context
	 * @return
	 */
	public static TextView createCommonTextView(Context context){
		Resources res = context.getResources();
		TextView tv = new TextView(context);
		tv.setSingleLine(true);
		tv.setEllipsize(TruncateAt.END);
		tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 
				res.getInteger(R.integer.text_font_size_normal));
		tv.setTextColor(res.getColor(R.color.common_text_color));
//		Paint p = tv.getPaint();
//		p.setShadowLayer(1, 1, 1, 
//				res.getColor(R.color.common_text_shadow_color));
		return tv;
	}
	
	/**
	 * 小字体
	 * @param context
	 * @return
	 */
	public static TextView createSmallTextView(Context context){
		Resources res = context.getResources();
		TextView tv = new TextView(context);
		tv.setGravity(Gravity.CENTER);
//		tv.setSingleLine(true);
//		tv.setEllipsize(TruncateAt.END);
		tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 
				res.getInteger(R.integer.text_font_size_small));
		tv.setTextColor(res.getColor(R.color.text_color_white_80));
//		Paint p = tv.getPaint();
//		p.setShadowLayer(1, 1, 1, 
//				res.getColor(R.color.common_text_shadow_color));
		return tv;
	}
	
	private WLUIUtils(){
		
	}
}
