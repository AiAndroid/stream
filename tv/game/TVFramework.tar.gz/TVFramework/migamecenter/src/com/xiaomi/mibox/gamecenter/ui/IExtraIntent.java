package com.xiaomi.mibox.gamecenter.ui;

public interface IExtraIntent {
	String CATEGORY_ID = "com.xiaomi.mibox.gamecenter.category_id";
	String CATEGORY_NAME = "com.xiaomi.mibox.gamecenter.category_name";
	String SCREEN_SHOT_POS = "com.xiaomi.mibox.gamecenter.screen_shot_pos";
	
	/**
	 * 统计使用
	 */
	String FROM = "com.xiaomi.mibox.gamecenter.from";
	String POSITION = "com.xiaomi.mibox.gamecenter.position";
}
