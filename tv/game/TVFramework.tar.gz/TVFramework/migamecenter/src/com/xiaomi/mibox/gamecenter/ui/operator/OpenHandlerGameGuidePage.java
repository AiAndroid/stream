package com.xiaomi.mibox.gamecenter.ui.operator;

import android.content.Intent;

import android.graphics.Paint;
import android.os.Bundle;

import android.view.View;

import android.widget.Button;

import android.widget.RelativeLayout;
import android.widget.TextView;

import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.ui.PictureActivity;
import com.xiaomi.mibox.gamecenter.utils.ViewUtils;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;
import com.xiaomi.mitv.store.XiaomiUIHelper;

/**
 * 打开手柄游戏时的没有连接的手柄时的界面
 * @author liubiqiang
 *
 */
public class OpenHandlerGameGuidePage extends XiaomiUIHelper {
	private static final String TAG = "OpenHandlerGameGuidePage";
	private RelativeLayout mRootLayout;
	private TextView mHintTextView;
	private Button mConnectButton;
	private Button mBuyHandlerButton;
	
	public static final String BOND = "bonded";
	public static final String PACKAGE_NAME = "package_name";
	
	private String mPackageName;
	
	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		setupViews();
		
		mPackageName = getIntent().getStringExtra(PACKAGE_NAME);
		boolean hasConneted = getIntent().getBooleanExtra(BOND, false);
		if(hasConneted){
			mBuyHandlerButton.setVisibility(View.GONE);
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode != RESULT_OK) {
			finish();
			return;
		}
		if(REQUEST_CODE_CONNECT == requestCode){//连接成功
			WLUIUtils.openGame(this, mPackageName, TAG);
			finish();
		}
	}

    private void setupViews(){
        this.setContentView(R.layout.handler_game_guide_layout);
		mRootLayout = (RelativeLayout) this.findViewById(R.id.handler_game_guide_container);

		mHintTextView = (TextView) this.findViewById(R.id.game_guide_hint_textview);
		Paint paint = mHintTextView.getPaint();
		paint.setFakeBoldText(true);

		mConnectButton = (Button) this.findViewById(R.id.connect_button);
		mConnectButton.setOnClickListener(mConnectHandlerClickListener);
		
		mBuyHandlerButton = (Button) this.findViewById(R.id.connect_buy_button);
		mBuyHandlerButton.setOnClickListener(mBuyHandlerClickListener);
	}
	
	
	private View.OnClickListener mConnectHandlerClickListener = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent intent = new Intent(OpenHandlerGameGuidePage.this,
					AddHandlerDialog.class);
			OpenHandlerGameGuidePage.this.startActivityForResult(intent, 
					REQUEST_CODE_CONNECT);
		}
	};
	
	private View.OnClickListener mBuyHandlerClickListener = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			Intent intent = new Intent(OpenHandlerGameGuidePage.this, PictureActivity.class);
			intent.putExtra(PictureActivity.INFO, PictureActivity.PURCHASE_HANDLER_URL);
			OpenHandlerGameGuidePage.this.startActivity(intent);
			
			finish();
		}
	};

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(mRootLayout != null){
			ViewUtils.unbindDrawables(mRootLayout);
			mRootLayout = null;
		}
	}
}
