package com.xiaomi.mibox.gamecenter.bluetooth;


import java.util.Iterator;
import java.util.Set;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothInputDevice;

public final class BluetoothUtils {
	
	public static final int SEARCH_TIME = 30000;
	public static final int SEARCH_TIME_GAP = 10000;
	
	public static void enableBluetooth() {
		BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
		if (adapter != null && !adapter.isEnabled()) {
			adapter.enable();			
		}
	}
	
	public static void disableBluetooth() {
		BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
		if (adapter != null && adapter.isEnabled()) {
			adapter.disable();		
		}
	}
	
	public static void setName(String name) {
		BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
		if (adapter != null) {
			adapter.setName(name);
		}
	}
	
	public static boolean isDiscoverable() {
		BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
		if (adapter != null) {
			return adapter.getScanMode() == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE;
		}
		
		return false;
	}
	
    public static int getState() {
    	BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter != null) {
            return adapter.getState();
        }
        
        return 0;
    }
    
    public static boolean cancelDiscovering(){
    	BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
    	if (adapter != null && adapter.isDiscovering()) {
    		return adapter.cancelDiscovery();
        }
    	
    	return false;
    }
    
    public static boolean startDiscovering(){
    	BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
    	if(adapter != null){
    		if (adapter.isDiscovering()) {
        		return false;//adapter.cancelDiscovery();
            }
        	
    		//adapter.setScanMode(BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE, SEARCH_TIME);
    		// TODO 这个扫描后是否需要重置下
    		//adapter.setScanMode(BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE, SEARCH_TIME);
        	return adapter.startDiscovery();
    	}
    	
    	return false;
    }
    
    public static boolean createBond(BluetoothInputDevice mInput, BluetoothDevice device){
    	BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
    	if (adapter != null && adapter.isDiscovering()) {
    		adapter.cancelDiscovery();
        }
    	
    	return device.createBond();
    }
    
    public static boolean connectDevice(BluetoothInputDevice mInput, BluetoothDevice device){
    	BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
    	if (adapter != null && adapter.isDiscovering()) {
    		adapter.cancelDiscovery();
        }
		return mInput.connect(device);
    }
    
    /**
     * 是否是小米蓝牙手柄
     * @param device
     * @return
     */
    public boolean isXiaomiBluetoothHandler(BluetoothDevice device, BluetoothInputDevice inputDevice){
        if(WLUIUtils.isXiaomiBluetoothHandle(device)){
            return true;
        }else if(!IConfig.CAN_NOT_SUPPORT_NEW_BLUETOOTH){
            try{
                int vid = inputDevice.getHidVid(device);
                int hidPid = inputDevice.getHidPid(device);
                if(WLUIUtils.isXiaomiBluetoothHandleByHidPid(vid,hidPid)){
                    return true;
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        
        return false;
    }

	/**
	 * 是否有曾经配对成功的手柄
	 * @return
	 */
	public static boolean isMatchXiaomiBluetooth(){
		boolean match = false;
		BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (bluetoothAdapter == null) {
			return match;
		}
		if (!bluetoothAdapter.isEnabled()) {
			return match;
		}
		Set<BluetoothDevice> devices = bluetoothAdapter.getBondedDevices();
		for (Iterator<BluetoothDevice> iterator = devices.iterator(); iterator.hasNext();) {
			BluetoothDevice device = iterator.next();
			if (WLUIUtils.isXiaomiBluetoothHandle(device)) {
				match = true;
				break;
			}
		}
		return match;
	}
}
