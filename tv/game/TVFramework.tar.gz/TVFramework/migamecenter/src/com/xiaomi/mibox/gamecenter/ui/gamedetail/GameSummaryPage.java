package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.data.LocalAppManager;
import com.xiaomi.mibox.gamecenter.data.LocalAppInfo;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mibox.gamecenter.utils.ViewUtils;
import com.xiaomi.mitv.app.view.TitleBar;
import com.xiaomi.mitv.store.XiaomiUIHelper;

import java.util.Calendar;

/**
 * 游戏全部简介页面
 * @author liubiqiang
 *
 */
public class GameSummaryPage extends XiaomiUIHelper {

    protected RelativeLayout mRootView;
    private ScrollView mScrollView;
    
    private LinearLayout mUpdateLayout;
    private TextView mCurrentViewView;
    private TextView mUpgradeVersionView;
    private TextView mUpgradeDateTimeView;
    private TextView mDeveloperNameView;
    
    private TextView mChangeLogView;
    
    private TextView mSummaryView;
    
    private LinearLayout mCurrentUpdateLayout;
    private TextView mCurrentChangeLogView;
    
    private String mGameId;
    private Bitmap mIconBitmap;
    
    public static final String ICON = "icon";
    private GameItem gameInfo;
    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        mGameId = getIntent().getStringExtra(Constants.GAME_ID);
        mIconBitmap = getIntent().getParcelableExtra(ICON);
        gameInfo    = (GameItem) getIntent().getSerializableExtra("item");
        setupViews();
        if(!TextUtils.isEmpty(mGameId)){
            if(gameInfo != null){
                mCurrentViewView.setText(getString(
                        R.string.format_current_version_title, 
                        gameInfo.ver.name));
                mUpgradeDateTimeView.setText(getString(
                        R.string.format_update_time_title,
                        formatTime(this,
                                gameInfo.times.updated)));
                mDeveloperNameView.setText(getString(
                        R.string.format_developer, gameInfo.vendor.name));
                
                mSummaryView.setText(Html.fromHtml(gameInfo.description));
                
                String changeLog = gameInfo.recent_change;
                if(TextUtils.isEmpty(changeLog)){
                    changeLog = getString(R.string.txt_no_change_log);
                }
                
                if(LocalAppManager.getManager().isUpdateable(gameInfo)){
                    mUpdateLayout.setVisibility(View.VISIBLE);
                    mChangeLogView.setText(changeLog);
                    
                    mUpgradeVersionView.setVisibility(View.VISIBLE);
                    mUpgradeVersionView.setText(getString(
                            R.string.format_upgrade_version_title,
                            gameInfo.ver.name));
                    
                    LocalAppInfo localAppInfo = LocalAppManager.getManager().getLocalAppInfo(
                            gameInfo.packagename);
                    if(localAppInfo != null){
                        mCurrentViewView.setText(getString(
                                R.string.format_current_version_title, 
                                localAppInfo.mVersionName));
                    }
                }else{
                    mCurrentUpdateLayout.setVisibility(View.VISIBLE);
                    mCurrentChangeLogView.setText(changeLog);
                }
            }
        }
        
        if(mIconBitmap != null){
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
                mRootView.setBackground(new BitmapDrawable(getResources(), mIconBitmap));
            else
                mRootView.setBackgroundDrawable(new BitmapDrawable(getResources(), mIconBitmap));
        }
    }

    private static final long BASE_STAMP_TIME = 10000000000L;
    public static String formatTime(Context context, long timeinMills){
        Calendar cal = Calendar.getInstance();
        if(timeinMills < BASE_STAMP_TIME){
            timeinMills *= 1000L;
        }
        cal.setTimeInMillis(timeinMills);
        return context.getResources().getString(R.string.format_upload_time, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH));
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        mIconBitmap = null;
        if(mRootView != null){
            ViewUtils.unbindDrawables(mRootView);
        }
    }

    private void setupViews(){

        setContentView(R.layout.game_summary_layout);
        mRootView = (RelativeLayout) this.findViewById(R.id.summary_container);

        TitleBar summary_title_bar = (TitleBar) mRootView.findViewById(R.id.summary_title_bar);
        summary_title_bar.setTitle(R.string.game_full_intro_title);

        mScrollView = (ScrollView) mRootView.findViewById(R.id.summary_scroller);
        mScrollView.setVerticalScrollBarEnabled(false);
        mScrollView.setSmoothScrollingEnabled(true);

        mCurrentViewView = (TextView) mRootView.findViewById(R.id.current_view);
        mUpgradeVersionView = (TextView) mRootView.findViewById(R.id.update_version_view);
        mUpgradeDateTimeView = (TextView) mRootView.findViewById(R.id.update_datetime_view);
        mDeveloperNameView = (TextView) mRootView.findViewById(R.id.developer_name_view);


        //更新titel
        //更新说明
        mUpdateLayout = (LinearLayout) mRootView.findViewById(R.id.update_layout);
        mChangeLogView = (TextView) mRootView.findViewById(R.id.summary_update_logview);
        mChangeLogView.setLineSpacing(20, 1.0f);

        mSummaryView = (TextView) mRootView.findViewById(R.id.summart_view);
        mSummaryView.setLineSpacing(20, 1.0f);

        mCurrentUpdateLayout = (LinearLayout) mRootView.findViewById(R.id.current_update_layout);
        mCurrentChangeLogView = (TextView) mRootView.findViewById(R.id.summary_current_update_logview);
    }

}
