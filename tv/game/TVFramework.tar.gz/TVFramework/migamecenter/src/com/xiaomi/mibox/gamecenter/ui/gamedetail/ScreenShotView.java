package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import android.os.Build;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.VolleyHelper;
import com.tv.ui.metro.model.Image;
import com.tv.ui.metro.model.ImageGroup;
import com.xiaomi.mibox.gamecenter.R;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

/**
 * 屏幕截图控件
 * @author mengshu
 * @since 2013-11-27
 *
 */
public class ScreenShotView extends RelativeLayout {

	private ImageView mScreenShotImageView;
	private ImageView mVideoHintView;
	private ImageGroup mScreenShot;

	public static String CDN_THUMB_HEIGHT = "w432";//432比较接近405的缩略图 CDN 尺寸
    private int SCREEN_WIDTH;
    private int SCREEN_HEIGHT;
	
//	enum ScreenShotType {
//		THUMB, SHOT
//	}
//	private ScreenShotType mType;
	
	public ScreenShotView(Context context) {
		super(context);

        SCREEN_WIDTH  = getResources().getDisplayMetrics().widthPixels;//1920
        SCREEN_HEIGHT = getResources().getDisplayMetrics().heightPixels;//1920
        init(context);
	}
	
	public ImageGroup screenShot(){
		return mScreenShot;
	}
	
	public ImageView screenShotImageView(){
		return mScreenShotImageView;
	}
	
	public void bindThumbData(ImageGroup screenShot){
//		mType = ScreenShotType.THUMB;
		mScreenShot = screenShot;
		if(null == screenShot){
			mScreenShotImageView.setBackgroundResource(R.drawable.icon_screenshot);
			mVideoHintView.setVisibility(View.GONE);
		}else{
            VolleyHelper.getInstance(getContext()).getImageLoader().get(screenShot.thumbnail().url,  ImageLoader.getImageListener(mScreenShotImageView, R.drawable.icon_screenshot, R.drawable.icon_screenshot));
			if(ScreenShot.TYPE_VIDEOS.equals(screenShot.thumbnail().type)){
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
				    mVideoHintView.setBackground(getResources().getDrawable(R.drawable.video_thumb));
                else
                    mVideoHintView.setBackgroundResource(R.drawable.video_thumb);

				mVideoHintView.setVisibility(View.VISIBLE);
			}else{
				mVideoHintView.setVisibility(View.GONE);
			}
		}
	}

	public void bindScreenShotData(final ImageGroup screenShot){
//		mType = ScreenShotType.SHOT;
		mScreenShot = screenShot;
		if(null == screenShot){
			mScreenShotImageView.setImageResource(R.drawable.icon_screenshot);//TODO 唯空图 需要放缩 否则 MI标会被拉伸
			mVideoHintView.setVisibility(View.GONE);
		}else{

            VolleyHelper.getInstance(getContext()).getImageLoader().get(screenShot.thumbnail().url,  new ImageLoader.ImageListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    mScreenShotImageView.setImageResource(R.drawable.icon_screenshot);
                }

                @Override
                public void onResponse(ImageLoader.ImageContainer response, boolean isImmediate) {
                    if (response.getBitmap() != null) {
                        mScreenShotImageView.setImageBitmap(response.getBitmap());
                        VolleyHelper.getInstance(getContext()).getImageLoader().get(screenShot.screenshot().url, ImageLoader.getImageListener(mScreenShotImageView, 0, 0));

                    } else {
                        mScreenShotImageView.setImageResource( R.drawable.icon_screenshot);
                    }
                }
            });
			
			if(ScreenShot.TYPE_VIDEOS == screenShot.thumbnail().type){
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
				    mVideoHintView.setBackground(getResources().getDrawable(R.drawable.video_screen_shot));
                else
                    mVideoHintView.setBackgroundDrawable(getResources().getDrawable(R.drawable.video_screen_shot));

				mVideoHintView.setVisibility(View.VISIBLE);
			}else{
				mVideoHintView.setVisibility(View.GONE);
			}
		}
	}
	
	private void init(Context context){
		RelativeLayout.LayoutParams rlp;
		
		mScreenShotImageView = new ImageView(context);
		rlp = new RelativeLayout.LayoutParams(
				RelativeLayout.LayoutParams.MATCH_PARENT,
				RelativeLayout.LayoutParams.MATCH_PARENT);
		this.addView(mScreenShotImageView, rlp);
		
		mVideoHintView = new ImageView(context);
		mVideoHintView.setVisibility(View.GONE);
		rlp = new RelativeLayout.LayoutParams(
				RelativeLayout.LayoutParams.WRAP_CONTENT,
				RelativeLayout.LayoutParams.WRAP_CONTENT);
		rlp.addRule(RelativeLayout.CENTER_IN_PARENT);
		this.addView(mVideoHintView, rlp);
	}
}
