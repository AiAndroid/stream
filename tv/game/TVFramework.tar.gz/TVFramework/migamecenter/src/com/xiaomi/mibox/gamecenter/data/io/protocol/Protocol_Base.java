package com.xiaomi.mibox.gamecenter.data.io.protocol;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.zip.GZIPOutputStream;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.StringEntity;
import org.json.JSONException;
import org.json.JSONObject;

import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.MiboxGamecenterApplication;
import com.xiaomi.mibox.gamecenter.data.io.Connection.NetworkError;
import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;

import android.content.Context;
import android.net.http.AndroidHttpClient;
import android.text.TextUtils;
import android.util.Log;

/**
 * 协议基本架构
 * 
 * @author smokelee
 * 
 */
abstract class Protocol_Base<T> {
	protected Context ctx;

	protected T response;

	protected HashMap<String, String> param = new HashMap<String, String>();

	public NetworkError execute() {
		String j = prepare();
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		NetworkError err = request(bos, j);
		if (err != NetworkError.OK) {
			return err;
		}
		err = parserResponse(bos.toByteArray());
		return err;
	}

	abstract String prepare();

	abstract URL getUrl();

	abstract Protocol_Method getMethod();

	abstract NetworkError parserResponse(byte[] data);

	public abstract T getResponse();

	Protocol_Base(Context ctx) {
		this.ctx = ctx;
	}

	private NetworkError request(OutputStream outputStream, String param) {
		if (getUrl() == null) {
			return NetworkError.URL_ERROR;
		}

		if (Thread.currentThread() == MiboxGamecenterApplication.getInstance()
				.getMainLooper().getThread()) {
			throw new IllegalStateException(
					"Http Connection Use Main Thread!!!!!!!");
		}

		if (!GamecenterUtils.isConnected(ctx)) {
			return NetworkError.NETWORK_ERROR;
		}
		URL url = getUrl();
		HttpResponse response = null;
		AndroidHttpClient hc = null;
		try {

			hc = AndroidHttpClient.newInstance("");
			HttpRequestBase request = null;

			if (getMethod() == Protocol_Method.GET) {
				String query = url.getQuery();
				String urlString = url.toString();
				if (TextUtils.isEmpty(query)) {
					urlString = urlString + "?" + param;
				} else {
					urlString = urlString + "&" + param;
				}
				url = new URL(urlString);
				request = new HttpGet(url.toString());
			} else {
				HttpPost post = new HttpPost(url.toString());
				if (hasCookie()) {
					post.setHeader("Cookie", cookie());
				}
				/**
				 * post 接口必须如此设置Content-Type。否则，服务器端会有问题。 晓菲的解释：Content-Type 设置为
				 * application/x-www-form-urlencoded，php会按照url参数解析。
				 * 晓菲说不设置Content-Type应该也可以。
				 */
				post.setHeader("Content-Type",
						"application/x-www-form-urlencoded;charset=utf-8");
				if (compress()) {
					post.setHeader("Content-Encoding", "gzip");
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					GZIPOutputStream gout = new GZIPOutputStream(bos);
					gout.write(param.getBytes("UTF-8"));
					gout.close();
					post.setEntity(new ByteArrayEntity(bos.toByteArray()));
					bos.close();
				} else {
					post.setEntity(new StringEntity(param, "UTF-8"));
				}

				request = post;
			}
			response = hc.execute(request);

		} catch (Exception e) {
			try {
				hc.close();
			} catch (Exception ee) {
			}
			e.printStackTrace();
			return NetworkError.UNKNOWN_ERROR;
		}

		BufferedInputStream bis = null;
		try {
			NetworkError code = handleResponseCode(response.getStatusLine()
					.getStatusCode());
			// Logger.error("Protocol "+this.getClass() +
			// "Result = "+response.getStatusLine().getStatusCode());
			if (code == NetworkError.OK) {
				if (outputStream != null) {
					try {
						bis = new BufferedInputStream(response.getEntity()
								.getContent(), 8192);
						byte[] buffer = new byte[1024];
						int count;
						while ((count = bis.read(buffer, 0, 1024)) > 0) {
							outputStream.write(buffer, 0, count);
						}
						outputStream.flush();
					} catch (Exception e) {
						// 读取文件流的过程中异常有可能造成文件损坏，页面读取时造成ANR
						return NetworkError.IO_ERROR;
					} finally {
						if (bis != null) {
							bis.close();
						}
					}
				}
			}
			return code;
		} catch (IOException e) {
			Log.e("", "Connection I/O Exception :", e);
			return NetworkError.IO_ERROR;
		} finally {
			if (bis != null) {
				try {
					bis.close();
				} catch (IOException e) {
					if (IConfig.DEBUG)
						e.printStackTrace();
				}
			}
			try {
				hc.close();
			} catch (Exception ee) {
			}

		}
	}

	private NetworkError handleResponseCode(int code) {
		if (code == HttpURLConnection.HTTP_OK) {
			return NetworkError.OK;
		} else {
			return NetworkError.IO_ERROR;
		}
	}

	void add_base_param() {
		HashMap<String, String> baseParam = GamecenterUtils
				.getRequestBaseParam(ctx, getMethod() == Protocol_Method.GET);
		param.putAll(baseParam);
	}

	JSONObject param_to_json() {
		JSONObject jo = new JSONObject();
		Set<Entry<String, String>> set = param.entrySet();
		for (Entry<String, String> e : set) {
			if (TextUtils.isEmpty(e.getValue())) {
				continue;
			}
			try {
				jo.put(e.getKey(), e.getValue());
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
		}
		return jo;
	}

	String param_to_url_param() {
		StringBuffer sb = new StringBuffer();
		Set<Entry<String, String>> set = param.entrySet();
		for (Entry<String, String> e : set) {
			String value = e.getValue();
			if (!TextUtils.isEmpty(value)) {
				sb.append(e.getKey()).append("=").append(value).append("&");
			}
		}
		sb.deleteCharAt(sb.length() - 1);
		return sb.toString();
	}

	boolean hasCookie() {
		return false;
	}

	String cookie() {
		return "";
	}

	boolean compress() {
		return false;
	}
}
