package com.xiaomi.mibox.gamecenter.account;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;

import com.xiaomi.xmsf.account.data.XiaomiUserInfo;

import android.content.Context;

/**
 * 小米账户信息的保存与读取
 * @author liubiqiang
 *
 */
public class UserInfoUtils {

	/**
	 * 将小米账户信息序列化保存到本地
	 * @param context
	 * @param userInfo
	 */
	public static void saveXiaomiUserInfo(Context context,
			XiaomiUserInfo userInfo){
		if(null == userInfo){
			return;
		}
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(new FileOutputStream(
					new File(context.getFilesDir()
							.getAbsoluteFile()
							+ File.separator
							+ XiaomiUserInfo.CFG_FILE_NAME)));
			oos.writeObject(userInfo);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * 
	 * @param context
	 * @return
	 */
	public static XiaomiUserInfo getXiaomiUserInfo(Context context){
		ObjectInputStream ois = null;
		XiaomiUserInfo userInfo = null;
		try {
			ois = new ObjectInputStream(new FileInputStream(
					new File(context.getFilesDir()
							.getAbsoluteFile()
							+ File.separator
							+ XiaomiUserInfo.CFG_FILE_NAME)));
			Object obj = ois.readObject();
			if (obj instanceof XiaomiUserInfo) {
				userInfo = (XiaomiUserInfo) obj;
			}
		} catch (StreamCorruptedException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (ois != null) {
				try {
					ois.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		return userInfo;
	}
	
	/**
	 * 
	 * @param context
	 */
	public static void reset(Context context){
		try{
			File file = new File(context.getFilesDir()
					.getAbsoluteFile()
					+ File.separator
					+ XiaomiUserInfo.CFG_FILE_NAME);
			if(file != null && file.exists()){
				file.delete();
			}
		}catch(Exception e){
			
		}
	}
}
