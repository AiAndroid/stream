package com.xiaomi.mitv.store;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Build;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.tv.ui.metro.DisplayItemActivity;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.account.LoginManager;
import com.xiaomi.mibox.gamecenter.utils.DrawableCache;
import com.xiaomi.mitv.store.utils.Utils;

/**
 * Created by liuhuadong on 9/16/14.
 */
public class XiaomiUIHelper extends DisplayItemActivity{

    protected ImageView mLeftMaskView;
    protected ImageView mRightMaskView;

    //request code
    public static final int REQUEST_CODE_CONNECT = 0x300;
    public static final int REQUEST_CODE_DISCONNECT = 0x301;

    //快速消失
    protected void maskDisappear(){
        if(mLeftMaskView != null && mRightMaskView != null){
            mLeftMaskView.setAlpha(0.0f);
            mRightMaskView.setAlpha(0.0f);
        }
    }

    //快速消失
    protected void maskQuickAppear(){
        if(mLeftMaskView != null && mRightMaskView != null){
            mLeftMaskView.setAlpha(1.0f);
            mRightMaskView.setAlpha(1.0f);
        }
    }

    //缓慢出现
    protected void maskAppear(){
        if(mLeftMaskView != null && mRightMaskView != null){
            ObjectAnimator ol = ObjectAnimator.ofFloat(mLeftMaskView, "alpha", 1.0f);
            ObjectAnimator or = ObjectAnimator.ofFloat(mRightMaskView, "alpha", 1.0f);
            AnimatorSet lineAnimator = new AnimatorSet();
            lineAnimator.playTogether(ol, or);
            lineAnimator.setDuration(800);
            lineAnimator.start();
        }
    }

    protected void addLeftMaskView(RelativeLayout rootView){
        mLeftMaskView = new ImageView(this);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
            mLeftMaskView.setBackground(DrawableCache.getInstance().loadByResId(R.drawable.mask_left));
        else
            mLeftMaskView.setBackgroundDrawable(DrawableCache.getInstance().loadByResId(R.drawable.mask_left));

        mLeftMaskView.setAlpha(0.0f);
        RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        rlp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        rootView.addView(mLeftMaskView, rlp);
    }

    protected void addRightMaskView(RelativeLayout rootView){
        mRightMaskView = new ImageView(this);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
            mRightMaskView.setBackground(DrawableCache.getInstance().loadByResId(R.drawable.mask_right));
        else
            mRightMaskView.setBackgroundDrawable(DrawableCache.getInstance().loadByResId(R.drawable.mask_right));

        mRightMaskView.setAlpha(0.0f);
        RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        rlp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        rlp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        rootView.addView(mRightMaskView, rlp);
    }

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);

        if(!LoginManager.getLoginManager().userCancelStatus()){
            LoginManager.getLoginManager().loginIfNeed(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Utils.showStatusBar(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Utils.hideStatusBar(this);
    }

    @Override
    public void onTrimMemory(int level) {
        DrawableCache.getInstance().release();
        super.onTrimMemory(level);
    }

    @Override
    public void onStart() {
        super.onStart();
        maskAppear();
    }

    @Override
    public void onStop() {
        super.onStop();
        maskDisappear();
    }
}

