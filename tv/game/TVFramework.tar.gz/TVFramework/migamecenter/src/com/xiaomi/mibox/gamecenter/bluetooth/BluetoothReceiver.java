package com.xiaomi.mibox.gamecenter.bluetooth;

import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


public class BluetoothReceiver extends BroadcastReceiver {
	
	private OnBluetoothHandlerListener mOnBluetoothHandlerListener;
	
	public BluetoothReceiver(OnBluetoothHandlerListener listener){
		super();
		mOnBluetoothHandlerListener = listener;
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		if (null == intent){
			return;
		}
		String action = intent.getAction();
		BluetoothDevice device = null;

		if("android.bluetooth.input.profile.action.HID_INFO".equals(action)){
			device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
			if(null == device){
				return;
			}
			if (WLUIUtils.isXiaomiBluetoothHandle(device)){
				if(mOnBluetoothHandlerListener != null){
					mOnBluetoothHandlerListener.connected(device);
				}
			}else{
				int pid = intent.getIntExtra("android.bluetooth.BluetoothInputDevice.extra.EXTRA_DEVICE_PID", -1);
				int vid = intent.getIntExtra("android.bluetooth.BluetoothInputDevice.extra.EXTRA_DEVICE_VID", -1);
				if(WLUIUtils.isXiaomiBluetoothHandleByHidPid(vid,pid)){
					if(mOnBluetoothHandlerListener != null){
						mOnBluetoothHandlerListener.connected(device);
					}
				}
			}
		}else if ("android.bluetooth.input.profile.action.CONNECTION_STATE_CHANGED".equals(action)) {
			device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
			if(device != null){
				int newState = intent.getIntExtra(BluetoothProfile.EXTRA_STATE,0);
				if(newState == BluetoothProfile.STATE_DISCONNECTED){
					if(mOnBluetoothHandlerListener != null){
						mOnBluetoothHandlerListener.disconnected(device);
					}
				}
			}
		}
	}
}
