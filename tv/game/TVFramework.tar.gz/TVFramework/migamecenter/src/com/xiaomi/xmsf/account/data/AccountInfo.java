package com.xiaomi.xmsf.account.data;

public class AccountInfo {

    private String userId;

    private String passToken;

    private String serviceToken;

    private String security;

    private String psecurity;

    /**
     * constructor for account info without service token.
     * @param userId user id, e.g. 110000
     * @param passToken pass token returned by server
     * @param psecurity AES key got from server after login.
     *                  This is paired with passToken for every login procedure.
     */
    public AccountInfo(String userId, String passToken, String psecurity) {
        this.userId = userId;
        this.passToken = passToken;
        this.psecurity = psecurity;
    }

    public AccountInfo(String userId, String passToken, String serviceToken, String security, String psecurity) {
        this.userId = userId;
        this.passToken = passToken;
        this.serviceToken = serviceToken;
        this.security = security;
        this.psecurity = psecurity;
    }

    public String getUserId() {
        return userId;
    }

    public String getServiceToken() {
        return serviceToken;
    }

    public String getPassToken() {
        return passToken;
    }

    public String getSecurity() {
        return security;
    }

    public String getPsecurity() {
        return psecurity;
    }

    @Override
    public String toString() {
        return "AccountInfo{" +
                "userId='" + userId + '\'' +
                ", security='" + security + '\'' +
                '}';
    }
}
