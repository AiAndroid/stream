package com.xiaomi.mibox.gamecenter.data.io;

import java.io.ByteArrayOutputStream;

class MemoryResetableOutputStream extends ResetableOutputStream {

    public MemoryResetableOutputStream(ByteArrayOutputStream outputStream) {
        super(outputStream);
    }

    @Override
    public void reset() {
        ((ByteArrayOutputStream)mOutputStream).reset();
    }
}
