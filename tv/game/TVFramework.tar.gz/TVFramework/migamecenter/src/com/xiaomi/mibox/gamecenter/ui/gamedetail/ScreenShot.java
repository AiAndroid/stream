package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import android.os.Parcel;
import android.os.Parcelable;

public class ScreenShot implements Comparable<ScreenShot>, Parcelable {
	public static final String TYPE_SCREENSHOTS = "image";
	public static final String TYPE_VIDEOS      = "video";

	public int type;
	public String url;
	public String action;
	
	   public static final Parcelable.Creator<ScreenShot> CREATOR 
       = new Parcelable.Creator<ScreenShot>() {

           @Override
           public ScreenShot createFromParcel(Parcel source) {
               ScreenShot screenShot = new ScreenShot();
               screenShot.type = source.readInt();
               screenShot.url = source.readString();
               screenShot.action = source.readString();
               return screenShot;
           }

           @Override
           public ScreenShot[] newArray(int size) {
               return new ScreenShot[size];
           }
       
   };
	
	@Override
	public int compareTo(ScreenShot another) {
		if(null == another){
			return -1;
		}else{
			if(another.type > this.type){
				return 1;
			}else if(another.type < this.type){
				return -1;
			}else{
				return 0;
			}
		}
	}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(type);
        dest.writeString(url);
        dest.writeString(action);
    }
}
