package com.xiaomi.mibox.gamecenter.ui.operator;

import com.xiaomi.mibox.gamecenter.data.MainHandler;
import com.xiaomi.mibox.gamecenter.R;

import com.xiaomi.mibox.gamecenter.utils.ViewUtils;
import com.xiaomi.mibox.gamecenter.utils.WLUIUtils;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;

import android.os.Bundle;
import android.util.SparseArray;

import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.xiaomi.mitv.store.XiaomiUIHelper;

/**
 * 对已连接上的手柄的操作选择
 * @author liubiqiang
 *
 */
public class ConnectedHanlderOperatorActivity extends XiaomiUIHelper {

    private RelativeLayout mRootLayout;
    private LinearLayout mChoiceLayout;
    private ImageView mFocusedView;
    
    private int mCurrPos = 1;
    private TextView mCurrentSelectedView;
    private SparseArray<TextView> mViewLists = new SparseArray<TextView>(2);
    private int[] mLocation = new int[2];
//    private int[] mParentLayoutLocation = new int[2];
    private boolean mAnimatorFinish = true;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupViews();
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(mRootLayout != null){
            ViewUtils.unbindDrawables(mRootLayout);
        }
    }

    private void setCurrentView(TextView currentSelectedView){
        if(null == currentSelectedView){
            return;
        }
        
        mAnimatorFinish = false;
        
        currentSelectedView.getLocationInWindow(mLocation);
//        mChoiceLayout.getLocationInWindow(mParentLayoutLocation);

        int diffX = 26;//因为焦点图有边框有阴影
        int diffY = 18;
        if(1 == mCurrPos){
            diffY += 1;
        }
        int x = mLocation[0] - diffX;
        int y = mLocation[1] - diffY;
        
        if(null == mCurrentSelectedView){
            mFocusedView.setX(x);
            mFocusedView.setY(y);
            mFocusedView.setVisibility(View.VISIBLE);
            mAnimatorFinish = true;
        }else{
            mFocusedView.setVisibility(View.VISIBLE);
            AnimatorSet lineAnimator = new AnimatorSet();
            ObjectAnimator oz = ObjectAnimator.ofFloat(mFocusedView, 
                        "x", x);
            ObjectAnimator ow = ObjectAnimator.ofFloat(mFocusedView, 
                        "y", y);
            lineAnimator.playTogether(oz,ow);
            lineAnimator.setDuration(60);
            lineAnimator.addListener(new AnimatorListener(){

                @Override
                public void onAnimationStart(Animator animation) {
                    
                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    mAnimatorFinish = true;
                }

                @Override
                public void onAnimationCancel(Animator animation) {
                    mAnimatorFinish = true;
                }

                @Override
                public void onAnimationRepeat(Animator animation) {
                    
                }
            });
            lineAnimator.start();
        }
        mCurrentSelectedView = currentSelectedView;
    }
    
    private OnKeyListener mOnKeyListener = new OnKeyListener(){

        @Override
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if(!mAnimatorFinish){//动画未结束
                return true;
            }
            
            if(KeyEvent.ACTION_DOWN == event.getAction()){
                TextView currentSelectedView = null;
                if(KeyEvent.KEYCODE_DPAD_DOWN == keyCode){
                    if(0 == mCurrPos){
                        mCurrPos = 1;
                        currentSelectedView = mViewLists.get(mCurrPos);
                        WLUIUtils.playSoundEffect(currentSelectedView, keyCode);
                        setCurrentView(currentSelectedView);
                    }else{
                        currentSelectedView = mViewLists.get(mCurrPos);
                        WLUIUtils.playSoundEffect(currentSelectedView, 
                                WLUIUtils.KEYCODE_ERROR);
                    }
                    return true;
                }
                
                if(KeyEvent.KEYCODE_DPAD_UP == keyCode){
                    if(1 == mCurrPos){
                        mCurrPos = 0;
                        currentSelectedView = mViewLists.get(mCurrPos);
                        WLUIUtils.playSoundEffect(currentSelectedView, keyCode);
                        setCurrentView(currentSelectedView);
                    }else{
                        currentSelectedView = mViewLists.get(mCurrPos);
                        WLUIUtils.playSoundEffect(currentSelectedView, 
                                WLUIUtils.KEYCODE_ERROR);
                    }
                    return true;
                }
                
                if(KeyEvent.KEYCODE_ENTER == keyCode
                        || KeyEvent.KEYCODE_DPAD_CENTER == keyCode
                        || KeyEvent.KEYCODE_BUTTON_A == keyCode){//A键=遥控器的确定
                    MainHandler.getInstance().postDelayed(new Runnable(){
                        @Override
                        public void run() {
                            Intent intent = new Intent();
                            intent.putExtra("index", mCurrPos);
                            setResult(RESULT_OK,intent);
                            finish();
                        }
                    }, 200);
                    return true;
                }
            }
            return false;
        }
    };
    
    @Override
    public void overridePendingTransition(int enterAnim, int exitAnim) {
        super.overridePendingTransition(0, R.anim.switcher_fade_out);
    }
    
    private View.OnFocusChangeListener mFocusedChangeListener = new View.OnFocusChangeListener(){

        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if(hasFocus){
                setCurrentView(mViewLists.get(mCurrPos));
            }else{
                if(mFocusedView != null){
                    mFocusedView.setVisibility(View.INVISIBLE);
                }
            }
        }
    };
    
    private void setupViews(){
        this.setContentView(R.layout.connected_handler_layout);
        mRootLayout = (RelativeLayout) this.findViewById(R.id.connected_handler_container);

        mChoiceLayout = (LinearLayout) this.findViewById(R.id.choice_layout);
        mChoiceLayout.setOnKeyListener(mOnKeyListener);
        mChoiceLayout.setOnFocusChangeListener(mFocusedChangeListener);

        TextView textView = (TextView) this.findViewById(R.id.cancel_connect_textview);
        int key = 0;
        mViewLists.put(key, textView);
        key++;

        textView = (TextView) this.findViewById(R.id.cancel_textview);
        mViewLists.put(key, textView);
        key++;

        mFocusedView = (ImageView) this.findViewById(R.id.connect_foucus_view);
    }
}
