package com.xiaomi.mibox.gamecenter.ui.gamedetail;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.data.MainHandler;
import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mitv.store.XiaomiUIHelper;

/**
 * 游戏大截图
 * @author liubiqiang
 *
 */
public class ScreenShotActivity extends XiaomiUIHelper implements OnSeekBarListener {
    
    public static final String SCREEN_SHOTS = "screen_shots";
    public static final String SELECTED_POS = "selected_position";
    public static final String CDN = "cdn";
    
    private GameItem mGame;
    private int mSelectedPos;
    
    private RelativeLayout mRootView;
    private ScreenShotListView mScreenShotListView;
    private QSeekBarPositionView mSeekBarPositionView;
    
    private ImageView mLeftArrowView;
    private ImageView mRightArrowView;
    
    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);

        mGame = (GameItem) getIntent().getSerializableExtra("item");
        mSelectedPos = getIntent().getIntExtra(SELECTED_POS, 0);
        
        setupViews();
        
        mScreenShotListView.setOnSeekBarListener(this);
        
        mScreenShotListView.bindScreenShots(mGame.screenshots);
        if(mSelectedPos > 0){//不让用户看到滚动的效果
            mScreenShotListView.setAlpha(0.0f);
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        
        if(mSelectedPos > 0){
            MainHandler.getInstance().postDelayed(new Runnable() {
                @Override
                public void run() {
                    mScreenShotListView.setSelectedPos(mSelectedPos);
                    mSelectedPos = -1;
                    mScreenShotListView.setAlpha(1.0f);
                }
            }, 200);
        }
    }

    private void setupViews(){
        this.setContentView(R.layout.screen_shot_layout);
        mRootView = (RelativeLayout) this.findViewById(R.id.screen_shot_container);
        mScreenShotListView = (ScreenShotListView) this.findViewById(R.id.screen_shot_listview);
        
        mLeftArrowView = (ImageView) this.findViewById(R.id.left_arrow);
        mRightArrowView = (ImageView) this.findViewById(R.id.right_arrow);
        mSeekBarPositionView = (QSeekBarPositionView) this.findViewById(R.id.seekbar_postion_view);
    }

    @Override
    public void seerBarTotal(int total) {
        mSeekBarPositionView.seerBarTotal(total);
    }

    @Override
    public void seekBarPositionChanged(int newPos) {
        mSeekBarPositionView.seekBarPositionChanged(newPos);
        if(mScreenShotListView.isFirst()){
            mLeftArrowView.setAlpha(0.0f);
        }else{
            mLeftArrowView.setAlpha(1.0f);
        }
        
        if(mScreenShotListView.isLast()){
            mRightArrowView.setAlpha(0.0f);
        }else{
            mRightArrowView.setAlpha(1.0f);
        }
    }
}
