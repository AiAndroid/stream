package com.xiaomi.mibox.gamecenter.data;

import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;

import android.text.TextUtils;

public class LocalAppInfo {
    public String mPackageName = "";
    public String mDisplayName = "";
    public int    mVersionCode = 0;
    public String mVersionName = "";
    public String mSignature   = "";
    public String mSourceDir   = "";
    public String mSourceMD5   = "";
    public boolean mIsSystem   = false;
    
    private LocalAppInfo() {
    }
    
    public static LocalAppInfo get(String packageName) {
    	LocalAppInfo app = new LocalAppInfo();
    	app.mPackageName = packageName;
    	return app;
    }
    
    public String getSourceMD5() {
    	if (TextUtils.isEmpty(mSourceDir)) {
    		return null;
    	}
    	
        if (TextUtils.isEmpty(mSourceMD5)) {
        	return GamecenterUtils.getFileMD5(mSourceDir);
        }else {
        	return mSourceMD5;
        }
    }

}
