package com.xiaomi.mibox.gamecenter.data.download;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationStatus;
import com.xiaomi.mibox.gamecenter.utils.Client;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;

import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.content.Context;
import android.database.Cursor;
import android.os.Environment;
import android.provider.Downloads;
import com.xiaomi.mitv.store.utils.Utils;

public class Decompression {
	static final int BUFFER = 2048;

	static int unZip(Context ctx, OperationSession session) {
		int status = 0;
		GameItem gi = Utils.getGameItem(ctx, session.getGameId());
		String packageName = gi.packagename;
		String unZipDir = null;
        if(gi.assets != null && gi.assets.size() > 0 )
            unZipDir = gi.assets.get(0).local_dir;

		long dataSize = Integer.valueOf(gi.sizes.packaged);
		String zipName = getZipName(ctx, session);//zipName=路径+zip包名
		if(!sdSpaceEnough(dataSize)){//SD卡空间不够用
			GamecenterUtils.showSDCardSpaceNotEnoughFailNotification(gi);
			return XMDownloadManager.REASON_INSTALL_UNZIPPING_INSUFFICIENT_STORAGE;
		}
		try {
			// 先判断目标文件夹是否存在，如果不存在则新建，如果父目录不存在也新建
			File f = new File(unZipDir + "/" + packageName);
			if(f.exists()){
				delFolder(unZipDir + "/" + packageName);
			}
			f.mkdirs();
			//计算解压百分比用
			long unZippedSize = 0;
			long zipSize = calcZipSize(zipName);
			int unZipRadio = 0;

			BufferedOutputStream bos = null;
			BufferedInputStream bis = null;
			ZipEntry entry;
			ZipFile zipfile = new ZipFile(zipName);
			Enumeration<?> emu = zipfile.entries();
			
			long lastunZipRadio = 0;
			session.setRadio(unZipRadio);
			while (emu.hasMoreElements()) {
				entry = (ZipEntry) emu.nextElement();//com.lextel.ALovePhone/
				
				if(entry.isDirectory()){
					new File(unZipDir + "/" + entry.getName()).mkdirs();
					continue;
				}
				
				bis = new BufferedInputStream(zipfile.getInputStream(entry));
				
				File file = new File(unZipDir + "/" + entry.getName());
				File parent = file.getParentFile();
				if(parent !=null && (!parent.exists())){
					parent.mkdirs();
				}
				FileOutputStream fos = new FileOutputStream(file);
				bos = new BufferedOutputStream(fos, BUFFER);
				
				int count;
				byte data[] = new byte[BUFFER];
				
				while ((count = bis.read(data, 0, BUFFER)) != -1) {
					bos.write(data, 0, count);
					
					unZippedSize += count;
					if (zipSize > 0 && unZippedSize > 0) {
						unZipRadio = (int) (unZippedSize * 100 / zipSize);
					}else if((zipSize == 0 && unZippedSize == 0)){
						unZipRadio = 100;
					}
					if(unZipRadio - lastunZipRadio >= 5|| unZipRadio == 100) {
						if (session.getStatus() == OperationStatus.Remove) {
							break;
						}
						lastunZipRadio = unZipRadio;
						session.setRadio(unZipRadio);
					}
				}
				bos.flush();
				bos.close();
				bis.close();

			}
			zipfile.close();
		} catch (Exception e) {
			status = XMDownloadManager.REASON_INSTALL_UNZIPPING_INSUFFICIENT_STORAGE;
		}
		return status;
	}

	//删除文件夹
	//param folderPath 文件夹完整绝对路径
	public static void delFolder(String folderPath) {
     try {
        delAllFile(folderPath); //删除完里面所有内容
        String filePath = folderPath;
        filePath = filePath.toString();
        File myFilePath = new File(filePath);
        myFilePath.delete(); //删除空文件夹
     } catch (Exception e) {
       e.printStackTrace(); 
     }
	}

	//删除指定文件夹下所有文件
	//param path 文件夹完整绝对路径
	private static boolean delAllFile(String path) {
       boolean flag = false;
       File file = new File(path);
       if (!file.exists()) {
         return flag;
       	 }
       if (!file.isDirectory()) {
         return flag;
         }
       String[] tempList = file.list();
       File temp = null;
       for (int i = 0; i < tempList.length; i++) {
          if (path.endsWith(File.separator)) {
             temp = new File(path + tempList[i]);
          } else {
              temp = new File(path + File.separator + tempList[i]);
          }
          if (temp.isFile()) {
             temp.delete();
          }
          if (temp.isDirectory()) {
             delAllFile(path + "/" + tempList[i]);//先删除文件夹里面的文件
             delFolder(path + "/" + tempList[i]);//再删除空文件夹
             flag = true;
          }
       }
       return flag;
     }
   
   //计算压缩包里所有文件大小的总和
    public static long calcZipSize(String fileName) {
        long size = 0;
        ZipFile zipfile = null;
        try {
            ZipEntry entry;
            zipfile = new ZipFile(fileName);
            Enumeration<?> emu = zipfile.entries();

            while (emu.hasMoreElements()) {
                entry = (ZipEntry) emu.nextElement();
                if (entry.isDirectory()) {
                    continue;
                } else {
                    size += entry.getSize();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(zipfile != null){
                try {
                    zipfile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return size;
    }
   
 	/**
 	 * 从数据库读取zip名
 	 * private String getZipName(OperationSession ops)
 	 * @return
 	 */
 	private static String getZipName(Context ctx, OperationSession ops){
 		String ret = null;
 		DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
 		Query query = new Query();
 		query.setFilterById(ops.getDataDownloadId());
 		Cursor cursor = dm.query(query);
 		if(cursor == null || !cursor.moveToFirst())
 		{
 			cursor.close();
 			return null;
 		}
 		int filePathColumnIndex = -1;
 		String filePathColumnName;
 		try {
 			if (Client.isLaterThanHoneycomb()) { // 这里不要判断MIUI，只判断Android版本
 				filePathColumnName = DownloadManager.COLUMN_LOCAL_FILENAME;
 			} else {
 				filePathColumnName = Constants.COLUMN_FILE_PATH;
 			}
 			filePathColumnIndex = cursor
 					.getColumnIndexOrThrow(filePathColumnName);
 		} catch (IllegalArgumentException e) {
 				e.printStackTrace();
 			try {
 				filePathColumnIndex = cursor.getColumnIndexOrThrow(Downloads.Impl._DATA);
 			} catch (Exception e2) {
 					e2.printStackTrace();
 				try {
 					filePathColumnIndex = cursor.getColumnIndexOrThrow("local_uri");
 				} catch (Exception e3) {
 						e3.printStackTrace();
 				}
 			}
 		}
 		// 该下载任务可能失败或者成功
 		if (filePathColumnIndex != -1) {
 			ret = cursor.getString(filePathColumnIndex);
 		}
 		return ret;
 	}
    
 	
 	/**
 	 * 检查SD卡空间是否足够解压zip文件
 	 * SD卡上只要有比文件大小多100MB的空间即可
 	 * @return
 	 */
 	public static boolean sdSpaceEnough(long dataSize){
 		if(Environment.getExternalStorageDirectory().canWrite()){
             String dataPath = Environment.getExternalStorageDirectory().getAbsolutePath();
             long needSpace = dataSize;
             long dataSpace = GamecenterUtils.getDiskFreeSize(dataPath);
             needSpace *= 1.5;
//             needSpace *= 400000;
 	        if (dataSpace < needSpace) {
 	            return false;
 	        }
     	}
     	return true;
 	}
 		
}
