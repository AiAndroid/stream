package com.xiaomi.mitv.store.game;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import com.tv.ui.metro.MainActivity;
import com.tv.ui.metro.model.Album;
import com.tv.ui.metro.model.DisplayItem;
import com.tv.ui.metro.model.Image;
import com.tv.ui.metro.model.Tabs;
import com.tv.ui.metro.view.MetroLayout;
import com.tv.ui.metro.view.RecommendCardView;
import com.tv.ui.metro.view.RecommendCardViewClickListenerFactory;
import com.tv.ui.metro.view.UserViewFactory;
import com.xiaomi.mibox.gamecenter.account.LoginManager;
import com.xiaomi.mibox.gamecenter.ui.view.BluetoothView;
import com.xiaomi.mibox.gamecenter.ui.view.UserView;
import com.xiaomi.mitv.store.network.GameTabsGsonLoader;
import com.xiaomi.mitv.store.utils.Utils;

import java.lang.reflect.Method;
import java.util.ArrayList;


public class GameMainActivity extends  MainActivity {
    private static final String TAG = GameMainActivity.class.getName();
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);     
        
        RecommendCardViewClickListenerFactory.getInstance().setFactory(new RecommendCardViewClickListenerFactory.ClickCreatorFactory() {
            @Override
            public View.OnClickListener getRecommendCardViewClickListener() {
                return mRecommendCardViewClickListener;
            }
        });

        //please call this
        UserViewFactory.getInstance().setFactory(new UserViewFactory.ViewCreatorFactory(){
            @Override
            public ArrayList<View> create(Context context) {
                ArrayList<View> views = new ArrayList<View>();
                views.add(new UserView(context));
                views.add(new BluetoothView(context));
                return  views;
            }

            @Override
            public int getPadding(Context context) {
                return getResources().getDimensionPixelSize(com.tv.ui.metro.R.dimen.user_view_padding);
            }
        });

        if(!LoginManager.getLoginManager().userCancelStatus()){
            LoginManager.getLoginManager().loginIfNeed(this);
        }
    }

    String ramdonVertical[] = {
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01Rv1BY9m8X/1a0fd9CEAMJVYo.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01plTuGi9Rp/U6bRNkCpwcXY6N.jpg",
            "http://file.market.xiaomi.com/download/Duokan/d8e9d013-d765-4674-b5e3-8bea2beb997a/dk985052_20140624145352_b720.jpg",
            "http://file.market.xiaomi.com/download/2bf/4a9be0bdaf96bd3a98429462200544968d7d405b/dk945743_20130418101653_b720.jpg",
            "http://file.market.xiaomi.com/download/fd0/7ac509d7004c23df410189d0fa2835a0708f4829/dk945744_20130503100756_b720.jpg",
            "http://file.market.xiaomi.com/download/Duokan/5808ebe6-6278-491b-a31c-2ee7f2999310/dk988007_20140916113943_b720.jpg",
    };

    String ramdonNormal[] = {
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01btrAPSCuG/Ru8aNsObQbLIUX.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01aY0CmtnnE/kLQHeevBERJ1cz.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01mmA2IUiwm/w66Kb0jpYClVbc.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01MdlPH1E0j/MXXcMVooBJHo7w.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01wDXNZbAI1/UF4Zenx7Hje93B.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01x2hrpjeAB/7OG3zeq5bzirxr.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01mCgaH2CoW/3Cmnhb4B6207mN.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01kslmf2Vvj/Z24g9MgWqVa0xS.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01YmW8Ouu4H/v8KOFhK4sYrcHS.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01nHGj6BRcX/M7aemKHNijtJdN.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01F2RQ4RafK/IUrrHiPuZnssrx.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01g4neZR73K/y5qqCihU07S0p3.jpg",
    };

    String ramdonHorizotal[] = {
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01iDCFlnLVt/UpjZ6LdONlfdVB.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01mmhxeR90q/oRqKSM1AwkabE9.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01xHSphQfIv/z5cDS3JStvYCsc.png",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01vU25E7nlb/jF1f4MrBLaqdZh.png",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01JcFDkdycE/UzImtfFjE30Ll2.jpg",
            "http://image.box.xiaomi.com/mfsv2/download/s010/p01DBlr3e5TP/j9xkdsNAxw659g.png",
    };


    protected void addVideoTestData(Tabs _content){
        if(false) {
            Album item = _content.data.get(0);
            item.name = "游戏";

            Album newVideo = item.clone();
            newVideo.name = "视频";
            for (DisplayItem di : newVideo.items) {
                di.ns = "video";


                di.images.back().url = ramdonNormal[((int) (Math.random() * 100)) % ramdonNormal.length];

                if (di._ui.layout.w == 2 && di._ui.layout.h == 1) {
                    di.images.back().url = ramdonHorizotal[((int) (Math.random() * 100)) % ramdonHorizotal.length];
                    //di.images.spirit.url = "http://image.box.xiaomi.com/mfsv2/download/s010/p01ocZJlIJJe/TDJBkJPfNPl5Q6.png";
                    di.images.text().url = "http://image.box.xiaomi.com/mfsv2/download/s010/p01ocZJlIJJe/TDJBkJPfNPl5Q6.png";
                } else if (di._ui.layout.w == 1 && di._ui.layout.h == 2) {
                    //
                    di.images.back().url = ramdonVertical[((int) (Math.random() * 100)) % ramdonVertical.length];
                }

            }
            _content.data.add(1, newVideo);

            Album appideo = item.clone();
            appideo.name = "应用";
            _content.data.add(2, appideo);
        }
    }
       //please override this fun
    protected void createTabsLoader(){
        mLoader = new GameTabsGsonLoader(this);
    }
    
    View.OnClickListener mRecommendCardViewClickListener = new View.OnClickListener() {
        
        @Override
        public void onClick(View v) {
            if(RecommendCardView.class.isInstance(v)){
                RecommendCardView rcv = (RecommendCardView)v;               
                DisplayItem item = rcv.getContentData();
                if (null != item) {
                    
                    String target = item.target.type;
                    if (null != target) {
                        if (target.equals("item")) {                            
                        } else if (target.equals("album")) {                            
                        } else if (target.equals("billboard")) {                            
                        } else if (target.equals("category")) {                         
                        } else {                            
                        }
                        
                        
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse("micontent://" + item.ns + "/" + item.type + "?rid="
                                    + item.id));
                            intent.putExtra("item", item);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            v.getContext().startActivity(intent);
                        }catch (Exception ne){ne.printStackTrace();}
                    }
                    
                }
            }           
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        Utils.showStatusBar(this);
    }
}