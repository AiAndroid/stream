package com.xiaomi.mibox.gamecenter.data.download;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;

import com.xiaomi.mibox.gamecenter.R;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.Download;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumnsMap;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationRetry;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationStatus;

import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.support.v4.content.LocalBroadcastManager;
import android.util.SparseArray;

/**
 * 操作管理器，
 * 1.初始化DownloadController、InstallController以及载入Session列表
 * 2.维护列表
 * @author lihao
 *
 */
public class XMDownloadManager {
	//广播的消息
	public static final String ACTION_DOWNLOADING = "dim_progress";
    public static final String ACTION_STATUS_CHANGE = "dim_status_change";
    //下载失败的异常
    public static final int REASON_DOWNLOAD_PAUSED_WAITING_TO_RETRY = 50001;
    public static final int REASON_DOWNLOAD_PAUSED_WAITING_FOR_NETWORK = 50002;
    public static final int REASON_DOWNLOAD_PAUSED_QUEUED_FOR_WIFI = 50003;
    public final static int REASON_DOWNLOAD_PAUSED_UNKNOWN = 50004;
    public final static int REASON_DOWNLOAD_PAUSED_MANUAL_WHEN_WAITING = 50005;//在等待中手动取消下载
    public final static int REASON_DOWNLOAD_PAUSED_MANUAL_WHEN_DOWNLOADING = 50006;//在下载中手动取消下载
    
    
	//安装失败的异常
	public static final int REASON_INSTALL_NO_PERMISSION = 40001;
	public static final int REASON_INSTALL_INSUFFICIENT_STORAGE = 40002;
	public static final int REASON_INSTALL_INCONSISTENT_CERTIFICATES = 40003;
	public static final int REASON_INSTALL_APK_NOT_EXISTS = 40004;
	public static final int REASON_INSTALL_APK_INVALID = 40005;
	public static final int REASON_INSTALL_FAIL_UNKOWN = 40006;
	public static final int REASON_INSTALL_UNINSTALL_FAIL = 40007;
	public static final int REASON_INSTALL_CANCEL_MANUAL = 40008;
	//zwb s
	public static final int REASON_INSTALL_UNZIPPING_INSUFFICIENT_STORAGE = 40009;
	//zwb e
	//安装成功，但是因空间不足等原因，拷贝apk包失败。
	public static final int REASON_INSTALL_APK_MOVE_FAILED = 40010;
	
	//安装控制器
	private InstallController install ;
	//下载控制器
	private DownloadController download;
	//本地广播实例
	private LocalBroadcastManager lbm;
	private Context ctx;
	private static XMDownloadManager instance;
	//所有正处于下载、安装状态的对象缓存列表
	private ConcurrentHashMap<String, OperationSession> session_cache = 
			new ConcurrentHashMap<String, OperationSession>();
	//处理下载状态变化通知
	private DownloadStatusHandler handler;
	
	//根据Filter来返回结果集
	interface Filter
	{
		boolean onFilter(OperationSession ops);
	}
	
	//快速定位异常的文本消息
	private static SparseArray<String> reason_string; 
	
	/**
	 * 将异常ID转换为相应的文字
	 * @param r
	 * @return
	 */
	public static String convert_reason_to_string(int r)
	{
		String ret = reason_string.get(r);
		if(ret == null)
			ret = "";
		return ret;
	}
	
	public static void Init(Context ctx)
	{
		if(instance == null)
		{
			Resources res = ctx.getResources();
			instance = new XMDownloadManager(ctx);
			reason_string = new SparseArray<String>();
			reason_string.put(REASON_DOWNLOAD_PAUSED_WAITING_TO_RETRY, res.getString(R.string.download_manager_download_reason_wait_to_retry));
			reason_string.put(REASON_DOWNLOAD_PAUSED_WAITING_FOR_NETWORK, res.getString(R.string.download_manager_download_reason_wait_for_network));
			reason_string.put(REASON_DOWNLOAD_PAUSED_QUEUED_FOR_WIFI, res.getString(R.string.download_manager_download_reason_queued_for_wifi));
			reason_string.put(REASON_DOWNLOAD_PAUSED_UNKNOWN, res.getString(R.string.download_manager_download_reason_paused_unknown));
			reason_string.put(REASON_DOWNLOAD_PAUSED_MANUAL_WHEN_DOWNLOADING, res.getString(R.string.download_manager_download_reason_paused_manual));
			reason_string.put(REASON_DOWNLOAD_PAUSED_MANUAL_WHEN_WAITING, res.getString(R.string.download_manager_download_reason_paused_manual));
			reason_string.put(REASON_INSTALL_NO_PERMISSION, res.getString(R.string.download_manager_install_no_permission));
			reason_string.put(REASON_INSTALL_INSUFFICIENT_STORAGE, res.getString(R.string.download_manager_install_insufficient_storage));
			reason_string.put(REASON_INSTALL_INCONSISTENT_CERTIFICATES, res.getString(R.string.download_manager_install_inconsistent_certificates));
			reason_string.put(REASON_INSTALL_APK_NOT_EXISTS, res.getString(R.string.download_manager_install_apk_not_exists));
			reason_string.put(REASON_INSTALL_APK_INVALID, res.getString(R.string.download_manager_install_apk_invalid));
			reason_string.put(REASON_INSTALL_FAIL_UNKOWN, res.getString(R.string.download_manager_install_fail_unkown));
			reason_string.put(REASON_INSTALL_UNINSTALL_FAIL, res.getString(R.string.download_manager_install_uninstall_fail));
			reason_string.put(REASON_INSTALL_CANCEL_MANUAL, res.getString(R.string.download_manager_install_cancel_manual));
			reason_string.put(REASON_INSTALL_UNZIPPING_INSUFFICIENT_STORAGE, res.getString(R.string.download_manager_install_cancel_unzipping));
		}
	}
	
	public static XMDownloadManager getInstance()
	{
		return instance;
	}
	
	private XMDownloadManager(Context ctx) 
	{
		handler = new DownloadStatusHandler(ctx.getMainLooper(),ctx);
		this.ctx = ctx;
		lbm = LocalBroadcastManager.getInstance(ctx);
		new InitHandler(ctx.getContentResolver()).startQuery(0, null, 
				Download.URI_DOWNLOAD, DataBaseColumnsMap.DOWNLOAD_PROJECTION, null, null, null);
	}
	
	/**
	 *  从数据库载入原始数据
	 */
	private void init_from_db(Cursor sor)
	{
		try {
			if(!sor.moveToFirst())
			{
				return ;
			}
			do
			{	//这里需要对数据解析进行保护
				try {
					OperationSession ops = new OperationSession(this, sor);
					session_cache.put(ops.getGameId(), ops);
				} catch (Exception e) {
					
				}
			}while(sor.moveToNext());
		} catch (Exception e) {
		}finally
		{
			if(sor != null)
			{
				sor.close();
			}
		}
	}
	
	/**
	 * 添加任务
	 * @param gameId
	 */
	public OperationSession appendDownloadTask(String gameId)
	{
		return download.append_download(gameId);
	}
	
	/**
	 * 暂停任务
	 * @param gameId
	 */
	public void pauseDownloadTask(String gameId){
		download.pause_download(gameId);
	}
	
	/**
	 * 继续任务
	 * @param gameId
	 */
	public void continueDownloadTask(String gameId){
		download.continue_download(gameId);
	}
	
	/**
	 * 取消任务
	 * @param gameId
	 */
	public void cancelDownloadTask(String gameId)
	{
		download.remove_download(gameId);
	}
	
	/**
	 * 重试安装
	 * @param gameId
	 * @param retry
	 */
	public void retryInstall(String gameId, OperationRetry retry)
	{
		install.retryInstallTask(gameId, retry);
	}
	
	/**
	 * 移交安装控制器
	 */
	boolean DownloadFinish(OperationSession session)
	{
		install.reloadInstallTask();
		return false;
	}
	
	/**
	 * 读取一个session
	 * @param gameId
	 * @return
	 */
	public synchronized OperationSession getOperationSession(String gameId)
	{
		return session_cache.get(gameId);
	}
	
	/**
	 * 压入一个session
	 * @param session
	 * @return
	 */
	synchronized OperationSession putOperationSession(OperationSession session)
	{
		return session_cache.put(session.getGameId(), session);
	}
	
	/**
	 * 移除一个session
	 * @param gameId
	 * @return
	 */
	synchronized OperationSession removeOperationSession(String gameId)
	{
		OperationSession ret = session_cache.remove(gameId);
		ret.setStatus(OperationStatus.Remove);
		return ret;
	}
	
	/**
	 * 根据自定义的Filter来返回Session列表
	 * @param filter
	 * @return
	 */
	synchronized OperationSession[] getOperationSessionByFilter(Filter filter)
	{
		ArrayList<OperationSession> ret = null;
		if(filter != null)
		{
			ret = new ArrayList<OperationSession>();
		}else
		{
			ret = new ArrayList<OperationSession>(session_cache.values());
			return ret.toArray(new OperationSession[0]);
		}
		
		Collection<OperationSession> vs = session_cache.values();
		for(OperationSession ops : vs)
		{
			if(filter.onFilter(ops))
			{
				ret.add(ops);
			}
		}
		
		return ret.toArray(new OperationSession[0]);
	}
	
	/**
	 * 根据状态返回session列表
	 * @param status
	 * @return
	 */
	public synchronized OperationSession[] getOperationSessionByStatus(OperationStatus[] status)
	{
		ArrayList<OperationSession> ret = null;
		if(status != null)
		{
			ret = new ArrayList<OperationSession>();
		}else
		{
			ret = new ArrayList<OperationSession>(session_cache.values());
			return ret.toArray(new OperationSession[0]);
		}
		
		Collection<OperationSession> vs = session_cache.values();
		for(OperationSession ops : vs)
		{
			for(OperationStatus sts : status)
			{
				if(ops.getStatus() == sts)
				{
					ret.add(ops);
					break;
				}
			}
		}
		return ret.toArray(new OperationSession[0]);
	}
	
	/**
	 *Session状态发生变化 
	 */
	synchronized void onSessionStatusChange(OperationSession ops, OperationStatus new_status)
	{
		Intent send = new Intent();
		
		//状态为下载且无变化也要发送
		if(ops.getStatus() == new_status && new_status == OperationStatus.Downloading)
		{
			send.putExtra("session", ops);
			send.setAction(ACTION_STATUS_CHANGE+ops.getGameId());
			lbm.sendBroadcast(send);
			return ;
		}
		//zwb s状态为解压缩且无变化也要发送
//		if(ops.getStatus() == new_status && new_status == OperationStatus.Unzipping)
//		{
//			send.putExtra("session", ops);
//			send.setAction(ACTION_STATUS_CHANGE+ops.getGameId());
//			lbm.sendBroadcast(send);
//			handler.postDownloadStatusChange(ops, new_status);
//
//			return ;
//		}
		
		//zwb e
		
		//其它都是状态发生变化后才会发送
		
		if(ops.getStatus() != new_status)
		{
			send.putExtra("session", ops);
			send.setAction(ACTION_STATUS_CHANGE+ops.getGameId());
			lbm.sendBroadcast(send);
			
			send = new Intent(ACTION_STATUS_CHANGE);
			send.putExtra("session", ops);
			lbm.sendBroadcast(send);
			handler.postDownloadStatusChange(ops, new_status);
		}
	}
	
	final class InitHandler extends AsyncQueryHandler
	{
		
		public InitHandler(ContentResolver cr) {
			super(cr);
		}
		
		@Override
		protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
			super.onQueryComplete(token, cookie, cursor);
			init_from_db(cursor);
			install = new InstallController(ctx, XMDownloadManager.this);
			download = new DownloadController(ctx, XMDownloadManager.this);
		}
	}

}
