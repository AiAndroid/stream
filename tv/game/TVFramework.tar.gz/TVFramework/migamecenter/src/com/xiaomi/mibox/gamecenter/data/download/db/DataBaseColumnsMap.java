package com.xiaomi.mibox.gamecenter.data.download.db;

import android.provider.BaseColumns;

import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.Download;
import com.xiaomi.mibox.gamecenter.data.download.db.DataBaseColumns.ReportQueue;

public interface DataBaseColumnsMap {

	static final String[] DOWNLOAD_PROJECTION = new String[] {
        Download.APP_ID,
        Download.DOWNLOAD_ID,
        Download.APK_HASH,
        Download.STATUS,
        Download.TOTAL_SIZE_BYTES,
        Download.DOWNLOADED_BYTES,
        Download.ERRCODE,
        Download.TIMESTAMP,
        Download.VERSIONCODE,
        Download.PACKAGE,
        Download.RETRY,
        Download._ID,
        Download.DATA_DOWNLOAD_ID,
        Download.DATA_HAS_DATA,
        Download.PATCHER
    };

    static final int COLUMN_DOWNLOAD_APP_ID       = 0;
    static final int COLUMN_DOWNLOAD_ID           = 1;
    static final int COLUMN_DOWNLOAD_HASH         = 2;
    static final int COLUMN_DOWNLOAD_STATUS 	  = 3;
    static final int COLUMN_DOWNLOAD_TOTAL_SIZE_BYTES = 4;
    static final int COLUMN_DOWNLOAD_DOWNLOADED_BYTES = 5;
    static final int COLUMN_DOWNLOAD_ERRCODE = 6;
    static final int COLUMN_DOWNLOAD_TIMESTAMP = 7;
    static final int COLUMN_DOWNLOAD_VERSIONCODE = 8;
    static final int COLUMN_DOWNLOAD_PACKAGE = 9;
    static final int COLUMN_DOWNLOAD_RETRY = 10;
    static final int COLUMN_DOWNLOAD_ORDER_ID = 11;
    static final int COLUMN_DATA_DOWNLOAD_ID = 12;
    static final int COLUMN_DATA_HAS_DATA = 13;
    static final int COLUMN_PATCHER = 14;
    
    static final String[] REPORT_PRJ = new String[]{
    	BaseColumns._ID,
    	ReportQueue.PARAM
    };
    static final int COLUMN_REPORT_ID = 0;
    static final int COLUMN_REPORT_PARAM = 1;
}
