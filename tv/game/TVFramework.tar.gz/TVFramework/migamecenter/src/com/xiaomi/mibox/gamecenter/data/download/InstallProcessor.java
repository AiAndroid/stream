package com.xiaomi.mibox.gamecenter.data.download;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.util.Log;
import com.tv.ui.metro.model.GameItem;
import com.xiaomi.mibox.gamecenter.data.IConfig;
import com.xiaomi.mibox.gamecenter.data.IPackageManagerConstants;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationRetry;
import com.xiaomi.mibox.gamecenter.data.download.OperationSession.OperationStatus;
import com.xiaomi.mibox.gamecenter.ui.InstallPackageByIntent;
import com.xiaomi.mibox.gamecenter.utils.Client;
import com.xiaomi.mibox.gamecenter.utils.Constants;
import com.xiaomi.mibox.gamecenter.utils.GamecenterUtils;
import com.xiaomi.mibox.gamecenter.utils.WLReflect;

import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.IPackageDeleteObserver;
import android.content.pm.IPackageInstallObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.provider.Downloads;
import android.text.TextUtils;
import com.xiaomi.mitv.store.utils.Utils;

final class InstallProcessor  
{

	private OperationSession session;
	
	private Context ctx;
	
	private Object _lock_ = new Object();
	
	private String pkgName;
	
	private int returnCode = Integer.MIN_VALUE;
	
	private String new_apk;
	
	public InstallProcessor(Context ctx, OperationSession session) 
	{
		this.session = session;
		this.ctx = ctx;
	}

	/**
	 * 执行安装过程
	 * @return
	 */
	public OperationSession execute()
	{
		//zwb s 判断是否有数据包，有的话先解压zip，然后再安装apk
		if (session.isHasData()) {
			int status = Decompression.unZip(ctx, session);
			if (session.getStatus() == OperationStatus.Remove) {
				return session;
			}
			if (status == XMDownloadManager.REASON_INSTALL_UNZIPPING_INSUFFICIENT_STORAGE) {
				session.setStatus(OperationStatus.InstallPause);
				session.setReason(XMDownloadManager.REASON_INSTALL_UNZIPPING_INSUFFICIENT_STORAGE);
				return session;
			}
		}
		//zwb e
		if(session.getRetry() == OperationRetry.UninstallInstall)
		{
			PackageInfo pi = null;
			try {
				pi = ctx.getPackageManager().getPackageInfo(session.getPackageName(), 0);
			} catch (NameNotFoundException e) {
				
			}
			if(pi != null)
			{
				session.setStatus(OperationStatus.Uninstall);
				//执行卸载过程
				WLReflect.deletePackage(ctx.getPackageManager(), 
						session.getPackageName(), 
						new PackageDeleteObserver(), 0);
				synchronized (_lock_) {
					try {
						_lock_.wait(2*60*1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				pi = null;
				try {
					pi = ctx.getPackageManager().getPackageInfo(session.getPackageName(), 0);
				} catch (NameNotFoundException e) {
					
				}
				if(pi !=null)
				{
					session.setStatus(OperationStatus.InstallPause);
					session.setReason(XMDownloadManager.REASON_INSTALL_UNINSTALL_FAIL);
					session.setRetry(OperationRetry.None);
					return session;
				}
			}
		}
		//1.设置状态为安装中
		session.setStatus(OperationStatus.Installing);
		//2.获取安装包路径以及校验Hash码
		new_apk = getApkPath();
		if(TextUtils.isEmpty(new_apk))
		{
			session.setReason(XMDownloadManager.REASON_INSTALL_APK_NOT_EXISTS);
			session.setStatus(OperationStatus.InstallPause);
		}
		try
		{
			if(!verify_apk_hash(new_apk))
			{
				if(checkNewVersionInstalled()){
					session.setStatus(OperationStatus.Success);
				}else{
					session.setReason(XMDownloadManager.REASON_INSTALL_APK_INVALID);
					session.setStatus(OperationStatus.InstallPause);
				}
			}
		}catch(SecurityException e)
		{
			session.setReason(XMDownloadManager.REASON_INSTALL_NO_PERMISSION);
			session.setStatus(OperationStatus.InstallPause);
		}
		session.update(ctx);
		//3.校验过程结束，查看状态
		if(session.getStatus() != OperationStatus.Installing)
		{
			return session;
		}
		
		//4.开始安装
		if(!installApkBySystemApi(new_apk))
		{
			installApkByUserIntent(new_apk);
		}
		return session;
	}
	
	/**
	 * 从数据库读取下载路径
	 * @return
	 */
	private String getApkPath()
	{
		String ret = null;
		DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
		Query query = new Query();
		query.setFilterById(session.getDownloadId());
		Cursor cursor = dm.query(query);
		if(cursor == null || !cursor.moveToFirst())
		{
			cursor.close();
			return null;
		}
		int filePathColumnIndex = -1;
		String filePathColumnName;
		try {
			if (Client.isLaterThanHoneycomb()) { // 这里不要判断MIUI，只判断Android版本
				filePathColumnName = DownloadManager.COLUMN_LOCAL_FILENAME;
			} else {
				filePathColumnName = Constants.COLUMN_FILE_PATH;
			}
			filePathColumnIndex = cursor
					.getColumnIndexOrThrow(filePathColumnName);
		} catch (IllegalArgumentException e) {
				e.printStackTrace();
			try {
				filePathColumnIndex = cursor.getColumnIndexOrThrow(Downloads.Impl._DATA);
			} catch (Exception e2) {
					e2.printStackTrace();
				try {
					filePathColumnIndex = cursor.getColumnIndexOrThrow("local_uri");
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			}
		}
		// 该下载任务可能失败或者成功
		if (filePathColumnIndex != -1) {
			ret = cursor.getString(filePathColumnIndex);
		}
		return ret;
	}
	
	/**
	 * 校验下载的apk
	 * @param apk
	 * @return
	 */
	private boolean verify_apk_hash(String apk)
	{
        if(IConfig.needCheckHash == true) {
            GameItem info = Utils.getGameItem(ctx, session.getGameId());
            String fileHash = GamecenterUtils.getFileMD5(apk);
            if (GamecenterUtils.NO_PERMISSION_MD5.equals(fileHash)) {
                throw new SecurityException("Permission Denied");
            }
//		//校验下载apk 如果是增量升级包 需要进行增量包的合并
//		if(TextUtils.equals(info.patcherHash, fileHash)){
//			PackageInfo pkgInfo = null;
//			PackageManager packageManager = ctx.getPackageManager();
//			try {
//				pkgInfo = packageManager.getPackageInfo(info.packageName, 
//						PackageManager.GET_SIGNATURES);
//			} catch (NameNotFoundException e) {
//				return false;
//			}
//			String oldApkPath = pkgInfo.applicationInfo.sourceDir;
//			String newApkPath = null;
//			if(apk.indexOf(".apk") > 0){
//				newApkPath = apk.replace(".apk", "_patcher.apk");
//			}else {
//				newApkPath = apk + "_patcher";
//			}
//			Patcher.patch(oldApkPath, newApkPath, apk);
//			new_apk = newApkPath;
//			fileHash = GamecenterUtils.getFileMD5(newApkPath);
//		}

            if (info != null) {
                Log.e("installPorcessor", "apk hash : " + info.apk.hash + " ||| pacher apk hash : " + fileHash);
                return TextUtils.equals(info.apk.hash, fileHash);
            }

            return false;
        }
        return true;
	}

	/**
	 * 使用Intent安装
	 * @param apkPath
	 * @return
	 */
	private boolean installApkByUserIntent(String apkPath) {
		Uri installUri = null;
		if (!TextUtils.isEmpty(apkPath)) {
			if (apkPath.contains("://")) {// 有可能是 content://
				installUri = Uri.parse(apkPath);
			} else {
				installUri = Uri.parse("file://" + apkPath);
			}
		}
		//创建监听器，等待Activity的返回
		final Object _lock_ = new Object();
		final BroadcastReceiver br = new BroadcastReceiver() {
			
			@Override
			public void onReceive(Context context, Intent intent) {
				synchronized (_lock_) {
					_lock_.notifyAll();
					ctx.unregisterReceiver(this);
				}
			}
		};
		ctx.registerReceiver(br, new IntentFilter(
				InstallPackageByIntent.INSTALL_ACTIVITY_HAS_RETURN+session.getPackageName()));
		
		//启动Activity
		Intent itAct = new Intent(ctx, InstallPackageByIntent.class);
		itAct.putExtra("apk_url", installUri.toString());
		itAct.putExtra("pkgName", session.getPackageName());
		itAct.putExtra("version", session.getVersioncode());
		itAct.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		ctx.startActivity(itAct);
		
		synchronized (_lock_) {
			try {
				_lock_.wait(6*60000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			//尝试注销listener
			ctx.unregisterReceiver(br);
		} catch (Exception e) {
		}
		
		
		//检查安装情况
		PackageInfo pi = null;
		try {
			pi = ctx.getPackageManager().getPackageInfo(
					session.getPackageName(), 0);
		} catch (NameNotFoundException e) {
		}
		if (pi == null || pi.versionCode < session.getVersioncode()) {
			session.setStatus(OperationStatus.InstallPause);
			session.setReason(XMDownloadManager.REASON_INSTALL_CANCEL_MANUAL);
			session.update(ctx);
		}else
		{
			session.setStatus(OperationStatus.Success);
			boolean copySuccess = moveApk(apkPath);
			if(!copySuccess){
				session.setReason(XMDownloadManager.REASON_INSTALL_APK_MOVE_FAILED);
			}
		}

		return true;
	}
	
	/**
	 * 使用系统API后台静默安装
	 * @param apkPath
	 * @return
	 */
	private boolean installApkBySystemApi(String apkPath)
	{
		Uri installUri = null;
        if(!TextUtils.isEmpty(apkPath)){
        	if(apkPath.contains("://")){//有可能是 content://
        		installUri = Uri.parse(apkPath);
        	}else{
        		installUri = Uri.parse("file://" + apkPath);
        	}
        }
        
        try {
        	ctx.enforceCallingOrSelfPermission(
        			android.Manifest.permission.INSTALL_PACKAGES, null);
            WLReflect.installPackage(ctx.getPackageManager(),
            		installUri,
                	new PackageInstallObserver(),
                	IPackageManagerConstants.INSTALL_REPLACE_EXISTING,
                	ctx.getPackageName());
		} catch (Exception e) {
			return false;
		}
        //最长等10分钟
        synchronized (_lock_) {
			try {
				_lock_.wait(10*60*1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
        if(returnCode == IPackageManagerConstants.INSTALL_SUCCEEDED)
		{
			session.setStatus(OperationStatus.Success);
			boolean copySuccess = moveApk(apkPath);
			if(!copySuccess){
				session.setReason(XMDownloadManager.REASON_INSTALL_APK_MOVE_FAILED);
			}
			session.update(ctx);
		}
		else if(returnCode == IPackageManagerConstants.INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES)
		{
			session.setStatus(OperationStatus.InstallPause);
			session.setReason(XMDownloadManager.REASON_INSTALL_INCONSISTENT_CERTIFICATES);
			session.update(ctx);
		}
		else if(returnCode == WLReflect.INSTALL_FAILED_INSUFFICIENT_STORAGE)
		{
			session.setStatus(OperationStatus.InstallPause);
			session.setReason(XMDownloadManager.REASON_INSTALL_INSUFFICIENT_STORAGE);
			session.update(ctx);
		}
		else if(returnCode == Integer.MIN_VALUE)
		{
			session.setStatus(OperationStatus.InstallPause);
			session.setReason(XMDownloadManager.REASON_INSTALL_FAIL_UNKOWN);
			session.setExtraErrorCode(returnCode);
			session.update(ctx);
		}else
		{
			session.setStatus(OperationStatus.InstallPause);
			session.setReason(XMDownloadManager.REASON_INSTALL_FAIL_UNKOWN);
			session.setExtraErrorCode(returnCode);
			session.update(ctx);
		}
        return true;
	}
	
	/**
	 * 根据设置里的开关选项，复制apk包到/sdcard/download目录下
	 * @param apkPath
	 * @return
	 */
	private boolean moveApk(String apkPath){
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(ctx);
		if(!sp.getBoolean("setting_need_copy_apk_after_install", false)){
			return false;
		}
		GameItem info = Utils.getGameItem(ctx, session.getGameId());
		if(null != info){
			String apkName = info.name+"_"+info.ver.name+".apk";
			if(Environment.getExternalStorageDirectory().canWrite()){
		    	File downloadDirFile = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
		    	if(null != downloadDirFile&& downloadDirFile.exists()){
		    		String newPath = downloadDirFile.getAbsolutePath()+"/"+apkName;
		    		long dataSpace = GamecenterUtils.getDiskFreeSize(downloadDirFile.getAbsolutePath());
		    		if(dataSpace<Integer.valueOf(info.sizes.packaged)){
		    			return false;
		    		}
		    		InputStream in= null;
		    		OutputStream out = null;
		    		try {
						in = new FileInputStream(apkPath);
						out = new FileOutputStream(newPath);
						
						byte[] buf = new byte[1024*10];
						int len;
						while ((len = in.read(buf)) > 0) {
						    out.write(buf, 0, len);
						}
						out.flush();
						return true;
					} catch (Exception e) {
						e.printStackTrace();
					}finally{
						if(null != in){
							try {
								in.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
						
						if(null != out){
							try {
								out.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
		    	}
			}
		}
		return false;
	}
	
	
	/**
	 * 有可能出现多家应用商店(游戏中心)下载安装同一个游戏的可能性。
	 * 在装过程中，检查一下最新版本是否已经安装上了。
	 * @return
	 */
	private boolean checkNewVersionInstalled(){
		try {
			GameItem info = Utils.getGameItem(ctx, session.getGameId());
			PackageManager packageManager = ctx.getPackageManager();
			PackageInfo pkgInfo = packageManager.getPackageInfo(
					info.packagename,
					PackageManager.GET_SIGNATURES);
			if(Integer.valueOf(info.ver.code) == pkgInfo.versionCode){
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	private class PackageInstallObserver extends IPackageInstallObserver.Stub
	{
		@Override
		public void packageInstalled(String packageName, 
				final int retCode)throws RemoteException {
			pkgName = packageName;
			returnCode = retCode;
			//返回的结果不是我们想要的结果
			if(!TextUtils.isEmpty(pkgName) 
					&& !session.getPackageName().equals(pkgName)){
				return ;
			}
			synchronized (_lock_) {
				_lock_.notifyAll();
			}
			
		}
	}
	
	private class PackageDeleteObserver extends IPackageDeleteObserver.Stub
	{
		@Override
		public void packageDeleted(String packageName, int retCode)
				throws RemoteException {
			pkgName = packageName;
			returnCode = retCode;
			if(!session.getPackageName().equals(pkgName)){
				return ;
			}
			synchronized (_lock_) {
				_lock_.notifyAll();
			}
		}
	}
}
