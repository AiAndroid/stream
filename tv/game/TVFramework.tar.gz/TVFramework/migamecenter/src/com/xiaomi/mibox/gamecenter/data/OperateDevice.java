package com.xiaomi.mibox.gamecenter.data;

/**
 * 操作类型
 * @author liubiqiang
 *
 */
public interface OperateDevice {
	public static final int OperateDeviceMouse = 0x01;//鼠标
	public static final int OperateDeviceController = 0x02;//遥控器
	public static final int OperateDeviceHandler = 0x04;//手柄
}
