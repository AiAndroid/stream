package com.tv.ui.metro.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by liuhuadong on 9/10/14.
 */
public class GameItem extends Item {
    private static final long serialVersionUID = 4L;

    public String description;
    public Vendor vendor;
    public ArrayList<Category>category;
    
    @SerializedName("package")
    public String packagename;

    public Sizes    sizes;
    public Counts   counts;
    
    public ArrayList<ImageGroup> screenshots;    
    public String    phrase;    
    public Version   ver;
    
    public Flags     flags;
    public int       score;
    public String    recent_change;

    public ArrayList<Assets>   assets;
    public ArrayList<GameItem> related;

    public APK       apk;
    public String    patch_url;
    
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("\n\nGameItem:  package="+packagename);
        sb.append("\ndisplayItem="+super.toString());
        sb.append("\nsizes="+sizes);
        sb.append("\ncounts="+counts);
        sb.append("\nver="+ver);
        sb.append("\nflags="+flags);
        sb.append("\nscore="+score);
        sb.append("\ndescription="+description);
        sb.append("\nrecent_change="+recent_change);
        sb.append("\napk="+apk);
        sb.append("\npatch_url="+patch_url);
        
        for(Category item:category){
            sb.append("\n category="+item);
        }
        
        for(ImageGroup item:screenshots){
            sb.append("\n screenshot="+item);
        }
        
        for(GameItem item:related){
            sb.append("\n related="+item);
        }

        for(Assets item:assets){
            sb.append("\n asset="+item);
        }

        return sb.toString();
    }

    public static class APK implements Serializable{
        private static final long serialVersionUID = 2L;
        public String url;
        public String hash;

        public String toString(){
            return "\n apk="+url + " hash="+hash;
        }
    }

    public static class Assets implements Serializable{
        private static final long serialVersionUID = 1L;
        public String url;
        public String local_dir;
        public String type;
        public int    size;

        public String toString(){
            return "\nAsset:  url="+url + " local_dir="+local_dir + " type="+type + " size="+size;
        }
    }

    public static class Vendor implements Serializable{
        private static final long serialVersionUID = 1L;
        public String id;
        public String name;
        
        public String toString(){
            return "\nVendor:  id="+id + " name="+name;
        }
    }

    public static class Flags implements Serializable{
        private static final long serialVersionUID = 2L;
        public boolean updated;
        public boolean joystick;
        public int     operate_device;
        
        public String toString(){
            return "\nFlags:  joystick="+joystick + " operate_device="+operate_device;
        }
    }

    public static class Version implements Serializable{
        private static final long serialVersionUID = 1L;
        public String code;
        public String name;
        
        public String toString(){
            return "\nVersion:  code="+code + " name="+name;
        }
    }

    public static class Sizes implements Serializable{
        private static final long serialVersionUID = 2L;
        @SerializedName("package")public String packaged;
        public String installed;
        public String data;
        
        public String toString(){
            return "\nsizes:  package="+packaged + " installed="+installed + " data="+data;
        }
    }

    public static class Category implements Serializable{
        private static final long serialVersionUID = 1L;
        public String id;
        public String name;
        
        public String toString(){
            return "\ncategory:  id="+id + " name="+name;
        }
    }

    public static class Counts implements Serializable{
        private static final long serialVersionUID = 1L;
        public int download;
        
        public String toString(){
            return "\ncounts:  download="+download;
        }
    }
}
