package miui.cloud;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;

import org.apache.http.auth.InvalidCredentialsException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import miui.cloud.exception.CloudServiceFailureException;
import miui.content.ExtraIntent;
import miui.cloud.ICloudManagerResponse;
import miui.cloud.ICloudManagerService;
import miui.cloud.exception.InvalidResponseException;
import miui.cloud.exception.NoActivateAccountException;
import miui.cloud.exception.OperationCancelledException;

/**
 * Cloud Manager Base Class
 * Support Base URL and Constants for Cloud And Access Xiaomi Account action by RPC
 * @hide
 */
public class CloudManager {
    public static final boolean USE_PREVIEW = new File("/data/system/account_preview").exists();

    /**
     * Account pass base url
     * preview : http://account.preview.n.xiaomi.net/pass
     * product : https://account.xiaomi.com/pass
     */
    public static final String URL_ACCOUNT_BASE = USE_PREVIEW ? "http://account.preview.n.xiaomi.net/pass"
            : "https://account.xiaomi.com/pass";

    /**
     * API pass base url
     * preview : http://api.account.preview.n.xiaomi.net/pass
     * product : http://api.account.xiaomi.com/pass
     */
    public static final String URL_ACOUNT_API_BASE = USE_PREVIEW ? "http://api.account.preview.n.xiaomi.net/pass"
            : "http://api.account.xiaomi.com/pass";

    public static final String URL_ACCOUNT_API_V2_BASE = USE_PREVIEW ? "http://api.account.preview.n.xiaomi.net/pass/v2"
            : "http://api.account.xiaomi.com/pass/v2";

    // Base url of APIs used to query user-specific info
    public static final String URL_ACCOUNT_SAFE_API_BASE = USE_PREVIEW ? "http://api.account.preview.n.xiaomi.net/pass/v2/safe"
            : "http://api.account.xiaomi.com/pass/v2/safe";
    // Rich media base url
    public static final String URL_RICH_MEDIA_BASE = USE_PREVIEW ? "http://api.micloud.preview.n.xiaomi.net"
            : "http://fileapi.micloud.xiaomi.net";
    // Contact base url
    public static final String URL_CONTACT_BASE = USE_PREVIEW ? "http://micloud.preview.n.xiaomi.net"
            : "http://contactapi.micloud.xiaomi.net";
    // Mms base url
    public static final String URL_MMS_BASE = USE_PREVIEW ? "http://micloud.preview.n.xiaomi.net"
            : "http://smsapi.micloud.xiaomi.net";
    // Gallery base url
    public static final String URL_GALLERY_BASE = USE_PREVIEW ? "http://micloud.preview.n.xiaomi.net"
            : "http://galleryapi.micloud.xiaomi.net";
    // Find device base url
    public static final String URL_FIND_DEVICE_BASE = USE_PREVIEW ? "http://micloud.preview.n.xiaomi.net"
            : "http://findapi.micloud.xiaomi.net";
    // Wifi base url
    public static final String URL_WIFI_BASE = USE_PREVIEW ? "http://micloud.preview.n.xiaomi.net"
            : "http://wifiapi.micloud.xiaomi.net";
    // Note base url
    public static final String URL_NOTE_BASE = USE_PREVIEW ? "http://micloud.preview.n.xiaomi.net"
            : "http://noteapi.micloud.xiaomi.net";
    /**
     * Calllog  base url
     * preview: http://micloud.preview.n.xiaomi.net
     * product: http://api.micloud.xiaomi.net
     */
    public static final String URL_CALL_LOG_BASE = USE_PREVIEW ? "http://micloud.preview.n.xiaomi.net"
            : "http://phonecallapi.micloud.xiaomi.net";

    // wifi share base url
    public static final String URL_WIFI_SHARE_BASE = USE_PREVIEW ? "http://micloud.preview.n.xiaomi.net"
            : "http://wifisharingapi.micloud.xiaomi.net";
    /**
     * Device setting base url
     * preview url :    http://api.device.preview.n.xiaomi.net
     * product url :    http://api.device.xiaomi.net
     */
    public static final String URL_DEV_BASE = USE_PREVIEW ? "http://api.device.preview.n.xiaomi.net"
            : "http://api.device.xiaomi.net";

    // Device setting url
    public static final String URL_DEV_SETTING = "/udi/v1/user/%s/device/%s/setting";
    /**
     * MiCloud Status base url
     * preview url:    http://statusapi.micloud.preview.n.xiaomi.net
     * product url:    http://statusapi.micloud.xiaomi.net
     */
    public static final String URL_MICLOUD_STATUS_BASE = "http://statusapi.micloud.xiaomi.net";

    public static final int ERROR_CODE_SEND_SMS_FAILURE = 0x00000001;

    public static final int ERROR_CODE_ACTIVATE_TIMEOUT = 0x00000002;

    public static final int ERROR_CODE_NO_ACCOUNT = 0x00000003;

    public static final int ERROR_IO = 0x00000004;

    public static final int ERROR_INVALID_RESPONSE = 0x00000005;

    public static final int ERROR_INVALID_CREDENTIAL = 0x00000006;

    public static final int ERROR_SIM_NOT_ACTIVATED = 0x0000007;

    public static final String KEY_ACTIVATE_PHONE = "activate_phone";

    public static final String KEY_PHONE_TICKET = "phone_ticket";

    public static final String KEY_ACTIVATE_SIM_ID = "sim_id";

    /**
     * AES key to query user-specific API
     */
    public static final String KEY_USER_SECURITY = "user_security";

    /**
     * Token used to query user-specific API
     */
    public static final String KEY_USER_TOKEN = "user_token";

    /**
     * Token used to query deviceinfo API
     */
    public static final String DEVICE_INFO_TOKEN = "deviceinfo";

    /**
     * @deprecated use {@link #KEY_USER_TOKEN} instead
     */
    public static final String KEY_PASSTOKEN = "pass_token";

    public static final String KEY_SECONDARY_SYNC_ON = "secondary_sync_on";

    public static final String KEY_FIND_DEVICE_TOKEN = "find_device_token";

    public static final String KEY_ACTIVATE_STATUS = "activate_status";

    public static final String KEY_SIM_USER_ID = "sim_user_id";

    public static final String KEY_RESULT = "result";

    public static final String KEY_SNS_ACCESS_TOKEN = "get_sns_access_token";

    public static final String KEY_SIM_INDEX = "sim_index";

    public static final String KEY_SIM_INSERTED = "sim_inserted";

    public static final int SIM_INDEX_0 = 0;

    public static final int SIM_INDEX_1 = 1;

    public static final int SIM_ID_DEFAULT = SIM_INDEX_0;

    /**
     * The activation procedure is in progress.
     */
    public static final int ACTIVATE_STATUS_ACTIVATING = 1;

    /**
     * The current phone number is known. You can use the
     * phone number directly, without sending SMS.
     */
    public static final int ACTIVATE_STATUS_ACTIVATED = 2;

    /**
     *  The current phone number is unknown. An SMS is required.
     */
    public static final int ACTIVATE_STATUS_UNACTIVATED = 3;

    /**
     * The SMS used to activate the SIM is sent.
     */
    public static final int ACTIVATE_STATUS_SMS_SENT = 4;

    /**
     * id of sim not activated notification. the id starts with 0x10000000
     */
    public static final int NOTIFICATION_ACTIVATE_ERROR = 0x10000001;

    private static final boolean DEBUG = true;

    private static final String TAG = "CloudManager";

    private Context mContext;

    private final int mSimCount;

    private static String mUserAgent;

    public static CloudManager get(Context context) {
        return new CloudManager(context);
    }

    private CloudManager(Context context) {
        this.mContext = context;
        this.mSimCount = 1;
    }

    /**
     * start to activate the sim, an SMS will be sent if need
     *
     * @param simIndex sim index, starting from 0, use one of CloudManager.SIM_INDEX_XX
     */
    public CloudManagerFuture<Bundle> startActivateSim(final int simIndex) {
        if (simIndex < 0) {
            throw new IllegalArgumentException(
                    "negative sim index is not allowed");
        }
        if (simIndex >= mSimCount) {
            throw new IllegalArgumentException(
                    "sim index exceeds the max value");
        }
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.startActivateSim(simIndex, getResponse());
            }
        }.start();
    }

    /**
     * <p>Gets phone number of the current device. If a previously activated
     * phone number is saved, then it is returned. Null the device is never
     * activated</p>
     *
     * @return An {@link CloudManagerFuture } which resolves to a Bundle with at
     *         least the following fields: <ul><li>{@link #KEY_ACTIVATE_PHONE} -
     *         the activated phone </li><li>{@link #KEY_PHONE_TICKET} token used
     *         to request bind id</li></ul> If any exception occurs, {@link
     *         miui.cloud.CloudManager.CloudManagerFuture#getResult()} throws
     *         <ul><li>{@link IOException}  if the manager experienced an I/O
     *         problem when fetching the phone number, usually because of
     *         network trouble</li><li>{@link OperationCancelledException}</li>
     *         if the operation is canceled for any reason<li>{@link
     *         CloudServiceFailureException} if the activate SMS is failed to
     *         sent, or not received by server for a long period of time.
     *         </li></ul>
     */
    public CloudManagerFuture<Bundle> getActivatedPhoneNumber(
            final int simIndex) {
        if (simIndex < 0) {
            throw new IllegalArgumentException(
                    "negative sim index is not allowed");
        }
        if (simIndex >= mSimCount) {
            throw new IllegalArgumentException(
                    "sim index exceeds the max value");
        }
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.getActivatedPhone(simIndex, getResponse());
            }
        }.start();
    }

    /**
     * retrieve the current activation status
     *
     * @param simIndex sim index, starting from 0, use one of CloudManager.SIM_INDEX_XX
     */
    public CloudManagerFuture<Bundle> getActivateStatus(final int simIndex) {
        if (simIndex < 0) {
            throw new IllegalArgumentException(
                    "negative sim index is not allowed");
        }
        if (simIndex >= mSimCount) {
            throw new IllegalArgumentException(
                    "sim index exceeds the max value");
        }
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.getActivatedStatus(simIndex, getResponse());
            }
        }.start();
    }

    public CloudManagerFuture<Bundle> getSimAuthToken(final int simIndex,
            final String serviceId) {
        if (simIndex < 0) {
            throw new IllegalArgumentException(
                    "negative sim index is not allowed");
        }
        if (simIndex >= mSimCount) {
            throw new IllegalArgumentException(
                    "sim index exceeds the max value");
        }
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.getSimAuthToken(simIndex, serviceId, getResponse());
            }
        }.start();
    }

    /**
     * get the account information behind the sim
     *
     * @param simIndex sim index, starting from 0, use one of CloudManager.SIM_INDEX_XX
     */
    public CloudManagerFuture<Bundle> getActivatedSimUser(final int simIndex) {
        if (simIndex < 0) {
            throw new IllegalArgumentException(
                    "negative sim index is not allowed");
        }
        if (simIndex >= mSimCount) {
            throw new IllegalArgumentException(
                    "sim index exceeds the max value");
        }
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.getActivatedSimUser(simIndex, getResponse());
            }
        }.start();
    }

    /**
     * get Find Device token for the SIM
     *
     * @param simIndex sim index, starting from 0, use one of CloudManager.SIM_INDEX_XX
     */
    public CloudManagerFuture<Bundle> getFindDeviceToken(final int simIndex) {
        if (simIndex < 0) {
            throw new IllegalArgumentException(
                    "negative sim index is not allowed");
        }
        if (simIndex >= mSimCount) {
            throw new IllegalArgumentException(
                    "sim index exceeds the max value");
        }
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.getFindDeviceToken(simIndex, getResponse());
            }
        }.start();
    }

    /**
     * get sms gateway that is suitable for the SIM
     *
     * @param simIndex sim index, starting from 0, use one of CloudManager.SIM_INDEX_XX
     */
    public CloudManagerFuture<Bundle> getSmsGateway(final int simIndex) {
        if (simIndex < 0) {
            throw new IllegalArgumentException(
                    "negative sim index is not allowed");
        }
        if (simIndex >= mSimCount) {
            throw new IllegalArgumentException(
                    "sim index exceeds the max value");
        }
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.getSmsGateway(simIndex, getResponse());
            }
        }.start();
    }

    /**
     * get sim card state whether insert or not
     * @param simIndex
     * @return
     */
    public CloudManagerFuture<Bundle> getSimInsertState(final int simIndex) {
        if (simIndex < 0) {
            throw new IllegalArgumentException(
                    "negative sim index is not allowed");
        }
        if (simIndex >= mSimCount) {
            throw new IllegalArgumentException(
                    "sim index exceeds the max value");
        }
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.getSimInsertState(simIndex, getResponse());
            }
        }.start();
    }

    public CloudManagerFuture<Bundle> getUserSecurity() {
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.getUserSecurity(getResponse());
            }
        }.start();
    }

    public CloudManagerFuture<Bundle> invalidateUserSecurity(final String token,
            final String security) {
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.invalidateUserSecurity(token, security, getResponse());
            }
        }.start();
    }


    public CloudManagerFuture<Bundle> cancelNotification(
            final int notificationId) {
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.cancelNotification(notificationId, getResponse());
            }
        }.start();
    }

    /**
     * get service token without adding account to system.
     *
     * @param userId   user id, with form of Miliao id, phone number, email
     *                 address
     * @param password password. NOT passToken
     * @param sid      service id
     * @return retrieve service token with {@link #KEY_USER_TOKEN}, AES key with
     *         {@link #KEY_USER_SECURITY}
     */
    public CloudManagerFuture<Bundle> checkUser(final String userId,
            final String password, final String sid) {
        if (TextUtils.isEmpty(userId) || TextUtils.isEmpty(password)
                || TextUtils.isEmpty(sid)) {
            throw new IllegalArgumentException("illegal params");
        }
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.checkUser(userId, password, sid, getResponse());
            }
        }.start();
    }

    /**
     * get sns access token by type
     * @param type
     * @return
     */
    public CloudManagerFuture<Bundle> getAccessToken(final String type) {
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.getAccessToken(type, getResponse());
            }
        }.start();
    }

    /**
     * invalidete access token according to type and current accessToken
     * @param type
     * @param accessToken
     * @return
     */
    public CloudManagerFuture<Bundle> invalidateAccessToken(final String type, final String accessToken) {
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.invalidateAccessToken(type, accessToken, getResponse());
            }
        }.start();
    }

    /**
     * temp action for get log info from xmsf
     * @return
     */
    public CloudManagerFuture<Bundle> getXmsfFeedback() {
        return new CmTask() {
            @Override
            protected void doWork() throws RemoteException {
                ICloudManagerService service = getService();
                service.getXmsfFeedback(getResponse());
            }
        }.start();
    }

    private abstract class CmTask extends FutureTask<Bundle>
            implements CloudManagerFuture<Bundle>, ServiceConnection {

        private ICloudManagerResponse mResponse;

        private ICloudManagerService mService;

        protected CmTask() {
            super(new Callable<Bundle>() {
                @Override
                public Bundle call() throws Exception {
                    throw new IllegalStateException(
                            "this should never be called");
                }
            });

            mResponse = new ICloudManagerResponseImpl();
        }

        protected ICloudManagerResponse getResponse() {
            return mResponse;
        }

        protected ICloudManagerService getService() {
            return mService;
        }

        protected abstract void doWork() throws RemoteException;

        public final CloudManagerFuture<Bundle> start() {
            bind();
            return this;
        }

        protected void bind() {
            if (!bindToCloudService()) {
                setException(new CloudServiceFailureException());
            }
        }

        protected void unBind() {
            mContext.unbindService(this);
            if (DEBUG) {
                Log.d(TAG, "service unbinded");
            }
        }

        protected boolean bindToCloudService() {
            Intent intent = new Intent(ExtraIntent.ACTION_ACTIVATE_PHONE);
            mContext.startService(intent);
            return mContext.bindService(intent, this, Context.BIND_AUTO_CREATE);
        }

        private Bundle internalGetResult(Long timeout, TimeUnit unit)
                throws IOException, CloudServiceFailureException,
                OperationCancelledException, NoActivateAccountException {
            if (!isDone()) {
                ensureNotOnMainThread();
            }
            try {
                if (timeout == null) {
                    return get();
                } else {
                    return get(timeout, unit);
                }
            } catch (CancellationException e) {
                throw new OperationCancelledException();
            } catch (TimeoutException e) {
                // fall through and cancel
            } catch (InterruptedException e) {
                // fall through and cancel
            } catch (ExecutionException e) {
                final Throwable cause = e.getCause();
                if (cause instanceof IOException) {
                    throw (IOException) cause;
                } else if (cause instanceof CloudServiceFailureException) {
                    throw (CloudServiceFailureException) cause;
                } else if (cause instanceof NoActivateAccountException) {
                    throw (NoActivateAccountException) cause;
                } else if (cause instanceof Error) {
                    throw (Error) cause;
                } else if (cause instanceof InvalidCredentialsException) {
                    throw new CloudServiceFailureException(cause,
                            ERROR_INVALID_CREDENTIAL);
                } else if (cause instanceof InvalidResponseException) {
                    throw new CloudServiceFailureException(cause,
                            ERROR_INVALID_RESPONSE);
                } else {
                    throw new CloudServiceFailureException(cause);
                }
            } finally {
                cancel(true /* interrupt if running */);
            }
            throw new OperationCancelledException();
        }

        @Override
        protected void set(Bundle bundle) {
            super.set(bundle);
            unBind();
        }

        @Override
        protected void setException(Throwable t) {
            super.setException(t);
            unBind();
        }

        @Override
        public Bundle getResult(long timeout, TimeUnit unit)
                throws IOException, OperationCancelledException,
                CloudServiceFailureException, NoActivateAccountException {
            return internalGetResult(timeout, unit);
        }

        @Override
        public Bundle getResult()
                throws IOException, OperationCancelledException,
                CloudServiceFailureException, NoActivateAccountException {
            return internalGetResult(null, null);
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (DEBUG) {
                Log.d(TAG, "onServiceConnected, component:" + name);
            }
            mService = ICloudManagerService.Stub.asInterface(service);
            try {
                doWork();
            } catch (RemoteException e) {
                setException(e);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            if (!isDone()) {
                Log.e(TAG,
                        "cloud service disconnected, but task is not completed");
                setException(new CloudServiceFailureException(
                        "active service exits unexpectedly"));
            }
            mService = null;
        }

        class ICloudManagerResponseImpl extends ICloudManagerResponse.Stub {

            @Override
            public void onResult(Bundle bundle)
                    throws RemoteException {
                set(bundle);
            }

            @Override
            public void onError(int code, String message)
                    throws RemoteException {
                setException(convertErrorCodeToException(code));
            }
        }

        private Exception convertErrorCodeToException(int code) {
            switch (code) {
                case ERROR_CODE_ACTIVATE_TIMEOUT:
                case ERROR_CODE_SEND_SMS_FAILURE:
                    return new CloudServiceFailureException(
                            "Send sms failure or activate timed out");
                case ERROR_CODE_NO_ACCOUNT:
                    return new NoActivateAccountException(
                            "no active Xiaomi account");
                case ERROR_IO:
                    return new IOException();
                case ERROR_INVALID_CREDENTIAL:
                    return new InvalidCredentialsException();
                case ERROR_INVALID_RESPONSE:
                    return new InvalidResponseException(
                            "invalid response, code: " + code);
            }
            return new CloudServiceFailureException(
                    "Unknown activation failure");
        }

        private void ensureNotOnMainThread() {
            final Looper looper = Looper.myLooper();
            if (looper != null && looper == mContext.getMainLooper()) {
                final IllegalStateException exception
                        = new IllegalStateException(
                        "calling this from your main thread can lead to deadlock");
                Log.e(TAG,
                        "calling this from your main thread can lead to deadlock and/or ANRs",
                        exception);
                throw exception;
            }
        }
    }

    public static interface CloudManagerFuture<V> {

        boolean cancel(boolean mayInterruptIfRunning);

        V getResult(long timeout, TimeUnit unit)
                throws IOException, OperationCancelledException,
                CloudServiceFailureException, NoActivateAccountException;

        V getResult() throws IOException, OperationCancelledException,
                CloudServiceFailureException, NoActivateAccountException;

        boolean isCancelled();

        boolean isDone();
    }


    public static String getUserAgent() {
        if (mUserAgent == null) {
            StringBuilder sb = new StringBuilder();
            //  model name + region name, like aries_tw
//            String miuiModel = SystemProperties.get("ro.product.mod_device");
//            if (!TextUtils.isEmpty(miuiModel)) {
//                sb.append(miuiModel);
//            } else {
//                sb.append(Build.MODEL);
//            }
            sb.append(Build.MODEL);
            sb.append("; MIUI/");
            sb.append(Build.VERSION.INCREMENTAL);
            if (SimpleRequest.IS_ALPHA_BUILD) {
                sb.append(' ');
                sb.append("ALPHA");
            }
            mUserAgent = sb.toString();
        }
        return mUserAgent;
    }

    public static interface DevSettingName {
        public static final String CAPABILITY = "capability";
        public static final String DEVICENAME = "deviceName";
        public static final String MODEL = "model";
        public static final String OS_VERSION = "osVersion";
        public static final String PHONE_INFO = "_phoneInfo";
    }

    public static class PhoneInfo {
        public final String mSimId;
        public final String mPhone;

        public PhoneInfo(String simId, String phone) {
            mSimId = simId;
            mPhone = phone;
        }

        private JSONObject toJSONObject() {
            try {
                JSONObject devSetting = new JSONObject();
                devSetting.put("simId", mSimId);
                devSetting.put("phone", mPhone);
                return devSetting;
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        public String createPhoneInfoString(List<PhoneInfo> phoneInfos) {
            JSONArray array = new JSONArray();
            if (phoneInfos != null) {
                for (PhoneInfo phoneInfo : phoneInfos) {
                    JSONObject o = phoneInfo.toJSONObject();
                    if (o != null) {
                        array.put(o);
                    }
                }
            }
            return array.toString();
        }
    }

    public static void waitUntilNetworkConnected(Context context)
            throws InterruptedException {
        ensureNotOnMainThread(context);
        IntentFilter filter = new IntentFilter(
                ConnectivityManager.CONNECTIVITY_ACTION);
        ConnectivityResumedReceiver r = new ConnectivityResumedReceiver(
                context);
        context.registerReceiver(r, filter);
        if (DEBUG) {
            Log.d(TAG, "waiting network...");
        }
        try {
            r.await();
            if (DEBUG) {
                Log.d(TAG, "network is OK");
            }
        } catch (ExecutionException e) {
            // ignore
        } finally {
            context.unregisterReceiver(r);
        }
    }

    public static boolean isNetworkConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(
                Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private static void ensureNotOnMainThread(Context context) {
        final Looper looper = Looper.myLooper();
        if (looper != null && looper == context.getMainLooper()) {
            throw new IllegalStateException(
                    "calling this from your main thread can lead to deadlock");
        }
    }

    private static class ConnectivityResumedReceiver extends BroadcastReceiver {

        private final AsyncFuture<Boolean> mFuture = new AsyncFuture<Boolean>();

        private final Context mContext;

        private ConnectivityResumedReceiver(Context context) {
            mContext = context;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            boolean noConnectivity = intent.getBooleanExtra(
                    ConnectivityManager.EXTRA_NO_CONNECTIVITY, false);
            if (!noConnectivity) {
                Log.i(TAG, "connectivity resumed");
                mFuture.setResult(true);
            }
        }

        public void await() throws InterruptedException, ExecutionException {
            if (isNetworkConnected(mContext)) {
                mFuture.setResult(true);
            }
            mFuture.get();
        }
    }

    private static final class AsyncFuture<V> extends FutureTask<V> {

        public AsyncFuture() {
            super(new Callable<V>() {
                @Override
                public V call() throws Exception {
                    throw new IllegalStateException(
                            "this should never be called");
                }
            });
        }

        public void setResult(V result) {
            set(result);
        }
    }

}
