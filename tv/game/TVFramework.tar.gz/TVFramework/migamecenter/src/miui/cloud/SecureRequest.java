package miui.cloud;

import android.util.Base64;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.crypto.Cipher;

import miui.cloud.SimpleRequest.MapContent;
import miui.cloud.SimpleRequest.StringContent;
import miui.cloud.exception.AccessDeniedException;
import miui.cloud.exception.AuthenticationFailureException;
import miui.cloud.exception.CipherException;
import miui.cloud.exception.InvalidResponseException;

/**
 * Data Request for MiCloud with Secure
 * @hide
 */
public class SecureRequest {

    private static final String UTF8 = SimpleRequest.UTF8;

    /**
     * Request data from MiCloud Server with Get Method, and convert response to string
     * @param url
     * @param params
     * @param cookies
     * @param readBody
     * @param security
     * @return
     * @throws IOException
     * @throws CipherException
     * @throws AccessDeniedException
     * @throws InvalidResponseException
     * @throws AuthenticationFailureException
     */
    public static StringContent getAsString(String url, Map<String, String> params,
            Map<String, String> cookies, boolean readBody, String security)
            throws IOException, CipherException, AccessDeniedException,
            InvalidResponseException, AuthenticationFailureException {
        Map<String, String> requestParams = encryptParams("GET", url, params,
                security);
        // the response is encrypted
        StringContent response = SimpleRequest.getAsString(url, requestParams,
                cookies, readBody);
        return processStringResponse(response, security);
    }

    /**
     * Request data from MiCloud Server with Get Method, and convert response to map
     * @param url
     * @param params
     * @param cookies
     * @param readBody
     * @param security
     * @return
     * @throws IOException
     * @throws CipherException
     * @throws AccessDeniedException
     * @throws InvalidResponseException
     * @throws AuthenticationFailureException
     */
    public static MapContent getAsMap(String url, Map<String, String> params,
            Map<String, String> cookies, boolean readBody, String security)
            throws IOException, CipherException, AccessDeniedException,
            InvalidResponseException, AuthenticationFailureException {
        StringContent stringContent = getAsString(url, params, cookies,
                readBody, security);
        return SimpleRequest.convertStringToMap(stringContent);
    }

    /**
     * Request data from MiCloud Server with Post Method, and convert response to string
     * @param url
     * @param params
     * @param cookies
     * @param readBody
     * @param security
     * @return
     * @throws IOException
     * @throws CipherException
     * @throws AccessDeniedException
     * @throws InvalidResponseException
     * @throws AuthenticationFailureException
     */
    public static StringContent postAsString(String url, Map<String, String> params,
            Map<String, String> cookies, boolean readBody, String security)
            throws IOException, CipherException, AccessDeniedException,
            InvalidResponseException, AuthenticationFailureException {
        Map<String, String> requestParams = encryptParams("POST", url, params,
                security);
        // the response is encrypted
        StringContent response = SimpleRequest.postAsString(url, requestParams,
                cookies, readBody);
        return processStringResponse(response, security);
    }

    /**
     * Request data from MiCloud Server with Post Method, and convert response to map
     * @param url
     * @param params
     * @param cookies
     * @param readBody
     * @param security
     * @return
     * @throws IOException
     * @throws AccessDeniedException
     * @throws InvalidResponseException
     * @throws CipherException
     * @throws AuthenticationFailureException
     */
    public static MapContent postAsMap(String url,
            Map<String, String> params, Map<String, String> cookies,
            boolean readBody, String security)
            throws IOException, AccessDeniedException, InvalidResponseException,
            CipherException, AuthenticationFailureException {
        StringContent stringContent = postAsString(url, params, cookies,
                readBody, security);
        return SimpleRequest.convertStringToMap(stringContent);
    }


    private static StringContent processStringResponse(
            StringContent stringResponse, String security)
            throws IOException, InvalidResponseException, CipherException {
        if (stringResponse == null) {
            throw new IOException("no response from server");
        }
        String body = stringResponse.getBody();
        if (body == null) {
            throw new InvalidResponseException("invalid response from server");
        }
        String decryptedBody = decryptResponse(body, security);
        StringContent resultContent = new StringContent(decryptedBody);
        resultContent.putHeaders(stringResponse.getHeaders());
        return resultContent;
    }

    public static Map<String, String> encryptParams(String method, String url,
            Map<String, String> params, String security)
            throws CipherException {
        Cipher cipher = CloudCoder.newAESCipher(security, Cipher.ENCRYPT_MODE);
        if (cipher == null) {
            throw new CipherException("failed to init cipher");
        }
        Map<String, String> requestParams = new HashMap<String, String>();
        if (params != null && !params.isEmpty()) {
            Set<Map.Entry<String, String>> entries = params.entrySet();
            for (Map.Entry<String, String> entry : entries) {
                String key = entry.getKey();
                String value = entry.getValue();
                if (key != null && value != null) {
                    // do NOT encrypt params whose name starts with underscore (_)
                    if (!key.startsWith("_")) {
                        try {
                            value = Base64.encodeToString(
                                    cipher.doFinal(value.getBytes(UTF8)),
                                    Base64.NO_WRAP);
                        } catch (Exception e) {
                            throw new CipherException(
                                    "failed to encrypt request params", e);
                        }
                    }
                    requestParams.put(key, value);
                }
            }
        }
        String signature = CloudCoder.generateSignature(method, url,
                requestParams, security);
        requestParams.put("signature", signature);
        return requestParams;
    }

    public static String decryptResponse(String body, String security)
            throws CipherException, InvalidResponseException {
        Cipher cipher = CloudCoder.newAESCipher(security, Cipher.DECRYPT_MODE);
        if (cipher == null) {
            throw new CipherException("failed to init cipher");
        }
        String responseData = null;
        try {
            byte[] bytes = cipher.doFinal(Base64.decode(body, Base64.NO_WRAP));
            responseData = new String(bytes, UTF8);
        } catch (Exception e) {
            // ignore
        }
        if (responseData == null) {
            throw new InvalidResponseException("failed to decrypt response");
        }
        return responseData;
    }

}