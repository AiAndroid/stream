package miui.cloud.exception;

import org.apache.http.HttpStatus;

/**
 * 
 * Exceptions handled by MiCloudSyncAdapterBase
 * 
 */
public class CloudServerException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2826947364523441280L;
	public int statusCode;

    public CloudServerException(int statusCode) {
        super("status: " + statusCode);
        this.statusCode = statusCode;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public static boolean isMiCloudServerException(int statusCode) {
        return statusCode == HttpStatus.SC_BAD_REQUEST ||
               statusCode == HttpStatus.SC_UNAUTHORIZED ||
               statusCode == HttpStatus.SC_FORBIDDEN ||
               statusCode == HttpStatus.SC_NOT_ACCEPTABLE ||
               statusCode / 100 == 5;
    }
}
