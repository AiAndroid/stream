package miui.cloud.exception;


public class CloudServiceFailureException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 3888935308598595235L;
	private int errorCode;

    public CloudServiceFailureException() {
    }

    public CloudServiceFailureException(String message) {
        super(message);
    }

    public CloudServiceFailureException(Throwable cause) {
        super(cause);
    }

    public CloudServiceFailureException(Throwable cause, int errorCode) {
        super(cause);
        this.errorCode = errorCode;
    }

    public int getErrorCode() {
        return errorCode;
    }
}
