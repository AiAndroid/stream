package miui.cloud.exception;

public class InvalidResponseException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 8566078736897655413L;

	public InvalidResponseException(String message) {
        super(message);
    }

}
