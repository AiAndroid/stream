package miui.cloud;

public interface IQueryBalance {
	public static final int QUERY_CODE_FAIL = 0;
	public static final int QUERY_CODE_SUCCESS = 1;
	public void onFinish(int code, long balance);
}
