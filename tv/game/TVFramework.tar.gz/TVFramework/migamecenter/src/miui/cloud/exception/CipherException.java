package miui.cloud.exception;


public class CipherException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 7327355957444985681L;

	public CipherException(String msg) {
        super(msg);
    }

    public CipherException(String message, Throwable cause) {
        super(message, cause);
    }
}
