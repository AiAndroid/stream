package miui.cloud.exception;

/**
 * TODO:
 * @hide
 */
public class NoActivateAccountException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoActivateAccountException(String message) {
        super(message);
    }
}