package miui.cloud.exception;

/**
 * 客户端的同步数据被修改导致服务端不认识的错误
 * 
 */
public class CloudParameterError extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 7169585196698304610L;

	public CloudParameterError() {
    }

    public CloudParameterError(String message) {
        super(message);
    }
}
