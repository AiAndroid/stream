package miui.cloud.exception;


public class AccessDeniedException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 5700441593109879965L;

	public AccessDeniedException(String detailMessage) {
        super(detailMessage);
    }
}
