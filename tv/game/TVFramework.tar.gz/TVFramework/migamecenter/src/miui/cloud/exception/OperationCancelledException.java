package miui.cloud.exception;

/**
 * TODO:
 * @hide
 */
public class OperationCancelledException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 5625765106040644629L;

	public OperationCancelledException() {
    }

    public OperationCancelledException(String message) {
        super(message);
    }
}
