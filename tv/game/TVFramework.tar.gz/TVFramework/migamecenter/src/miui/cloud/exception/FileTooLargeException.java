package miui.cloud.exception;


public class FileTooLargeException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 3117414151710477485L;

	public FileTooLargeException(String message) {
        super(message);
    }

}
