package miui.cloud;

import java.io.IOException;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerFuture;
import android.accounts.AuthenticatorException;
import android.accounts.OperationCanceledException;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class AccountUtils {
	public static final int ACCOUNT_ACTION_GETAUTHENTICATION = 1;
	public static final String ACCOUNT_ACTION_OPTION_NAME = "client_action";
	public static final String XIAOMI_ACCOUNT_TYPE = "com.xiaomi";

	public static String getExtToken(AccountManager paramAccountManager,
			String paramString, Account paramAccount) {
		Log.i("AccountUtils", "getExtToken, account: " + paramAccount);
		Bundle localBundle = new Bundle();
		localBundle.putInt("client_action", 1);
		String str;
		try {
			AccountManagerFuture<?> localAccountManagerFuture = paramAccountManager
					.getAuthToken(paramAccount, paramString, localBundle,
							false, null, null);
			if (localAccountManagerFuture == null) {
				Log.e("AccountUtils", "Null future.");
				return null;
			}
			if (localAccountManagerFuture.getResult() == null) {
				Log.e("AccountUtils", "Null future result.");
				return null;
			}
			str = ((Bundle) localAccountManagerFuture.getResult())
					.getString("authtoken");
			Log.d("AccountUtils", "token: " + str);
			if (str != null) {
				boolean bool = str.isEmpty();
				if (!bool)
					;
			} else {
				return null;
			}
		} catch (OperationCanceledException localOperationCanceledException) {
			Log.e("AccountUtils", "initAccount",
					localOperationCanceledException);
			return null;
		} catch (AuthenticatorException localAuthenticatorException) {
			Log.e("AccountUtils", "initAccount", localAuthenticatorException);
			return null;
		} catch (IOException localIOException) {
			Log.e("AccountUtils", "initAccount", localIOException);
			return null;
		}
		return str;
	}

	public static ExtendedAuthToken getPassToken(Activity paramActivity,
			Account paramAccount) {
		Log.i("AccountUtils", "getPassToken, account: " + paramAccount);
		Bundle localBundle = new Bundle();
		localBundle.putInt("client_action", 1);
		String str = null;
		AccountManagerFuture<?> localAccountManagerFuture = null;
		try {
			localAccountManagerFuture = AccountManager.get(paramActivity)
					.getAuthToken(paramAccount, "passportapi", localBundle,
							paramActivity, null, null);
			if (localAccountManagerFuture == null) {
				Log.e("AccountUtils", "getPassToken: Null future.");
				return null;
			}
			if (localAccountManagerFuture.getResult() == null) {
				Log.e("AccountUtils", "getPassToken: Null future result.");
				return null;
			}
			str = ((Bundle) localAccountManagerFuture.getResult())
					.getString("authtoken");
			if (str == null) {
				Log.w("AccountUtils", "getPassToken: No ext token string.");
				return null;
			}
		} catch (OperationCanceledException localOperationCanceledException) {
			// AccountManagerFuture localAccountManagerFuture;
			Log.e("AccountUtils", "getPassToken",
					localOperationCanceledException);
			return null;
		} catch (AuthenticatorException localAuthenticatorException) {
			Log.e("AccountUtils", "getPassToken", localAuthenticatorException);
			return null;
		} catch (IOException localIOException) {
			Log.e("AccountUtils", "getPassToken", localIOException);
			return null;
		}
		return ExtendedAuthToken.parse(str);
	}
}
