package miui.cloud.exception;

public class AuthenticationFailureException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = -5989543052068492125L;

	public AuthenticationFailureException(String detailMessage) {
        super(detailMessage);
    }
}
