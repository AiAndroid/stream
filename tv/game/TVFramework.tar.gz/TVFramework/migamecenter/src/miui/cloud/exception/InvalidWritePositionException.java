package miui.cloud.exception;

/**
 * TODO:
 * @hide
 */
public class InvalidWritePositionException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidWritePositionException(String message) {
        super(message);
    }

}
