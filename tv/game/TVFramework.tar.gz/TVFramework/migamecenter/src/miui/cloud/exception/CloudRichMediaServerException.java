package miui.cloud.exception;

/**
 */
public class CloudRichMediaServerException extends CloudServerException {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6994788167588091140L;

	public CloudRichMediaServerException(int statusCode) {
        super(statusCode);
    }

}
