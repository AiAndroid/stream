/**
 * @deprecated Don't use this class again, it will be delete.
 */
package miui.cloud;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Build;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.CookieManager;
import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import miui.cloud.exception.AccessDeniedException;
import miui.cloud.exception.AuthenticationFailureException;

/**
 * Data Request for MiCloud without secure
 * @hide
 * 
 */
public final class SimpleRequest {

    private static final boolean DEBUG = false;

    public static final String UTF8 = "utf-8";
    public static final boolean IS_ALPHA_BUILD = "1".equals(SimpleRequest.getSystemProperties(
    		"ro.miui.secure"));


    private static final Logger log = Logger.getLogger(
            SimpleRequest.class.getSimpleName());

    private static final int TIMEOUT = 30000;

    public static final String LOCATION = "Location";
    
    /**
     * 从android.os.SystemProperties中获取一个属性
     * @param prop
     * @return
     */
    public static String getSystemProperties(String prop) {
        String output = "";
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            Method get = sp.getMethod("get", String.class);
            output = (String)get.invoke(null, prop);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return output;
    }
    
    
    private static String mUserAgent;
    public static String getUserAgent() {
        if (mUserAgent == null) {
            StringBuilder sb = new StringBuilder();
            //  model name + region name, like aries_tw
//            String miuiModel = SystemProperties.get("ro.product.mod_device");
//            if (!TextUtils.isEmpty(miuiModel)) {
//                sb.append(miuiModel);
//            } else {
//                sb.append(Build.MODEL);
//            }
            sb.append(Build.MODEL);
            sb.append("; MIUI/");
            sb.append(Build.VERSION.INCREMENTAL);
            if (IS_ALPHA_BUILD) {
                sb.append(' ');
                sb.append("ALPHA");
            }
            mUserAgent = sb.toString();
        }
        return mUserAgent;
    }

    protected static String appendUrl(String origin,
            List<NameValuePair> nameValuePairs) {
        if (origin == null) {
            throw new NullPointerException("origin is not allowed null");
        }
        StringBuilder urlBuilder = new StringBuilder(origin);
        if (nameValuePairs != null) {
            final String paramPart = URLEncodedUtils
                    .format(nameValuePairs, UTF8);
            if (paramPart != null && paramPart.length() > 0) {
                if (origin.contains("?")) {
                    urlBuilder.append("&");
                } else {
                    urlBuilder.append("?");
                }
                urlBuilder.append(paramPart);
            }
        }
        return urlBuilder.toString();
    }

    /**
     * Request data from MiCloud Server with Get Method, and convert response to string
     * @param url
     * @param params
     * @param cookies
     * @param readBody
     * @return
     * @throws IOException
     * @throws AccessDeniedException
     * @throws AuthenticationFailureException
     */
    public static StringContent getAsString(String url,
            Map<String, String> params, Map<String, String> cookies,
            boolean readBody) throws IOException, AccessDeniedException,
            AuthenticationFailureException {
        List<NameValuePair> nameValuePairs = mapToPairs(params);
        final String fullUrl = appendUrl(url, nameValuePairs);
        HttpURLConnection conn = makeConn(fullUrl, cookies);
        if (conn == null) {
            log.severe("failed to create URLConnection");
            throw new IOException("failed to create connection");
        }
        try {
            conn.setDoInput(true);
            conn.setRequestMethod("GET");
            conn.connect();

            int code = conn.getResponseCode();
            if (code == HttpURLConnection.HTTP_OK
                    || code == HttpURLConnection.HTTP_MOVED_TEMP) {
                final Map<String, List<String>> headerFields = conn
                        .getHeaderFields();
                final CookieManager cm = new CookieManager();
                final URI reqUri = URI.create(fullUrl);
                cm.put(reqUri, headerFields);
                List<HttpCookie> httpCookies = cm.getCookieStore().get(reqUri);
                Map<String, String> cookieMap = parseCookies(httpCookies);
                cookieMap.putAll(listToMap(headerFields));
                StringBuilder sb = new StringBuilder();
                if (readBody) {
                    BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream()), 1024);
                    try {
                        String line;
                        while ((line = br.readLine()) != null) {
                            sb.append(line);
                        }
                    } finally {
                        try {
                            br.close();
                        } catch (IOException ex) {
                            // ignore
                        }
                    }
                }
                final StringContent stringContent = new StringContent(
                        sb.toString());
                stringContent.putHeaders(cookieMap);
                return stringContent;
            } else if (code == HttpURLConnection.HTTP_FORBIDDEN) {
                throw new AccessDeniedException(
                        "access denied, encrypt error or user is forbidden to access the resource");
            } else if (code == HttpURLConnection.HTTP_UNAUTHORIZED
                    || code == HttpURLConnection.HTTP_BAD_REQUEST) {
                throw new AuthenticationFailureException(
                        "authentication failure for get, code: " + code);
            } else {
                log.info("http status error when GET: " + code);
                if (code == HttpURLConnection.HTTP_MOVED_PERM) {
                    log.info("unexpected redirect from "
                            + conn.getURL().getHost() + " to "
                            + conn.getHeaderField(LOCATION));
                }
                throw new IOException("unexpected http res code: " + code);
            }
        } catch (ProtocolException e) {
            throw new IOException("protocol error");
        } finally {
            conn.disconnect();
        }
    }

    /**
     * Request data from MiCloud Server with Get Method, and convert response to stream
     * @param url
     * @param params
     * @param cookies
     * @return
     * @throws IOException
     * @throws AccessDeniedException
     * @throws AuthenticationFailureException
     */
    public static StreamContent getAsStream(String url,
            Map<String, String> params, Map<String, String> cookies)
            throws IOException, AccessDeniedException,
            AuthenticationFailureException {
        List<NameValuePair> nameValuePairs = mapToPairs(params);
        final String fullUrl = appendUrl(url, nameValuePairs);
        HttpURLConnection conn = makeConn(fullUrl, cookies);
        if (conn == null) {
            log.severe("failed to create URLConnection");
            throw new IOException("failed to create connection");
        }
        try {
            conn.setDoInput(true);
            conn.setRequestMethod("GET");
            // follow redirect
            conn.setInstanceFollowRedirects(true);
            conn.connect();

            int code = conn.getResponseCode();
            // only allow 200
            if (code == HttpURLConnection.HTTP_OK) {
                final Map<String, List<String>> headerFields = conn
                        .getHeaderFields();
                final CookieManager cm = new CookieManager();
                final URI reqUri = URI.create(fullUrl);
                cm.put(reqUri, headerFields);
                List<HttpCookie> httpCookies = cm.getCookieStore().get(reqUri);
                Map<String, String> cookieMap = parseCookies(httpCookies);
                cookieMap.putAll(listToMap(headerFields));
                StreamContent streamContent = new StreamContent(
                        conn.getInputStream());
                streamContent.putHeaders(cookieMap);
                return streamContent;
            } else if (code == HttpURLConnection.HTTP_FORBIDDEN) {
                throw new AccessDeniedException(
                        "access denied, encrypt error or user is forbidden to access the resource");
            } else if (code == HttpURLConnection.HTTP_UNAUTHORIZED
                    || code == HttpURLConnection.HTTP_BAD_REQUEST) {
                throw new AuthenticationFailureException(
                        "authentication failure for get, code: " + code);
            } else {
                log.info("http status error when GET: " + code);
                if (code == HttpURLConnection.HTTP_MOVED_PERM) {
                    log.info("unexpected redirect from "
                            + conn.getURL().getHost() + " to "
                            + conn.getHeaderField(LOCATION));
                }
                throw new IOException("unexpected http res code: " + code);
            }
        } catch (ProtocolException e) {
            throw new IOException("protocol error");
        }
        // do not close the connection.
        // otherwise, the returned stream cannot be read
    }

    /**
     * Request data from MiCloud Server with Get Method, and convert response to map
     * @param url
     * @param params
     * @param cookies
     * @param readBody
     * @return
     * @throws IOException
     * @throws AccessDeniedException
     * @throws AuthenticationFailureException
     */
    public static MapContent getAsMap(String url,
            Map<String, String> params, Map<String, String> cookies,
            boolean readBody) throws IOException, AccessDeniedException,
            AuthenticationFailureException {
        StringContent stringContent = getAsString(url, params, cookies,
                readBody);
        return convertStringToMap(stringContent);
    }

    /**
     * Request data from MiCloud Server with Post Method, and convert response to string
     * @param url
     * @param params
     * @param cookies
     * @param readBody
     * @return
     * @throws IOException
     * @throws AccessDeniedException
     * @throws AuthenticationFailureException
     */
    public static StringContent postAsString(String url,
            Map<String, String> params, Map<String, String> cookies,
            boolean readBody) throws IOException, AccessDeniedException,
            AuthenticationFailureException {
        HttpURLConnection conn = makeConn(url, cookies);
        if (conn == null) {
            log.severe("failed to create URLConnection");
            throw new IOException("failed to create connection");
        }
        try {
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.connect();

            List<NameValuePair> nameValuePairs = mapToPairs(params);
            if (nameValuePairs != null) {
                String content = URLEncodedUtils.format(nameValuePairs, UTF8);
                OutputStream os = conn.getOutputStream();
                BufferedOutputStream bos = new BufferedOutputStream(os);
                try {
                    bos.write(content.getBytes(UTF8));
                } finally {
                    try {
                        bos.flush();
                    } catch (IOException ex) {
                        // ignore
                    }
                    try {
                        bos.close();
                    } catch (IOException ex) {
                        // ignore
                    }
                }
            }

            int code = conn.getResponseCode();
            if (code == HttpURLConnection.HTTP_OK
                    || code == HttpURLConnection.HTTP_MOVED_TEMP) {
                final Map<String, List<String>> headerFields = conn
                        .getHeaderFields();
                final CookieManager cm = new CookieManager();
                final URI reqUri = URI.create(url);
                cm.put(reqUri, headerFields);
                Map<String, String> cookieMap = parseCookies(
                        cm.getCookieStore().get(reqUri));
                cookieMap.putAll(listToMap(headerFields));
                StringBuilder sb = new StringBuilder();
                if (readBody) {
                    BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream()),
                            1024);
                    try {
                        String line;
                        while ((line = br.readLine()) != null) {
                            sb.append(line);
                        }
                    } finally {
                        try {
                            br.close();
                        } catch (IOException ex) {
                            // ignore
                        }
                    }
                }
                final StringContent stringContent = new StringContent(
                        sb.toString());
                stringContent.putHeaders(cookieMap);
                return stringContent;
            } else if (code == HttpURLConnection.HTTP_FORBIDDEN) {
                throw new AccessDeniedException(
                        "access denied, encrypt error or user is forbidden to access the resource");
            } else if (code == HttpURLConnection.HTTP_UNAUTHORIZED
                    || code == HttpURLConnection.HTTP_BAD_REQUEST) {
                throw new AuthenticationFailureException(
                        "authentication failure for post, code: " + code);
            } else {
                log.info("http status error when POST: " + code);
                if (code == HttpURLConnection.HTTP_MOVED_PERM) {
                    log.info("unexpected redirect from "
                            + conn.getURL().getHost() + " to "
                            + conn.getHeaderField(LOCATION));
                }
                throw new IOException("unexpected http res code: " + code);
            }
        } catch (ProtocolException e) {
            throw new IOException("protocol error");
        } finally {
            conn.disconnect();
        }
    }

    /**
     * Request data from MiCloud Server with Post Method, and convert response to map
     * @param url
     * @param params
     * @param cookies
     * @param readBody
     * @return
     * @throws IOException
     * @throws AccessDeniedException
     * @throws AuthenticationFailureException
     */
    public static MapContent postAsMap(String url,
            Map<String, String> params, Map<String, String> cookies,
            boolean readBody) throws IOException, AccessDeniedException,
            AuthenticationFailureException {
        StringContent stringContent = postAsString(url, params, cookies,
                readBody);
        return convertStringToMap(stringContent);
    }

    protected static MapContent convertStringToMap(StringContent stringContent) {
        if (stringContent == null) {
            return null;
        }
        String bodyString = stringContent.getBody();
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(bodyString);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (jsonObject == null) {
            return null;
        }
        Map<String, Object> contentMap = jsonToMap(jsonObject);
        MapContent mapContent = new MapContent(contentMap);
        mapContent.putHeaders(stringContent.getHeaders());
        return mapContent;
    }

    protected static HttpURLConnection makeConn(String url,
            Map<String, String> cookies) {
        URL req = null;
        try {
            req = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        if (req == null) {
            log.severe("failed to init url");
            return null;
        }
        try {
            HttpURLConnection conn = (HttpURLConnection) req.openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(TIMEOUT);
            conn.setReadTimeout(TIMEOUT);
            conn.setUseCaches(false);
            conn.setRequestProperty("Content-Type",
                    "application/x-www-form-urlencoded");
            conn.setRequestProperty("User-Agent", getUserAgent());
            if (cookies != null) {
                conn.setRequestProperty("Cookie", joinMap(cookies, "; "));
            }
            return conn;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    protected static String joinMap(Map<String, String> map, String sp) {
        if (map == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        Set<Map.Entry<String, String>> entries = map.entrySet();
        int i = 0;
        for (Map.Entry<String, String> entry : entries) {
            if (i > 0) {
                sb.append(sp);
            }
            final String key = entry.getKey();
            final String value = entry.getValue();
            sb.append(key);
            sb.append("=");
            sb.append(value);
            i++;
        }
        return sb.toString();
    }

    protected static Map<String, String> parseCookies(
            List<HttpCookie> cookies) {
        Map<String, String> cookieMap = new HashMap<String, String>();
        for (HttpCookie cookie : cookies) {
            if (!cookie.hasExpired()) {
                final String name = cookie.getName();
                final String value = cookie.getValue();
                if (name != null) {
                    cookieMap.put(name, value);
                }
            } else {
                if (DEBUG) {
                    log.warning("cookie has expired, key:" + cookie.getName());
                }
            }
        }
        return cookieMap;
    }

    /**
     * Convert map to NameValuePair list for performing http request.
     *
     * @param map map object
     * @return NameValuePair list, or null if map is null
     */
    private static List<NameValuePair> mapToPairs(Map<String, String> map) {
        if (map == null) {
            return null;
        }
        List<NameValuePair> pairs = new ArrayList<NameValuePair>();
        Set<Map.Entry<String, String>> entries = map.entrySet();
        for (Map.Entry<String, String> entry : entries) {
            final String key = entry.getKey();
            final String value = entry.getValue();
            BasicNameValuePair pair = new BasicNameValuePair(key,
                    value != null ? value : "");
            pairs.add(pair);
        }
        return pairs;
    }

    /**
     * <p>Flatten json object into Map. the data type in the json object will be
     * retained. The parameter type of the returned map is Object, so it can
     * contain arbitrary data types. The four basic json types corresponds to
     * primitive type or String or null in Java, eg.: <ul><li>json number => int
     * (or long)</li><li>json bool (true, false) => boolean</li><li>json string
     * => String </li><li>json null => null</li></ul> JSON array will be
     * converted to List, and JSON Object will recursively be converted to
     * Object, eg.: <ul><li>json array => List</li><li>json object =>
     * Object</li></ul>Here are some examples:</p> <ul><li>{"name":"Lin"} =>
     * map.put("name", "Lin")</li> <li> {"name", {"first":"Jun", "last":"Lin"}}
     * => nameMap.put("first", "Jun"); nameMap.put("last", "Lin");
     * map.put("name", nameMap); </li> </ul>
     *
     * @param jsonObj json object to be converted
     * @return map object or null if jsonObj is null
     */
    private static Map<String, Object> jsonToMap(JSONObject jsonObj) {
        if (jsonObj == null) {
            return null;
        }
        Map<String, Object> map = new HashMap<String, Object>();
        Iterator<?> iter = jsonObj.keys();
        while (iter.hasNext()) {
            final String key = (String) iter.next();
            final Object value = jsonObj.opt(key);
            map.put(key, convertObj(value));
        }
        return map;
    }

    private static Map<String, String> listToMap(
            Map<String, List<String>> listMap) {
        Map<String, String> map = new HashMap<String, String>();
        if (listMap != null) {
            Set<Map.Entry<String, List<String>>> entries = listMap.entrySet();
            for (Map.Entry<String, List<String>> entry : entries) {
                final String key = entry.getKey();
                final List<String> valueList = entry.getValue();
                if (key != null && valueList != null && valueList.size() > 0) {
                    map.put(key, valueList.get(0));
                }
            }
        }
        return map;
    }

    private static Object convertObj(Object obj) {
        if (obj instanceof JSONObject) {
            return jsonToMap((JSONObject) obj);
        } else if (obj instanceof JSONArray) {
            JSONArray array = (JSONArray) obj;
            final int size = array.length();
            List<Object> list = new ArrayList<Object>();
            for (int i = 0; i < size; i++) {
                list.add(convertObj(array.opt(i)));
            }
            return list;
        } else if (obj == JSONObject.NULL) {
            return null;
        }
        return obj;
    }

    public static class HeaderContent {

        private final Map<String, String> headers
                = new HashMap<String, String>();

        public void putHeader(String key, String value) {
            headers.put(key, value);
        }

        public String getHeader(String key) {
            return headers.get(key);
        }

        public Map<String, String> getHeaders() {
            return headers;
        }

        public void putHeaders(Map<String, String> headers) {
            this.headers.putAll(headers);
        }

        @Override
        public String toString() {
            return "HeaderContent{" +
                    "headers=" + headers +
                    '}';
        }
    }

    public static class StringContent extends HeaderContent {

        private String body;

        public StringContent(String body) {
            this.body = body;
        }

        public String getBody() {
            return body;
        }

        @Override
        public String toString() {
            return "StringContent{" +
                    "body='" + body + '\'' +
                    '}';
        }
    }

    public static class MapContent extends HeaderContent {

        private Map<String, Object> bodies;

        public MapContent(Map<String, Object> bodies) {
            this.bodies = bodies;
        }

        public Object getFromBody(String key) {
            return bodies.get(key);
        }

        @Override
        public String toString() {
            return "MapContent{" +
                    "bodies=" + bodies +
                    '}';
        }
    }

    public static class StreamContent extends HeaderContent {

        private InputStream stream;

        public StreamContent(InputStream stream) {
            this.stream = stream;
        }

        public InputStream getStream() {
            return stream;
        }

        public void closeStream() {
            if (stream != null) {
                try {
                    stream.close();
                } catch (IOException ex) {
                    // ignore
                }
            }
        }

    }

}
